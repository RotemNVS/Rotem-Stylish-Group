<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 14.09.2016
 * Time: 14:42
 */
add_action( 'wp_footer', 'revo_add_to_footer_code' );

function revo_add_to_footer_code() {
	?>
	<div id="request" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<span class="close" data-dismiss="modal" aria-label="Close">&times;</span>

					<h2 class="modal-title"><?php echo wp_kses_post( get_theme_mod( 'revo_c_form_s_txt', esc_html__( 'Start with us', 'revo' ) ) );

						?>
						<?php //esc_html_e( 'Start with us', 'revo' );
						?></h2>
				</div>
				<div class="modal-body text-center">

					<?php if ( function_exists( 'revo_contact_form_func' ) ) {

						echo do_shortcode( get_theme_mod( 'revo_c_form_s_val', '[revo_contact_form]' ) );

					} else {

						?>
						<form class="form-request js-ajax-form">
							<div class="row-fields row">
								<div class="form-group col-field col-sm-6">
									<input type="text" class="form-control form-control-white" name="name" required
									       placeholder="<?php esc_html_e( 'Name *', 'revo' ); ?>">
								</div>
								<div class="form-group col-field col-sm-6">
									<input type="email" class="form-control form-control-white" name="email" required
									       placeholder="<?php esc_html_e( 'Email *', 'revo' ); ?>">
								</div>
								<div class="form-group col-field col-sm-12">
                            <textarea class="form-control form-control-white" rows="3" name="message"
                                      placeholder="<?php esc_html_e( 'Message', 'revo' ); ?>"></textarea>
								</div>

								<div class="col-sm-12">
									<button type="submit" class="btn btn-hvr-white hvr-pulse-grow"
									        data-text-hover="Submit">
										<?php esc_html_e( 'Send request', 'revo' ); ?>
									</button>
								</div>

							</div>
						</form>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>

	<!-- Modals success -->

	<div id="success" class="modal modal-message fade" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
                <span class="close" data-dismiss="modal" aria-label="Close"><span
		                aria-hidden="true">&times;</span></span>

					<h2 class="modal-title">
						<?php
						echo esc_html( get_theme_mod( 'revo_c_form_s_susses_title', esc_html__( 'Thank you', 'revo' ) ) ); ?></h2>

					<p class="modal-subtitle">
						<?php echo esc_html( get_theme_mod( 'revo_c_form_s_susses_sub_title', esc_html__( 'Your message is successfully sent...', 'revo' ) ) ); ?>
					</p>
				</div>
			</div>
		</div>
	</div>

	<!-- Modals error -->

	<div id="error" class="modal modal-message fade" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
                <span class="close" data-dismiss="modal" aria-label="Close"><span
		                aria-hidden="true">&times;</span></span>

					<h2 class="modal-title">
						<?php echo esc_html( get_theme_mod( 'revo_c_form_s_error_title', esc_html__( 'Sorry', 'revo' ) ) ); ?>
					</h2>

					<p class="modal-subtitle">
						<?php echo esc_html( get_theme_mod( 'revo_c_form_s_error_sub_title', esc_html__( 'Something went wrong', 'revo' ) ) ); ?>
					</p>
				</div>
			</div>
		</div>
	</div>

	<?php

}

/**
 *
 */
function revo_mail_send() {
	if ( isset( $_POST['email'] ) && isset( $_POST['name'] ) && isset( $_POST['message'] ) ) {

		// detect & prevent header injections
		$test = "/(content-type|bcc:|cc:|to:)/i";
		foreach ( $_POST as $key => $val ) {
			if ( preg_match( $test, $val ) ) {
				exit;
			}
		}

		$to = esc_html( get_option( 'admin_email' ) );
		if ( strlen( get_theme_mod( 'mail_email' ) ) > 4 ) {
			$to = esc_html( get_theme_mod( 'mail_email' ) );
		}
		$email = sanitize_text_field( $_POST['email'] );



		$phone = '';
		if ( isset( $_POST['phone'] ) ) {
			$phone = "\n\r <br>" . esc_html__( 'Phone number: ', 'revo' ) . sanitize_text_field( $_POST['phone'] ) . ' ' . "\n\r <br>";
		}
		$headers[] = "From:  {$email} < $to >";
		$headers[] = 'content-type: text/html';
		$send      = wp_mail( $to, sanitize_text_field( $_POST['name'] ), wp_kses_post( $_POST['message'] ) . $phone, $headers );


		if ( $send ) {
			echo 1;
		} else {
			echo 0;

		}

	}
	wp_die();
	exit;
}

add_action( 'wp_ajax_revo_mail_send', 'revo_mail_send' ); // for logged in user
add_action( 'wp_ajax_nopriv_revo_mail_send', 'revo_mail_send' ); // if user not logged in