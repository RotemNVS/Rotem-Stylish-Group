<?php
/*
Plugin Name: Revo plugin
Plugin URI:
Description: Revo plugin
Version: 1.0.8
Author: Victor
Author URI:
License:
*/



if (function_exists('vc_set_shortcodes_templates_dir')) {
    require plugin_dir_path(__FILE__) . '/shortcodes/shortcodes.php';
    require plugin_dir_path(__FILE__) . '/VC_custum-data.php';
}
require plugin_dir_path(__FILE__) . '/import_demo.php';
require plugin_dir_path(__FILE__) . '/contact_form.php';
require plugin_dir_path(__FILE__) . '/custom-style.php';
require plugin_dir_path(__FILE__) . '/function.php';



/**
 *Create the desired tables for theme
 */


add_action('init', 'revo_portfolio_init');
/**
 * great portfolio custom type post
 */
function revo_portfolio_init()
{
    $args = array(
        'label' => esc_html__('Events', 'revo'),
        'labels' => array(
            'edit_item' => esc_html__('Edit', 'revo'),
            'add_new_item' => esc_html__('Add', 'revo'),
            'view_item' => esc_html__('View', 'revo'),
        ),
        'singular_label' => esc_html__('Event', 'revo'),
        'has_archive' => true,
        'public' => true,
        'show_ui' => true,
        '_builtin' => false,
        '_edit_link' => 'post.php?post=%d',
        'capability_type' => 'post',
        'hierarchical' => false,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-groups'
    );

    $args['label'] = esc_html__('Portfolio', 'revo');
    $args['singular_label'] = esc_html__('Item', 'revo');
    register_post_type('portfolio', $args);
    register_taxonomy(
        'portfolio_categories',  //The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces).
        'portfolio',         //post type name
        array(
            'hierarchical' => true,
            'label' => esc_html__('Category', 'revo'),  //Display name
            'query_var' => true,
            'rewrite' => array('slug' => 'portfolio')

        )
    );

}








// ADD NEW COLUMN
function revo_columns_head($defaults)
{
    $defaults['place_author'] = esc_html__('Image', 'revo');
    return $defaults;
}

// SHOW THE AUTHOR portfolio
function revo_columns_content($column_name, $post_ID)
{
    if ($column_name == 'place_author') {


        $thumbnail = get_the_post_thumbnail($post_ID, 'thumbnail');
        preg_match_all('#src="(.*?)"#si', $thumbnail, $thumb_url);



?>
    <img width="75"  src="<?php
global  $Revo_class;
        if (isset($thumb_url[1][0]))
            $Revo_class->get_post_thumbnail($post_ID, 50, 50, true); ?>" alt="">
<?php

    }
}

add_filter('manage_portfolio_posts_columns', 'revo_columns_head');
add_action('manage_portfolio_posts_custom_column', 'revo_columns_content', 10, 2);


add_shortcode('revo_social_links', 'revo_social_links_function');

function revo_social_links_function($atts)
{
    $atts = shortcode_atts(
        array(
            'url' => '#',
            'class' => '',
        ), $atts
    );
    ob_start();
    ?>
    <a href="<?php echo esc_url($atts['url']); ?>" class=" <?php echo esc_html($atts['class']) ?>">

    </a>

    <?php
    return ob_get_clean();
}

