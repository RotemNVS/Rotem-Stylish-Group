<?php
/**
 * SHORTCODES V2
 * Created by PhpStorm.
 * User: Pro
 * Date: 10.06.2016
 * Time: 12:30
 */

/********New SHORTCODES ****************/


/*
 *  Services
 */


add_shortcode( 'revo_services', 'revo_services_func' );
function revo_services_func( $atts, $content ) {
	ob_start();
	$content = !empty( $content ) ? $content : "";
	$atts = shortcode_atts(
		array(
			't' => esc_html__( 'We Are Awesome Web Agency', 'revo' ),
			'd' => esc_html__( ' The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo' ),
			'class' => 'fadeInUp',
			'icon' => '',
			'items' => '',
			'ts' => esc_html__( 'Branding', 'revo' ),
			'ds' => esc_html__( 'Maecenas mattis est eget efficitur tempus. Maecenas fermentum fringilla vestibulum. Nulla pulvinar ullamcorper auctor', 'revo' ),
			'section_id' => '',
			'wow_delay' => '',
			'css' => '',


		), $atts

	);

	extract( $atts );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );

	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="services <?php echo esc_attr( $css_class ); ?>  text-center section">


        <div class="container">
            <div class="row">
                <header class="col-md-8 col-md-offset-2">
                    <h2 class="section-title"><?php echo esc_html( $t ); ?></h2>

                    <div class="spacer spacer-primary">
                        <div class="line">
                            <div class="dot"></div>
                            <div class="dot"></div>
                            <div class="dot"></div>
                        </div>
                    </div>
                    <p><?php echo esc_html( $d ); ?></p>
                </header>
            </div>
        </div>
        <div class="section-content">
            <div class="container">
                <div class="row row-columns">
					<?php
					$items_v = vc_param_group_parse_atts( $atts['items'] );
					if ( $items_v ) {
						foreach ( $items_v as $item ) {

							?>


                            <div class="service-column column col-md-4 wow <?php echo esc_attr( $class ); ?>"
                                 data-wow-delay="<?php if ( isset( $item['wow']{1} ) ) {
								     echo esc_attr( $item['wow'] );
							     } ?>">
              <span class="icon-circle">
                <i class="fa <?php echo esc_attr( ( $item['icon'] ) ); ?>"></i>
              </span>

                                <h3 class="entry"><?php if ( isset( $item['ts'] ) ) {
										echo esc_html( $item['ts'] );
									} ?></h3>

                                <div class="spacer-white">
                                    <div class="line">
                                        <div class="dot"></div>
                                        <div class="dot"></div>
                                        <div class="dot"></div>
                                    </div>
                                </div>

                                <div class="spacer">
                                    <div class="line">
                                        <div class="dot"></div>
                                        <div class="dot"></div>
                                        <div class="dot"></div>
                                    </div>
                                </div>
                                <p class="small text-muted"><?php if ( isset( $item['ds'] ) ) {
										echo esc_html( $item['ds'] );
									} ?></p>
                            </div>


						<?php }
					}
					?>
                </div>

            </div>
        </div>
    </section>

	<?php
	return ob_get_clean();
}


/*
 *  Services2
 */


add_shortcode( 'revo_services2', 'revo_services2_func' );
function revo_services2_func( $atts, $content ) {
	ob_start();
	$content = !empty( $content ) ? $content : "";
	$atts = shortcode_atts(
		array(
			't' => esc_html__( 'We Are Awesome Web Agency', 'revo' ),
			'd' => esc_html__( ' The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo' ),
			'class' => '',
			'icon' => '',
			'items' => '',
			'ts' => esc_html__( 'Branding', 'revo' ),
			'ds' => esc_html__( 'Maecenas mattis est eget efficitur tempus. Maecenas fermentum fringilla vestibulum. Nulla pulvinar ullamcorper auctor', 'revo' ),
			'section_id' => '',
			'wow_delay' => '',
			'css' => '',
			'anima' => '',

		), $atts

	);

	extract( $atts );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="services  <?php echo esc_attr( $css_class ); ?> text-center section">


        <div class="container">
            <div class="row row-base">
				<?php
				$items_v = vc_param_group_parse_atts( $atts['items'] );
				if ( $items_v ) {
					foreach ( $items_v as $item ) {

						?>


                        <div
                                class="service-column column col-md-4 <?php if ( isset( $item['anima'] ) ) {
									echo esc_html( $item['anima'] );
								} ?>" <?php if ( isset( $item['wow_delay'] ) ) { ?> data-wow-delay="<?php echo esc_attr( $item['wow_delay'] ); ?>"  <?php } ?>>
                            <div class="border-column">

              <span class="icon-circle-white">
                <i class="fa   <?php if ( isset( $item['icon'] ) ) {
	                echo esc_html( $item['icon'] );
                } ?>"></i>
              </span>

                                <h3 class="entry"><?php if ( isset( $item['ts'] ) ) {
										echo esc_html( $item['ts'] );
									} ?></h3>

                                <div class="spacer-white">
                                    <div class="line">
                                        <div class="dot"></div>
                                        <div class="dot"></div>
                                        <div class="dot"></div>
                                    </div>
                                </div>
                                <div class="spacer">
                                    <div class="line">
                                        <div class="dot"></div>
                                        <div class="dot"></div>
                                        <div class="dot"></div>
                                    </div>
                                </div>
                                <p class="small "><?php if ( isset( $item['ds'] ) ) {
										echo esc_html( $item['ds'] );
									} ?></p>
                            </div>
                        </div>


					<?php }
				}
				?>
            </div>

    </section>

	<?php
	return ob_get_clean();
}


/*
 * Portfolio
 */

add_shortcode( 'revo_portfolio_new', 'revo_portfolio_new_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_portfolio_new_func( $atts, $content ) {
	global $Revo_class;
	ob_start();
	extract( shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'heading' => '',
		'posts' => 0,
		'order' => 'DESC',
		'orderby' => 'date',
		'portfolio_category' => 'all',
		'class' => ' ',


	), $atts ) );


	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
	?>

    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="showcase 	<?php echo esc_attr( $css_class ); ?>  text-center">

        <div class="container">
            <div class="row">
				<?php if ( isset( $heading{1} ) ) { ?>
                    <header class="col-md-8 col-md-offset-2">
                        <h2 class="section-title"><?php if ( isset( $heading{1} ) ) {
								echo esc_html( $heading );
							} ?></h2>

                        <div class="spacer spacer-primary">
                            <div class="line">
                                <div class="dot"></div>
                                <div class="dot"></div>
                                <div class="dot"></div>
                            </div>
                        </div>
                    </header>

				<?php } ?>
            </div>
            <ul class="filter">
                <li class="active"><a href="#" data-filter="*"> <?php esc_html_e( 'All', 'revo' ); ?></a></li>
				<?php $terms = get_terms( 'portfolio_categories', array( 'hide_empty' => true ) );
				foreach ( $terms as $v ) {

					?>
                    <li><a href="#"
                           data-filter=".<?php echo esc_attr( $v->slug ); ?>"><?php echo esc_html( $v->name ); ?></a>
                    </li>
					<?php

				}
				?>

            </ul>
        </div>

        <div class="section-content">


            <div class="isotope  <?php echo esc_attr( $class ); ?> js-gallery">
				<?php

				$rentit_new_arr = array(
					'posts_per_page' => $posts,
					'order' => $order,
					'orderby' => $orderby,
					'post_status' => 'publish',
					'post_type' => 'portfolio',
				);


				if ( $portfolio_category != 'all' ) {
					$str = $portfolio_category;
					$arr = explode( ',', $str );
					$rentit_new_arr['tax_query'][] = array(
						'taxonomy' => 'portfolio_categories',
						'field' => 'slug',
						'terms' => $arr
					);
				}


				$rentit_custom_query = new WP_Query( $rentit_new_arr );
				if ( $rentit_custom_query->have_posts() ):
					while ( $rentit_custom_query->have_posts() ) {
						$rentit_custom_query->the_post();


						$terms = get_the_terms( get_the_ID(), 'portfolio_categories' );
						$revo_portfolio_widht = get_post_meta( get_the_ID(), '_revo_portfolio_widht', true );

						?>
                        <div class="isotope-item  <?php
						if ( !empty( $terms ) ):
							foreach ( $terms as $v ) {
								echo esc_html( $v->slug . " " );
							}
						endif;
						if ( $revo_portfolio_widht == 'on' ) {
							echo esc_html( ' w2 ' );
						} ?>">
                            <a href="<?php $Revo_class->get_post_thumbnail( get_the_ID(), 345, 244, true ); ?>"
                               title="<?php the_title(); ?>">

                                <figure class="showcase-item">
                                    <div class="showcase-item-thumbnail"><img alt=""
                                                                              src="<?php $Revo_class->get_post_thumbnail( get_the_ID(), 600, 400 ); ?>">
                                    </div>
                                    <figcaption class="showcase-item-hover">
                                        <div class="showcase-item-info">
											<?php
											foreach ( $terms as $v ) {

												?>

                                                <div
                                                        class="showcase-item-category"> <?php echo esc_html( $v->name ); ?></div>
											<?php } ?>


                                            <div class="showcase-item-title">  <?php the_title(); ?></div>
                                        </div>
                                    </figcaption>
                                </figure>
                            </a>
                        </div>

						<?php

					}
					wp_reset_postdata();


				endif;
				?>


            </div>
        </div>

    </section>


	<?php
	return ob_get_clean();

}


/*
 * Portfolio col-2
 */

add_shortcode( 'revo_portfolio_col_2', 'revo_portfolio_col_2_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_portfolio_col_2_func( $atts, $content ) {
	global $Revo_class;
	ob_start();
	extract( shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'heading' => '',
		'posts' => 0,
		'order' => 'DESC',
		'orderby' => 'date',
		'portfolio_category' => 'all',
		'class' => ' ',


	), $atts ) );


	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
	?>

    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="<?php echo esc_attr( $css_class ); ?>  showcase text-center section">

        <div class="container">
            <div class="row">
				<?php if ( isset( $heading{1} ) ) { ?>
                    <header class="col-md-8 col-md-offset-2">
                        <h2 class="section-title"><?php if ( isset( $heading{1} ) ) {
								echo esc_html( $heading );
							} ?></h2>

                        <div class="spacer spacer-primary">
                            <div class="line">
                                <div class="dot"></div>
                                <div class="dot"></div>
                                <div class="dot"></div>
                            </div>
                        </div>
                    </header>

				<?php } ?>
            </div>
            <ul class="filter">
                <li class="active"><a href="#" data-filter="*"> <?php esc_html_e( 'All', 'revo' ); ?></a></li>
				<?php $terms = get_terms( 'portfolio_categories', array( 'hide_empty' => true ) );
				foreach ( $terms as $v ) {

					?>
                    <li><a href="#"
                           data-filter=".<?php echo esc_attr( $v->slug ); ?>"><?php echo esc_html( $v->name ); ?></a>
                    </li>
					<?php

				}
				?>

            </ul>
        </div>

        <div class="section-content">
            <div class="container">
                <div class="row">

                    <div class="col-2 isotope isotope-padding js-gallery  <?php echo esc_attr( $class ); ?> ">
						<?php

						$rentit_new_arr = array(
							'posts_per_page' => $posts,
							'order' => $order,
							'orderby' => $orderby,
							'post_status' => 'publish',
							'post_type' => 'portfolio',
						);


						if ( $portfolio_category != 'all' ) {
							$str = $portfolio_category;
							$arr = explode( ',', $str );
							$rentit_new_arr['tax_query'][] = array(
								'taxonomy' => 'portfolio_categories',
								'field' => 'slug',
								'terms' => $arr
							);
						}


						$rentit_custom_query = new WP_Query( $rentit_new_arr );
						if ( $rentit_custom_query->have_posts() ):
							while ( $rentit_custom_query->have_posts() ) {
								$rentit_custom_query->the_post();


								$terms = get_the_terms( get_the_ID(), 'portfolio_categories' );


								?>
                                <div class="isotope-item  <?php
								if ( !empty( $terms ) ):
									foreach ( $terms as $v ) {
										echo esc_html( $v->slug . " " );
									}
								endif; ?>">
                                    <a href="<?php $Revo_class->get_post_thumbnail( get_the_ID(), 345, 244, true ); ?>"
                                       title="<?php the_title(); ?>">

                                        <figure class="showcase-item">
                                            <div class="showcase-item-thumbnail"><img alt=""
                                                                                      src="<?php $Revo_class->get_post_thumbnail( get_the_ID(), 600, 400, true ); ?>">
                                            </div>
                                            <figcaption class="showcase-item-hover">
                                                <div class="showcase-item-info">
													<?php
													foreach ( $terms as $v ) {

														?>

                                                        <div
                                                                class="showcase-item-category"> <?php echo esc_html( $v->name ); ?></div>
													<?php } ?>


                                                    <div class="showcase-item-title">  <?php the_title(); ?></div>
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </a>
                                </div>

								<?php

							}
							wp_reset_postdata();


						endif;
						?>

                    </div>
                </div>
            </div>
        </div>

    </section>


	<?php
	return ob_get_clean();

}


/*****about***************/

add_shortcode( 'revo_about_section', 'revo_about_section_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_about_section_func( $atts, $content ) {
	ob_start();

	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'items2' => '',
		'heading' => esc_html__( 'What we do', 'revo' ),
		'description' => esc_html__( 'The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo' ),
		'right_heading' => esc_html__( 'THE HOME OF CREATIVE DESIGNS', 'revo' ),
		'items' => '',
		'img_src' => '',
		't' => '',
		'd' => '',
		'left_heading' => '',
		'left_text' => '',
		'progresstitle' => esc_html__( 'DESIGN', 'revo' ),
		'progresssize' => '',
		'img_src2' => '',
	), $atts ) );

	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );


	$items_v = vc_param_group_parse_atts( $items );
	$items_v2 = vc_param_group_parse_atts( $items2 );

	if ( isset( $img_src[0] ) ) {
		$img = wp_get_attachment_image_src( $img_src, 'full' );


	}
	if ( isset( $img_src2[0] ) ) {
		$img2 = wp_get_attachment_image_src( $img_src2, 'full' );


	}


	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="about <?php echo esc_attr( $css_class ); ?> section pb-0">

        <div class="container">
            <div class="row">
                <header class="text-center col-md-8 col-md-offset-2">
					<?php if ( isset( $heading{1} ) ) { ?>
                        <h2 class="section-title"><?php echo esc_html( $heading ); ?></h2>
                        <div class="spacer spacer-primary">
                            <div class="line">
                                <div class="dot"></div>
                                <div class="dot"></div>
                                <div class="dot"></div>
                            </div>
                        </div>
					<?php } ?>
                    <p><?php if ( isset( $description{1} ) ) {
							echo wp_kses_post( $description );
						} ?></p>
                </header>
            </div>
        </div>
        <div class="section-content">
            <div class="row-about bgc-light clearfix">
                <div <?php if ( isset( $img[0] ) ) { ?> style="    background: url(<?php echo esc_url( $img[0] ); ?>) 100% 0 no-repeat;"
				<?php } ?> class="bg-about-1 bg-left-fluid bordered col-md-6"></div>
                <div class="col-about-right col-md-6 col-md-offset-6">

                    <h2 class="about-title"><?php if ( isset( $right_heading{1} ) ) {
							echo esc_html( $right_heading );
						} ?></h2>

                    <div class="col-about-content">
                        <div class="row row-columns">

							<?php if ( $items_v ):
								foreach ( $items_v as $item ) {
									?>

                                    <div class="column col-sm-6 col-md-12">
                                        <div class="media-left">
                    <span class="icon-circle-2 wow bounceIn">
                      <i class="fa <?php if ( isset( $item['icon'] ) ) {
	                      echo esc_attr( $item['icon'] );
                      } ?>"></i>
                    </span>
                                        </div>
                                        <div class="media-right">
                                            <h4 class="icon-title "><?php if ( isset( $item['t'] ) ) {
													echo esc_attr( $item['t'] );
												} ?></h4>

                                            <p><?php if ( isset( $item['d'] ) ) {
													echo esc_attr( $item['d'] );
												} ?></p>
                                        </div>
                                    </div>

									<?php
								}
							endif; ?>


                        </div>
                    </div>
                </div>
            </div>
            <div class="row-about bgc-light-md clearfix">


                <div <?php if ( isset( $img2[0] ) ) { ?> style="    background: url(<?php echo esc_url( $img2[0] ); ?>) 100% 0 no-repeat;"
				<?php } ?> class="bg-about-2 bg-right-fluid col-md-6"></div>


                <div class="col-about-left col-md-5 col-md-offset-1">
                    <h2 class="about-title"><?php if ( isset( $left_heading{1} ) ) {
							echo esc_html( $left_heading );
						} ?></h2>

                    <p><?php if ( isset( $left_text{1} ) ) {
							echo esc_html( $left_text );
						} ?></p>

                    <div class="col-about-content">

						<?php if ( $items_v2 ):
							foreach ( $items_v2 as $item2 ) {
								?>
                                <div
                                        class="progress-bar-title"><?php if ( isset( $item2 ['progresstitle'] ) ) {
										echo esc_attr( $item2 ['progresstitle'] );
									} ?></div>
                                <div class="progress">
                                    <div class="progress-bar"
                                         data-width="<?php if ( isset( $item2 ['progresssize'] ) ) {
										     echo esc_html( $item2 ['progresssize'] );
									     } ?>">
										<span><?php if ( isset( $item2 ['progresssize'] ) ) {
												echo esc_html( $item2 ['progresssize'] . '%' );
											} ?></span>
                                    </div>
                                </div>

								<?php
							}
						endif; ?>


                    </div>
                </div>
            </div>
        </div>
    </section>

	<?php
	return ob_get_clean();
}


/*****about2***************/

add_shortcode( 'revo_about_section2', 'revo_about_section2_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_about_section2_func( $atts, $content ) {
	ob_start();

	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'items2' => '',
		'heading' => esc_html__( 'What we do', 'revo' ),
		'description' => esc_html__( 'The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo' ),
		'right_heading' => esc_html__( 'THE HOME OF CREATIVE DESIGNS', 'revo' ),
		'items' => '',
		'images' => '',
		't' => '',
		'd' => '',
		'left_heading' => esc_html__( 'OUR EXPERTISE', 'revo' ),
		'left_text' => esc_html__( 'Aliquam et hendrerit nisi, viverra ultricies nisi. Nullam at dolor condimentum, venenatis ligula non, faucibus risus. Donec pretium leo interdum nibh commodo tempus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.', 'revo' ),
		'progresstitle' => esc_html__( 'DESIGN', 'revo' ),
		'progresssize' => '',
		'img_src2' => '',
	), $atts ) );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );
	$items_v = vc_param_group_parse_atts( $items );
	$items_v2 = vc_param_group_parse_atts( $items2 );

	global $Revo_class;


	$img_arr = wp_get_attachment_image_src( $images, 'full' );
	$img = $Revo_class->trim_img_by_url( $img_arr[0], 570, 650 );


	$img2 = wp_get_attachment_image_src( $img_src2, 'full' );


	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="bout <?php echo esc_attr( $css_class ); ?> section pb-0">

        <div class="container">
            <div class="row">
                <header class="text-center col-md-8 col-md-offset-2">
                    <h2 class="section-title"><?php if ( isset( $heading{1} ) ) {
							echo esc_html( $heading );
						} ?></h2>

                    <div class="spacer spacer-primary">
                        <div class="line">
                            <div class="dot"></div>
                            <div class="dot"></div>
                            <div class="dot"></div>
                        </div>
                    </div>
                    <p><?php if ( isset( $description{1} ) ) {
							echo wp_kses_post( $description );
						} ?></p></header>
            </div>
        </div>

        <div class="section-content">
            <div class="clearfix">
                <div class="col-md-6 col-lg-6 wow fadeInUp">
                    <div class="img-frame md-pull-right">
                        <img alt="" class="center-block img-responsive" src="<?php if ( isset( $img ) ) {
							;
						}
						echo esc_url( $img ); ?>">
                    </div>
                </div>
                <div class="col-about-margin col-md-6 col-lg-4">
                    <h2 class="about-title"><?php if ( isset( $right_heading{1} ) ) {
							echo esc_html( $right_heading );
						} ?></h2>

                    <div class="col-about-content">
                        <div class="row row-columns">
							<?php if ( $items_v ):
								foreach ( $items_v as $item ) {
									?>

                                    <div class="column col-sm-6 col-md-12">
                                        <div class="media-left">
                    <span class="icon-circle-2 wow bounceIn">
                        <i class="fa <?php if ( isset( $item['icon'] ) ) {
	                        echo esc_attr( $item['icon'] );
                        } ?>"></i>

                    </span>
                                        </div>
                                        <div class="media-right">
                                            <h4 class="icon-title "><?php if ( isset( $item['t'] ) ) {
													echo esc_attr( $item['t'] );
												} ?></h4>

                                            <p><?php if ( isset( $item['d'] ) ) {
													echo esc_attr( $item['d'] );
												} ?></p></div>
                                    </div>
									<?php
								}
							endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section-content">
                <div class="row-about bgc-light clearfix">
                    <div style="background: url(<?php if ( isset( $img2 ) ) {
						;
					}
					echo esc_url( $img2[0] ); ?>) center no-repeat;
                            background-size: cover;; "
                         class="bg-about-5 bg-right-fluid col-md-6"></div>


                    <div class="col-about-left col-md-5 col-md-offset-1">
                        <h2 class="about-title"><?php if ( isset( $left_heading{1} ) ) {
								echo esc_html( $left_heading );
							} ?></h2>

                        <p><?php if ( isset( $left_text{1} ) ) {
								echo esc_html( $left_text );
							} ?></p>

                        <div class="col-about-content">


							<?php if ( $items_v2 ):
								foreach ( $items_v2 as $item2 ) {
									?>
                                    <div
                                            class="progress-bar-title"><?php if ( isset( $item2 ['progresstitle'] ) ) {
											echo esc_attr( $item2 ['progresstitle'] );
										} ?></div>
                                    <div class="progress">
                                        <div class="progress-bar"
                                             data-width="<?php if ( isset( $item2 ['progresssize'] ) ) {
											     echo esc_html( $item2 ['progresssize'] );
										     } ?>">
											<span><?php if ( isset( $item2 ['progresssize'] ) ) {
													echo esc_html( $item2 ['progresssize'] . '%' );
												} ?></span>
                                        </div>
                                    </div>

									<?php
								}
							endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>


    </section>
	<?php
	return ob_get_clean();
}


/*****statistic***************/

add_shortcode( 'revo_statistic', 'revo_statistic_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_statistic_func( $atts, $content ) {
	ob_start();

	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'items' => '',
		'progresstitle' => esc_html__( 'DESIGN', 'revo' ),
		'progresssize' => '',
		'img_src2' => '',
		'class' => '',

	), $atts ) );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );

	$items_v = vc_param_group_parse_atts( $items );


	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"
	<?php } ?> class="statistic <?php echo esc_attr( $css_class ); ?>  <?php echo esc_attr( $class ); ?>">
        <div class="container">
            <div class="row row-columns">
				<?php if ( $items_v ):
					foreach ( $items_v as $item ) {
						?>
                        <div class="column col-sm-6 col-md-3">
                            <div class="counter">
                                <div class="counter-value"
                                     data-value="<?php if ( isset( $item ['progresssize'] ) ) {
									     echo esc_attr( $item ['progresssize'] );
								     } ?>"><?php if ( isset( $item ['progresssize'] ) ) {
										echo esc_html( $item ['progresssize'] );
									} ?></div>
                                <div
                                        class="counter-details"><?php if ( isset( $item ['progresstitle'] ) ) {
										echo esc_attr( $item ['progresstitle'] );
									} ?></div>
                            </div>
                        </div>
						<?php
					}
				endif; ?>
            </div>
        </div>

    </section>

	<?php
	return ob_get_clean();
}


/*********** team section****************/
class WPBakeryShortCode_revo_my_team extends WPBakeryShortCodesContainer {


}


add_shortcode( 'revo_my_team', 'revo_my_team_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_my_team_func( $atts, $content ) {
	ob_start();

	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'heading' => '',
		'slogan' => '',
		'description' => '',
		'headingcolor' => '',
		'heading_description' => '',
		'aftercolor' => '',
		'team_name_c' => '',
		'team_bio_c' => '',
		'team_social_c' => '',
		'team_name_spec_c' => '',


	), $atts ) );

	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );

	/*
     * colors
     */
	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="team text-center 	<?php echo esc_attr( $css_class ); ?>  section">
        <div class="container">
            <div class="row">
                <header class="col-md-8 col-md-offset-2">
					<?php if ( isset( $heading{1} ) ) { ?>
                        <h2 class="section-title "><?php echo esc_html( $heading ); ?></h2>
                        <div class="spacer spacer-primary">
                            <div class="line">
                                <div class="dot"></div>
                                <div class="dot"></div>
                                <div class="dot"></div>
                            </div>
                        </div>
					<?php } ?>
                </header>
            </div>
            <div class="section-content">
                <div class="container">
                    <div class="row-columns row">
						<?php echo do_shortcode( $content ); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
	<?php
	return ob_get_clean();
}


/*****team item***************/
add_shortcode( 'revo_team', 'revo_team_func' );

function revo_team_func( $atts, $content ) {
	ob_start();
	$content = !empty( $content ) ? $content : "";
	$atts = shortcode_atts(
		array(
			'h' => '',
			'sh' => '',
			'name' => '',
			'items' => '',
			'images' => '',
			'spec' => '',


		), $atts
	);
	extract( $atts );
	global $Revo_class;
	$tems_v = vc_param_group_parse_atts( $atts['items'] );

	$img_arr = wp_get_attachment_image_src( $images, 'full' );
	$img = $Revo_class->trim_img_by_url( $img_arr[0], 360, 409 );
	?>


    <div class="column col-sm-6 col-md-4">
        <figure class="team-profile">
            <div class="team-profile-img"><img alt="" src="<?php if ( isset( $img_arr[0] ) ) {
					echo esc_url( $img_arr[0] );
				} ?>"></div>
            <figcaption class="team-profile-hover">
                <div class="team-profile-info">


					<?php if ( $tems_v ) {
						?>
                        <div class="team-profile-social">
							<?php
							foreach ( $tems_v as $item ) { ?>
                                <a href="<?php if ( isset( $item['url']{0} ) ) {
									echo esc_url( $item['url'] );
								} ?>"
                                   class="fa <?php if ( isset( $item['icon']{1} ) ) {
									   echo esc_attr( $item['icon'] );
								   } ?>"></a>
							<?php }
							?>
                        </div>


					<?php }
					?>
                    <div class="team-profile-name"><?php echo esc_html( $name ); ?></div>
					<?php if ( isset( $spec{0} ) ) { ?>
                        <div class="team-profile-spec"><?php echo esc_html( $spec ); ?></div>
                        <div class="spacer spacer-white">
                            <div class="line">
                                <div class="dot"></div>
                                <div class="dot"></div>
                                <div class="dot"></div>
                            </div>
                        </div>
					<?php } ?>
                    <p class="team-profile-descr small"><?php echo esc_html( $content ); ?> </p>
                </div>
            </figcaption>
        </figure>
    </div>


	<?php
	return ob_get_clean();
}


/*
 * features
 */
add_shortcode( 'revo_features', 'revo_features_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_features_func( $atts, $content ) {
	ob_start();
	extract( shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'items' => '',
		'heading' => esc_html__( 'Why Choose US', 'revo' ),
		'h' => esc_html__( 'Modern Design', 'revo' ),
		'main_desc' => esc_html__( 'The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo' ),
		'desc' => esc_html__( 'Donec et egestas quam. Phasellus mattis dui et elementum consectetur. Etiam eu magna id lectus', 'revo' ),
		'icon' => '',


	), $atts ) );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
	$items_v = vc_param_group_parse_atts( $items );

	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>

            class="features	<?php echo esc_attr( $css_class ); ?>  section pt-0">
        <div class="container">
            <div class="row">
                <header class="text-center col-md-8 col-md-offset-2">
                    <h2 class="section-title"><?php if ( isset( $heading{0} ) ) {
							echo esc_html( $heading );
						} ?></h2>

                    <div class="spacer spacer-primary">
                        <div class="line">
                            <div class="dot"></div>
                            <div class="dot"></div>
                            <div class="dot"></div>
                        </div>
                    </div>
                    <p><?php if ( isset( $main_desc{0} ) ) {
							echo esc_html( $main_desc );
						} ?></p>
                </header>
            </div>
        </div>
        <div class="section-content">
            <div class="container">
                <div class="row row-columns">
					<?php if ( $items_v ):
						foreach ( $items_v as $item ) {
							?>

                            <div class="col-feature column col-sm-6 col-md-4">
                                <div class="media-left">
                                    <i class="text-primary icon-feature <?php if ( isset( $item['icon'] ) ) {
										echo( $item['icon'] );
									} ?>"></i>
                                </div>
                                <div class="media-right">
                                    <h3 class="icon-title"><?php if ( isset( $item['h'] ) ) {
											echo( $item['h'] );
										} ?></h3>

                                    <p class="feature-descr text-muted"><?php if ( isset( $item['desc'] ) ) {
											echo( $item['desc'] );
										} ?></p>
                                </div>
                            </div>

							<?php
						}
					endif; ?>

                </div>
            </div>
        </div>
    </section>


	<?php
	return ob_get_clean();

}


/*
 * features2
 */
add_shortcode( 'revo_features_2', 'revo_features_2_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_features_2_func( $atts, $content ) {
	ob_start();
	extract( shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'items' => '',
		'items2' => '',
		'heading' => esc_html__( 'Design Makes Everything Better', 'revo' ),
		'h' => esc_html__( 'MODERN DESIGN', 'revo' ),
		'main_desc' => esc_html__( 'The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo' ),
		'desc' => esc_html__( 'Donec et egestas quam. Phasellus mattis dui et elementum consectetur. Etiam eu magna id lectus', 'revo' ),
		'icon' => '',
		'images' => '',
		'delay' => '',
		'delay2' => '',
		'class' => '',
		'class2' => 'fadeInUp',
		'class3' => '',

	), $atts ) );
	$items_v2 = vc_param_group_parse_atts( $items2 );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
	$items_v = vc_param_group_parse_atts( $items );


	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="features <?php echo esc_attr( $css_class ); ?> section">
        <div class="container">
            <div class="row">

                <header class="text-center col-md-8 col-md-offset-2">
					<?php if ( isset( $heading{0} ) ) { ?>
                        <h2 class="section-title"><?php echo esc_html( $heading ); ?></h2>
                        <div class="spacer spacer-primary">
                            <div class="line">
                                <div class="dot"></div>
                                <div class="dot"></div>
                                <div class="dot"></div>
                            </div>
                        </div>
					<?php } ?>
                    <p><?php if ( isset( $main_desc{0} ) ) {
							echo esc_html( $main_desc );
						} ?></p>
                </header>
            </div>
        </div>
        <div class="section-content">
            <div class="container">
                <div class="row row-columns">


                    <div class="column col-md-4">
						<?php if ( $items_v ):
							foreach ( $items_v as $item ) {


								?>
                                <div class="feature-box-wrap">
                                    <div class="feature-box wow <?php echo esc_attr( $item['class'] ); ?>"
                                         data-wow-delay="<?php echo esc_attr( $item['delay'] ); ?>">
                                        <div class="media-left">
                                            <i class="text-primary icon-feature fa  <?php if ( isset( $item['icon'] ) ) {
												echo esc_attr( $item['icon'] );
											} ?>"></i>
                                        </div>
                                        <div class="media-right">
                                            <h3 class="icon-title"><?php if ( isset( $item['h'] ) ) {
													echo esc_html( $item['h'] );
												} ?></h3>

                                            <p class="feature-descr text-muted"><?php if ( isset( $item['desc'] ) ) {
													echo esc_html( $item['desc'] );
												} ?></p>
                                        </div>
                                    </div>

                                </div>

								<?php

							}
						endif; ?>
                    </div>
					<?php
					global $Revo_class;
					$img_arr = wp_get_attachment_image_src( $images, 'full' );
					$img = $Revo_class->trim_img_by_url( $img_arr[0], 360, 438 );

					if ( isset( $img{0} ) ) { ?>
                        <div class="column col-md-4 wow <?php echo esc_attr( $class2 ); ?>">
                            <img alt="" class="img-responsive" src="<?php if ( isset( $img ) ) {
								echo esc_attr( $img );
							} ?>">
                        </div>


						<?php

					}
					?>

                    <div class="column col-md-4">
						<?php if ( $items_v2 ):
							foreach ( $items_v2 as $item2 ) {


								?>
                                <div class="feature-box-wrap">
                                    <div class="feature-box wow <?php echo esc_attr( $item2['class3'] ); ?>"
                                         data-wow-delay="<?php echo esc_attr( $item2['wow'] ); ?>">
                                        <div class="media-left">
                                            <i class="text-primary icon-feature fa  <?php if ( isset( $item2['icon2'] ) ) {
												echo esc_attr( $item2['icon2'] );
											} ?>"></i>
                                        </div>
                                        <div class="media-right">
                                            <h3 class="icon-title"><?php if ( isset( $item2['h2'] ) ) {
													echo esc_html( $item2['h2'] );
												} ?></h3>

                                            <p class="feature-descr text-muted"><?php if ( isset( $item2['desc2'] ) ) {
													echo esc_html( $item2['desc2'] );
												} ?></p>
                                        </div>
                                    </div>

                                </div>

								<?php

							}
						endif; ?>
                    </div>

                </div>
            </div>
        </div>
    </section>


	<?php
	return ob_get_clean();

}


/*
 * revo reviews
 */

add_shortcode( 'revo_reviews', 'revo_reviews_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_reviews_func( $atts, $content ) {
	ob_start();
	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'title' => esc_html__( 'Our Testimonials', 'revo' ),
		'items' => '',
		'images' => '',
		'name' => esc_html__( 'Ana Blunt', 'revo' ),
		'desc' => esc_html__( ' Mauris aliquam risus id dui elementum accumsan. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse convallis eget ante sed pharetra. Fusce mollis diam eu libero pellentesque, eu venenatis erat viverra. Nunc iaculis maximus', 'revo' ),
		'spec' => esc_html__( 'Creative Director', 'revo' ),


	), $atts ) );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );

	?>


    <!-- Reviews -->


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>" <?php } ?>

            class="reviews text-white <?php echo esc_attr( $css_class ); ?>  text-center masked section parallax">
        <div class="container">
            <div class="row">
                <header class="col-md-8 col-md-offset-2">
                    <h2 class="text-white section-title"><?php echo esc_html( $title ) ?></h2>

                    <div class="spacer spacer-primary">
                        <div class="line">
                            <div class="dot"></div>
                            <div class="dot"></div>
                            <div class="dot"></div>
                        </div>
                    </div>
                </header>
            </div>
        </div>
        <div class="section-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="review-carousel dots-white js-review-carousel">
							<?php
							$tems_v = vc_param_group_parse_atts( $atts['items'] );
							foreach ( $tems_v as $item ) { ?>
                                <div class="review">
									<?php

									global $Revo_class;
									$img_arr = wp_get_attachment_image_src( $item['images'], 'full' );

									$img = $Revo_class->trim_img_by_url( $img_arr[0], 100, 100 );

									if ( isset( $img[0] ) ) {
										?>
                                        <div class="review-img"><img alt="" class="img-circle"
                                                                     src="<?php echo esc_url( $img ); ?>"></div>
										<?php

									}
									?>

                                    <h3 class="text-white review-name"><?php if ( isset( $item['name']{1} ) ) {
											echo wp_kses_post( $item['name'] );
										} ?></h3>
                                    <h4 class="review-spec"><?php if ( isset( $item['spec']{1} ) ) {
											echo wp_kses_post( $item['spec'] );
										} ?></h4>

                                    <p class="review-description">
										<?php if ( isset( $item['desc']{1} ) ) {
											echo wp_kses_post( $item['desc'] );
										} ?></p>
                                </div>
							<?php }
							?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

	<?php
	return ob_get_clean();
}

/*
 * revo reviews2
 */

add_shortcode( 'revo_reviews_2', 'revo_reviews_2_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */

function revo_reviews_2_func( $atts, $content ) {
	ob_start();
	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'title' => esc_html__( 'Our Testimonials', 'revo' ),
		'items' => '',
		'images' => '',
		'name' => esc_html__( 'Ana Blunt', 'revo' ),
		'desc' => esc_html__( ' Mauris aliquam risus id dui elementum accumsan. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse convallis eget ante sed pharetra. Fusce mollis diam eu libero pellentesque, eu venenatis erat viverra. Nunc iaculis maximus', 'revo' ),
		'spec' => esc_html__( 'Creative Director', 'revo' ),


	), $atts ) );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), '', $atts );
	?>


    <!-- Reviews -->


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>" <?php } ?>

            class="reviews-2 <?php echo esc_attr( $css_class ); ?>  text-center section">
        <div class="container">
            <div class="row">
                <header class="col-md-8 col-md-offset-2">
                    <h2 class=" section-title"><?php echo esc_html( $title ) ?></h2>

                    <div class="spacer spacer-primary">
                        <div class="line">
                            <div class="dot"></div>
                            <div class="dot"></div>
                            <div class="dot"></div>
                        </div>
                    </div>
                </header>
            </div>
        </div>
        <div class="section-content">
            <div class="container">
                <div class="review-carousel-2 js-review-carousel-2">


					<?php
					$tems_v = vc_param_group_parse_atts( $atts['items'] );
					foreach ( $tems_v as $item ) { ?>
                        <div class="review">
							<?php

							global $Revo_class;
							$img_arr = wp_get_attachment_image_src( $item['images'], 'full' );

							$img = $Revo_class->trim_img_by_url( $img_arr[0], 100, 100 );

							if ( isset( $img[0] ) ) {
								?>
                                <div class="review-img"><img alt="" class="img-circle"
                                                             src="<?php echo esc_url( $img ); ?>"></div>
								<?php

							}
							?>

                            <h3 class=" review-name"><?php if ( isset( $item['name']{1} ) ) {
									echo wp_kses_post( $item['name'] );
								} ?></h3>
                            <h4 class="review-spec"><?php if ( isset( $item['spec']{1} ) ) {
									echo wp_kses_post( $item['spec'] );
								} ?></h4>

                            <p class="review-description">
								<?php if ( isset( $item['desc']{1} ) ) {
									echo wp_kses_post( $item['desc'] );
								} ?></p>
                        </div>
					<?php }
					?>


                </div>
            </div>
        </div>

    </section>

	<?php
	return ob_get_clean();
}


/*
 * revo reviews3
 */

add_shortcode( 'revo_reviews_3', 'revo_reviews_3_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */

function revo_reviews_3_func( $atts, $content ) {
	ob_start();
	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'title' => esc_html__( 'Our Testimonials', 'revo' ),
		'items' => '',
		'images' => '',
		'name' => esc_html__( 'Ana Blunt', 'revo' ),
		'desc' => esc_html__( ' Mauris aliquam risus id dui elementum accumsan. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse convallis eget ante sed pharetra. Fusce mollis diam eu libero pellentesque, eu venenatis erat viverra. Nunc iaculis maximus', 'revo' ),
		'spec' => esc_html__( 'Creative Director', 'revo' ),


	), $atts ) );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), '', $atts );
	?>


    <!-- Reviews -->


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>" <?php } ?>

            class="reviews-2 <?php echo esc_attr( $css_class ); ?> text-center section">
        <div class="container">
            <div class="row">
                <header class="col-md-8 col-md-offset-2">
                    <h2 class="section-title"><?php echo esc_html( $title ) ?></h2>

                    <div class="spacer spacer-primary">
                        <div class="line">
                            <div class="dot"></div>
                            <div class="dot"></div>
                            <div class="dot"></div>
                        </div>
                    </div>
                </header>
            </div>
        </div>
        <div class="section-content">
            <div class="container">
                <div class="review-carousel-3 js-review-carousel">
					<?php
					$tems_v = vc_param_group_parse_atts( $atts['items'] );
					foreach ( $tems_v as $item ) { ?>

                        <div class="review">

							<?php

							global $Revo_class;
							$img_arr = wp_get_attachment_image_src( $item['images'], 'full' );

							$img = $Revo_class->trim_img_by_url( $img_arr[0], 540, 293 );

							if ( isset( $img[0] ) ) {
								?>
                                <div class="col-md-6">
                                    <div class="review-img"><img alt="" class="img-responsive"
                                                                 src="<?php echo esc_url( $img ); ?>"></div>
                                </div>
                                <div class="col-review-text col-md-6">
                                    <h3 class="review-name"><?php if ( isset( $item['name']{1} ) ) {
											echo wp_kses_post( $item['name'] );
										} ?></h3>
                                    <h4 class="review-spec"><?php if ( isset( $item['spec']{1} ) ) {
											echo wp_kses_post( $item['spec'] );
										} ?></h4>

                                    <p class="review-description"><?php if ( isset( $item['desc']{1} ) ) {
											echo wp_kses_post( $item['desc'] );
										} ?> </p>
                                </div>

								<?php

							}
							?>
                        </div>

					<?php }
					?>


                </div>
            </div>
        </div>
    </section>
	<?php
	return ob_get_clean();
}


/**********price table**********/

add_shortcode( 'revo_price_table', 'revo_price_table_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_price_table_func( $atts, $content ) {
	global $Revo_class;
	ob_start();
	//var_dump($atts);
	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'heading' => '',
		'description' => '',
		'items' => '',
		'heading_description' => '',

	), $atts ) );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );

	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="prices text-center <?php echo esc_attr( $css_class ); ?>  section">
        <div class="container">
            <div class="row">
                <header class="col-md-8 col-md-offset-2">
                    <h2 class="section-title"><?php if ( isset( $heading{1} ) ) {
							echo esc_html( $heading );
						} ?></h2>

                    <div class="spacer spacer-primary">
                        <div class="line">
                            <div class="dot"></div>
                            <div class="dot"></div>
                            <div class="dot"></div>
                        </div>
                    </div>
                    <p><?php if ( isset( $description{1} ) ) {
							echo wp_kses_post( $description );
						} ?></p>
                </header>
            </div>
            <div class="section-content">
                <div class="row-price ">
					<?php
					/*
                     * price tables
                     */


					$tems_v = vc_param_group_parse_atts( $atts['items'] );


					foreach ( $tems_v as $att ) {
						$att = shortcode_atts(
							array(
								'currency' => esc_html__( '$', 'revo' ),
								'h' => '',
								'sh' => '',
								'price' => '',
								'period' => esc_html__( 'Per Month', 'revo' ),
								'tb' => esc_html__( 'Select plan', 'revo' ),
								'tbh' => esc_html__( 'Order Now', 'revo' ),
								'css' => '',
								'items' => '',
								'class' => '',
								'icon' => '',
								'url' => '#',


							), $att
						);
						$css_class_n = '';
						$tems_text_list_ = vc_param_group_parse_atts( $att['items'] );
						extract( $att );
						if ( $att['class'] == 'ADVANCED' ) {
							$css_class_n = ' ' . 'leading  wow flipInY ';
						}


						?>
                        <div class="<?php echo esc_attr( $css_class_n ); ?> col-price col-sm-6 col-md-3">
                            <div class="price-box">
                                <div class="price-body">
                                    <div class="price-header">
                                        <h4 class="price-title"><?php echo esc_html( $h ); ?></h4>

                                        <div class="price">
                                            <span class="price-currency"><?php echo esc_html( $currency ); ?></span>
                                            <span class="price-amount"><?php echo esc_html( $price ); ?></span>

                                            <div class="price-period"><?php echo esc_html( $period ); ?></div>
                                        </div>
                                    </div>
                                    <div class="price-features">
										<?php if ( $tems_text_list_ ): ?>
                                            <ul>
												<?php
												foreach ( $tems_text_list_ as $item ) {
													?>

                                                    <li>
                                                        <i class="fa <?php if ( isset( $item['icon'] ) ) {
															echo wp_kses_post( $item['icon'] );
														} ?>"></i>
														<?php if ( isset( $item['title'] ) ) {
															echo wp_kses_post( $item['title'] );
														} ?>
                                                    </li>
													<?php
												}
												?>
                                            </ul>
										<?php endif; ?>

                                        <a href="<?php echo esc_url( $url ); ?>"
                                           class="btn  hvr-pulse-grow"><?php echo esc_html( $tbh ); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>

						<?php
					}
					?>


                </div>
            </div>
        </div>
    </section>


	<?php
	return ob_get_clean();

}


/**********blog**********/

add_shortcode( 'revo_blog_section', 'revo_blog_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_blog_func( $atts, $content ) {
	global $Revo_class;
	ob_start();
	//var_dump($atts);
	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'count' => esc_html__( '3', 'revo' ),
		'description' => esc_html__( 'The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo' ),
		'title' => esc_html__( 'Our blog', 'revo' ),
		'posts' => 0,
		'order' => 'DESC',
		'orderby' => 'date',
		'blog_category' => '',


	), $atts ) );


	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );
	$args = array(
		'post_type' => 'post',
		'category_name' => $blog_category,
		'post_status' => 'publish',
		'posts_per_page' => $count,
		'order' => $order,
		'orderby' => $orderby,
		'ignore_sticky_posts' => true,
		'meta_query' => array( array( 'key' => '_thumbnail_id' ) )

	);

	?>


    <section id="blog" class="blog <?php echo esc_attr( $css_class ); ?>  text-center section pt-0">
        <div class="container">
            <div class="row">
                <header class="col-md-8 col-md-offset-2">
                    <h2 class="section-title"><?php esc_html_e( $title ); ?></h2>

                    <div class="spacer spacer-primary">
                        <div class="line">
                            <div class="dot"></div>
                            <div class="dot"></div>
                            <div class="dot"></div>
                        </div>
                    </div>
                    <p><?php esc_html_e( $description ); ?></p>
                </header>
            </div>


            <div class="section-content">
                <div class="row row-columns">
					<?php
					$revo_query = new WP_Query( $args );

					$j = 1;


					if ( $revo_query->have_posts() ):
						while ( $revo_query->have_posts() ) {
							$revo_query->the_post();
							$main_class = 'wow fadeInLeft';
							if ( $j % 2 == 0 ) {
								$main_class = ' wow fadeInUp';
							}
							if ( $j % 3 == 0 ) {
								$main_class = 'wow fadeInRight';
							}

							if ( get_post_format() == 'gallery' ) {

								?>
                                <div class="b-grid-item">
                                    <div class="post column col-sm-6 col-md-4 <?php echo esc_attr( $main_class ); ?>">
                                        <div class="blog-article">
                                            <div class="blog-article-thumbnail">
												<?php revo_post_gallery_slide( 360, 360 ); ?>
                                                <div class="date"><?php
													echo wp_kses_post( implode( '<br/>', explode( ' ', get_the_time( 'd M' ) ) ) );
													?></div>
                                            </div>
                                            <div class="blog-article-details">
                                                <h3 class="blog-article-title"><?php the_title(); ?></h3>
                                                <h4 class="blog-article-category">
													<?php $category = get_the_category();
													if ( isset( $category[0]->cat_name ) ) {
														echo esc_html( $category[0]->cat_name );
													} ?></h4>
                                                <a href="<?php echo esc_url( get_the_permalink() ); ?>"
                                                   class="read-more"> <?php echo esc_html( get_theme_mod( 'revo_blog_list_text', esc_html__( 'Read More', 'revo' ) ) ); ?>
                                                    <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								<?php

							} elseif ( get_post_format() == 'video' ) {
								?>
                                <div class="b-grid-item">
                                    <div <?php post_class( 'post column col-sm-6 col-md-4 ' . $main_class, '' ); ?> >
                                        <div class="blog-article">

                                            <div class="blog-article-thumbnail">
												<?php revo_theme_oembed_videos(); ?>
                                                <div class="date"><?php
													echo wp_kses_post( implode( '<br/>', explode( ' ', get_the_time( 'd M' ) ) ) );
													?></div>
                                            </div>
                                            <div class="blog-article-details">
                                                <h3 class="blog-article-title"><?php the_title(); ?></h3>
                                                <h4 class="blog-article-category">
													<?php $category = get_the_category();
													if ( isset( $category[0]->cat_name ) ) {
														echo esc_html( $category[0]->cat_name );
													} ?></h4>
                                                <a href="<?php echo esc_url( get_the_permalink() ); ?>"
                                                   class="read-more"> <?php echo esc_html( get_theme_mod( 'revo_blog_list_text', esc_html__( 'Read More', 'revo' ) ) ); ?>
                                                    <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								<?php

							} else {
								?>
                                <div class="b-grid-item">
                                    <div <?php post_class( 'post column col-sm-6 col-md-4  ' . $main_class, '' ); ?> >
                                        <div class="blog-article">
                                            <div class="blog-article-thumbnail">
												<?php revo_post_thumbnail(); ?>
                                                <div class="date"><?php
													echo wp_kses_post( implode( '<br/>', explode( ' ', get_the_time( 'd M' ) ) ) );
													?></div>
                                            </div>
                                            <div class="blog-article-details">
                                                <h3 class="blog-article-title"><?php the_title(); ?></h3>
                                                <h4 class="blog-article-category">
													<?php $category = get_the_category();
													if ( isset( $category[0]->cat_name ) ) {
														echo esc_html( $category[0]->cat_name );
													} ?></h4>
                                                <a href="<?php echo esc_url( get_the_permalink() ); ?>"
                                                   class="read-more"> <?php echo esc_html( get_theme_mod( 'revo_blog_list_text', esc_html__( 'Read More', 'revo' ) ) ); ?>
                                                    <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								<?php
							}


							?>


							<?php
							$j ++;
							/*if ($j == 4)
                                $j = 1;*/
						}
						wp_reset_postdata();
					endif; ?>

                </div>
            </div>
        </div>
    </section>


	<?php
	return ob_get_clean();

}


add_shortcode( 'revo_contact_section', 'revo_contact_section_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_contact_section_func( $atts, $content ) {
	ob_start();

	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'heading' => '',
		'addres_heading' => '',
		'heading_description' => '',
		'aftercolor' => '',
		'address_items' => '',
		'name' => esc_html__( 'Name ', 'revo' ),
		'Email' => esc_html__( 'Email address *', 'revo' ),
		'sm' => esc_html__( 'Send message', 'revo' ),
		'message' => esc_html__( 'Write message *', 'revo' ),


	), $atts ) );

	$address_items = (array) vc_param_group_parse_atts( $address_items );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"
	<?php } ?> class="contact <?php echo esc_attr( $css_class ); ?>  text-white masked section">
        <div class="container">
            <header class="text-center col-md-8 col-md-offset-2">
				<?php if ( isset( $heading{1} ) ) { ?>
                    <h2 class="text-white section-title"><?php echo esc_html( $heading ); ?></h2>
                    <div class="spacer spacer-primary">
                        <div class="line">
                            <div class="dot"></div>
                            <div class="dot"></div>
                            <div class="dot"></div>
                        </div>
                    </div>

				<?php } ?>
            </header>
        </div>
        <div class="section-content">
            <div class="container rel-1">
                <div class="row row-columns">
					<?php if ( $address_items ) {
						?>

                        <div class="column col-md-4 col-md-push-8">
							<?php

							foreach ( $address_items as $item ) {
								?>
                                <div class="contact-row">
                                    <div class="media-left">
                  <span class="icon-circle-3">
                    <i class="fa <?php if ( isset( $item['addres_icon'] ) ) {
	                    echo esc_attr( $item['addres_icon'] );
                    } ?>"></i>
                  </span>
                                    </div>
                                    <div class="media-right">
                                        <h4 class="text-white icon-title"><?php if ( isset( $item['addres_heading'] ) ) {
												echo esc_html( $item['addres_heading'] );
											} ?></h4>

                                        <p> <?php if ( isset( $item['addres_desc'] ) ) {
												echo wp_kses_post( $item['addres_desc'] );
											} ?></p>
                                    </div>
                                </div>
								<?php
							} ?>

                        </div>

						<?php
					} ?>
                    <div class="column col-md-8 col-md-pull-4">
                        <form class="js-ajax-form">
                            <div class="form-group">
                                <input type="text" class="form-control form-control-white" name="name"
                                       placeholder="<?php echo esc_attr( $name ); ?>">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control form-control-white" name="email" required
                                       placeholder="<?php echo esc_attr( $Email ); ?>">
                            </div>
                            <div class="form-group">
                                <textarea class="form-control form-control-white" name="message" required
                                          placeholder="<?php echo esc_attr( $message ); ?>"></textarea>
                            </div>
                            <div class="text-center">
                                <button type="submit"
                                        class="btn btn-b-white wow swing"><?php echo esc_html( $sm ); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

	<?php
	return ob_get_clean();
}


add_shortcode( 'revo_contact_section_2', 'revo_contact_section_2_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_contact_section_2_func( $atts, $content ) {
	ob_start();

	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'heading' => esc_html__( 'CONTACT US ', 'revo' ),
		'addres_heading' => '',
		'heading_description' => '',
		'aftercolor' => '',
		'address_items' => '',
		'social_icon' => '',
		'name' => esc_html__( 'Name ', 'revo' ),
		'Email' => esc_html__( 'Email address *', 'revo' ),
		'sm' => esc_html__( 'Send message', 'revo' ),
		'message' => esc_html__( 'Write message *', 'revo' ),
		'phone' => esc_html__( 'Phone', 'revo' ),
		'social_url' => '',


	), $atts ) );
	$address_items = vc_param_group_parse_atts( $atts['address_items'] );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );

	?>
    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>

            class="contact-2 <?php echo esc_attr( $css_class ); ?>  section pt-0">
        <div class="container">
            <header class="text-center col-md-8 col-md-offset-2">
                <h2 class="section-title"><?php if ( isset( $heading{1} ) ) {
						echo esc_html( $heading );
					} ?></h2>

                <div class="spacer spacer-primary">
                    <div class="line">
                        <div class="dot"></div>
                        <div class="dot"></div>
                        <div class="dot"></div>
                    </div>
                </div>
            </header>
        </div>
        <div class="section-content">
            <div class="container">
                <form class="js-ajax-form">
                    <div class="form-group">
                        <div class="row-form row">
                            <div class="col-form col-md-4"><input type="text" class="form-control" name="name"
                                                                  placeholder="<?php echo esc_attr( $name ); ?>"></div>
                            <div class="col-form col-md-4"><input type="text" class="form-control" name="email" required
                                                                  placeholder="<?php echo esc_attr( $Email ); ?>"></div>
                            <div class="col-form col-md-4"><input type="text" class="form-control" name="phone"
                                                                  placeholder="<?php echo esc_attr( $phone ); ?>"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" name="message" required
                                  placeholder="<?php echo esc_attr( $message ); ?>"></textarea>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-b-dark wow swing"><?php echo esc_html( $sm ); ?></button>
                    </div>
                </form>
				<?php if ( $address_items ) {
					?>
                    <div class="social-round social">
						<?php

						foreach ( $address_items as $item ) {


							?>

                            <a href="<?php if ( isset( $item['social_url'] ) ) {
								echo esc_url( $item['social_url'] );
							} ?>">
                                <i class="fa   <?php if ( isset( $item['social_icon'] ) ) {
									echo esc_attr( $item['social_icon'] );
								} ?>"></i>
                            </a>
							<?php

						} ?>


                    </div>
					<?php
				} ?>
            </div>
        </div>
    </section>


	<?php
	return ob_get_clean();
}


/**
 * Partners
 */
add_shortcode( 'revo_partners', 'revo_partners_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_partners_func( $atts, $content ) {
	ob_start();
	$content = !empty( $content ) ? $content : "";
	$atts = shortcode_atts(
		array(
			'items' => '',
			'images' => '',
			'section_id' => '',
			'css' => '',
			'h' => esc_html__( 'Our Partners', 'vanessa' ),

		), $atts
	);
	extract( $atts );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );

	$arr_img = explode( ',', $images );

	?>

    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="partners text-center section <?php echo esc_attr( $css_class ); ?> ">
        <div class="container">
            <div class="row">
                <header class="col-md-8 col-md-offset-2">
                    <h2 class="section-title"><?php echo esc_html( $h ); ?></h2>

                    <div class="spacer spacer-primary">
                        <div class="line">
                            <div class="dot"></div>
                            <div class="dot"></div>
                            <div class="dot"></div>
                        </div>
                    </div>
                </header>
            </div>
        </div>
        <div class="section-content">
            <div class="container">
                <div class="partners-carousel">
					<?php
					foreach ( $arr_img as $item ) { ?>

                        <div class="partner">
							<?php
							$img_arr = wp_get_attachment_image_src( $item, 'revo_163-40' );
							$img = @$img_arr[0];

							?>

                            <img alt="" src="<?php echo esc_url( $img ); ?>">
                        </div>
					<?php }
					?>

                </div>
            </div>
        </div>
    </section>

	<?php
	return ob_get_clean();
}


/******** End New SHORTCODES ****************/


add_shortcode( 'revo_header_slider', 'revo_header_slider_func' );
function revo_header_slider_func( $atts, $content ) {
	ob_start();
	$content = !empty( $content ) ? $content : "";

	$atts = shortcode_atts(
		array(
			'section_id' => '',
			'alias_slider' => '',


		), $atts
	);

	extract( $atts );


	?>


    <main <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>" <?php } ?> class="main">
        <div class="rev_slider_wrapper">
            <div id="rev_slider" class="rev_slider fullscreenbanner" data-version="5.0.7">


				<?php if ( isset( $img_src[0] ) ) {
					$img = wp_get_attachment_image_src( $img_src, 'full' );

					?>
                    <img src="<?php echo esc_url( $img ); ?>" alt="" data-lazyload="<?php echo esc_url( $img[0] ); ?>"
                         data-bgposition="center top" data-kenburns="on" data-duration="20000"
                         data-ease="Power1.easeOut" data-scalestart="120" data-scaleend="100" class="rev-slidebg"
                         data-no-retina>
					<?php
				} ?>


				<?php

				if ( $alias_slider != '' ) {
					echo do_shortcode( '[rev_slider alias="' . $alias_slider . '"][/rev_slider]' );
				} ?>


            </div>

        </div>

    </main>

	<?php
	return ob_get_clean();
}


/****banner***************/

add_shortcode( 'revo_banner', 'revo_banner_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_banner_func( $atts, $content ) {
	ob_start();

	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'items' => '',
		'title' => '',
		'url' => '',
		'bt' => '',

	), $atts ) );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );


	?>

    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"
	<?php } ?> class="banner-section bgc-primary text-white <?php echo esc_attr( $css_class ); ?>">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h2 class="text-white"><?php echo esc_html( $title ); ?></h2>
                </div>
                <div class="col-md-4 text-right-md">
                    <a href="<?php echo esc_html( $url ); ?>"
                       class="btn btn-b-white wow swing"><?php echo esc_html( $bt ); ?></a>
                </div>
            </div>
        </div>
    </section>


	<?php
	return ob_get_clean();
}


/*****about1***************/

add_shortcode( 'revo_about_progressbar', 'revo_about_progressbar_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_about_progressbar_func( $atts, $content ) {
	ob_start();

	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'items2' => '',
		'items' => '',
		't' => '',
		'd' => '',
		'left_heading' => '',
		'left_text' => '',
		'progresstitle' => esc_html__( 'DESIGN', 'revo' ),
		'progresssize' => '',
		'img_src2' => '',
	), $atts ) );

	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );


	$items_v2 = vc_param_group_parse_atts( $items2 );


	if ( isset( $img_src2[0] ) ) {
		$img2 = wp_get_attachment_image_src( $img_src2, 'full' );


	}


	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"
	<?php } ?> class="about section <?php echo esc_attr( $css_class ); ?>   pb-0">
        <div class="row-about bgc-light clearfix">


            <div <?php if ( isset( $img2[0] ) ) { ?> style="    background: url(<?php echo esc_url( $img2[0] ); ?>) 100% 0 no-repeat;"
			<?php } ?> class="bg-about-2 bg-right-fluid bordered col-md-6"></div>


            <div class="col-about-left col-md-5 col-md-offset-1">

                <h2 class="about-title"><?php if ( isset( $left_heading{1} ) ) {
						echo esc_html( $left_heading );
					} ?></h2>

                <p><?php if ( isset( $left_text{1} ) ) {
						echo esc_html( $left_text );
					} ?> </p>

                <div class="col-about-content">
					<?php if ( $items_v2 ):
						foreach ( $items_v2 as $item2 ) {
							?>
                            <div
                                    class="progress-bar-title"><?php if ( isset( $item2 ['progresstitle'] ) ) {
									echo esc_attr( $item2 ['progresstitle'] );
								} ?></div>
                            <div class="progress">
                                <div class="progress-bar"
                                     data-width="<?php if ( isset( $item2 ['progresssize'] ) ) {
									     echo esc_html( $item2 ['progresssize'] );
								     } ?>">
									<span><?php if ( isset( $item2 ['progresssize'] ) ) {
											echo esc_html( $item2 ['progresssize'] . '%' );
										} ?></span>
                                </div>
                            </div>

							<?php
						}
					endif; ?>

                </div>
            </div>
        </div>
    </section>
	<?php
	return ob_get_clean();
}


/**
 * about part  with icons
 */

add_shortcode( 'revo_about_icon', 'revo_about_icon_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_about_icon_func( $atts, $content ) {
	ob_start();

	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'items2' => '',
		'heading' => esc_html__( 'What we do', 'revo' ),
		'description' => esc_html__( 'The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo' ),
		'right_heading' => esc_html__( 'THE HOME OF CREATIVE DESIGNS', 'revo' ),
		'items' => '',
		'images' => '',
		't' => '',
		'd' => '',
		'left_heading' => '',
		'left_text' => '',
		'progresstitle' => esc_html__( 'DESIGN', 'revo' ),
		'progresssize' => '',
		'img_src2' => '',
		'style' => '',
	), $atts ) );

	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );


	$items_v = vc_param_group_parse_atts( $items );


	if ( isset( $images[0] ) ) {
		$img = wp_get_attachment_image_src( $images, 'full' );


	}


	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"
	<?php } ?> class="about section <?php echo esc_attr( $css_class ); ?>">
        <div class="container">
            <div class="row">

				<?php if ( $atts['style'] == false ) { ?>
                    <header class="text-center col-md-8 col-md-offset-2">
                        <h2 class="section-title"><?php if ( isset( $heading{1} ) ) {
								echo esc_html( $heading );
							} ?></h2>

                        <div class="spacer spacer-primary">
                            <div class="line">
                                <div class="dot"></div>
                                <div class="dot"></div>
                                <div class="dot"></div>
                            </div>
                        </div>
                        <p><?php if ( isset( $description{1} ) ) {
								echo wp_kses_post( $description );
							} ?></p>
                    </header>
				<?php } ?>

            </div>
        </div>
        <div class="section-content">
            <div class="row-about bgc-light clearfix">
                <div <?php if ( isset( $img[0] ) ) { ?> style="    background: url(<?php echo esc_url( $img[0] ); ?>) 100% 0 no-repeat;"
				<?php } ?> class="bg-about-1 bg-left-fluid bordered col-md-6"></div>
                <div class="col-about-right col-md-6 col-md-offset-6">
                    <h2 class="about-title"><?php if ( isset( $right_heading{1} ) ) {
							echo esc_html( $right_heading );
						} ?></h2>

                    <div class="col-about-content">

						<?php if ( $items_v ):
							foreach ( $items_v as $item ) {
								?>
                                <div class="row row-columns">
                                    <div class="column col-sm-6 col-md-12">
                                        <div class="media-left">
                    <span class="icon-circle-2 wow bounceIn">
                      <i class="fa <?php if ( isset( $item['icon'] ) ) {
	                      echo esc_attr( $item['icon'] );
                      } ?>"></i>
                    </span>
                                        </div>
                                        <div class="media-right">
                                            <h4 class="icon-title "><?php if ( isset( $item['t'] ) ) {
													echo esc_attr( $item['t'] );
												} ?></h4>

                                            <p><?php if ( isset( $item['d'] ) ) {
													echo esc_attr( $item['d'] );
												} ?></p>
                                        </div>
                                    </div>

                                </div>

								<?php
							}
						endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


	<?php
	return ob_get_clean();
}

/*
*  Home
*
*/


add_shortcode( 'revo_home', 'revo_home_func' );
function revo_home_func( $atts, $content ) {
	ob_start();
	$content = !empty( $content ) ? $content : "";
	$atts = shortcode_atts(
		array(
			't' => '',
			'd' => '',
			'class' => '',
			'css' => '',


		), $atts

	);

	extract( $atts );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );

	?>


    <main <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="main masked <?php echo esc_attr( $css_class ); ?>  <?php echo esc_attr( $class ); ?>  parallax"
            data-stellar-background-ratio="0.7">
        <div class="opener">
            <div class="container">
                <div class="row">
                    <h1><?php echo esc_html( $t ); ?></h1>

                    <h2><?php echo esc_html( $d ); ?></h2>
                </div>
            </div>
        </div>
    </main>


	<?php
	return ob_get_clean();
}

/*****about with small img***************/

add_shortcode( 'revo_about_small_img', 'revo_about_small_img_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_about_small_img_func( $atts, $content ) {
	ob_start();

	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'items2' => '',
		'heading' => esc_html__( 'What we do', 'revo' ),
		'description' => esc_html__( 'The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo' ),
		'about_heading' => esc_html__( 'THE HOME OF CREATIVE DESIGNS', 'revo' ),
		'items' => '',
		'images' => '',
		't' => '',
		'd' => '',
		'main_heading' => '',
		'main_description' => '',


	), $atts ) );
	extract( $atts );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
	$items_v = vc_param_group_parse_atts( $items );


	global $Revo_class;


	$img_arr = wp_get_attachment_image_src( $images, 'full' );
	$img = $Revo_class->trim_img_by_url( $img_arr[0], 570, 650 );


	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="about <?php echo esc_attr( $css_class ); ?> section">
        <div class="container">
            <div class="row">
                <header class="text-center col-md-8 col-md-offset-2">
					<?php if ( isset( $main_heading{0} ) ) { ?>
                        <h2 class="section-title"><?php echo esc_html( $main_heading ) ?></h2>
                        <div class="spacer spacer-primary">
                            <div class="line">
                                <div class="dot"></div>
                                <div class="dot"></div>
                                <div class="dot"></div>
                            </div>
                        </div>
					<?php } ?>
                    <p><?php echo esc_html( $main_description ) ?></p>
                </header>
            </div>
        </div>
        <div class="section-content">

            <div class="clearfix">
                <div class="col-md-6 col-lg-6 wow fadeInLeft">
					<?php if ( isset( $img{1} ) ) { ?>
                        <div class="img-frame md-pull-right">
                            <img alt="" class="center-block img-responsive" src="<?php echo esc_url( $img ); ?>"></div>
					<?php } ?>
                </div>
                <div class="col-about-margin col-md-6 col-lg-4">
                    <h2 class="about-title"><?php if ( isset( $about_heading{1} ) ) {
							echo esc_html( $about_heading );
						} ?></h2>

                    <div class="col-about-content">
                        <div class="row row-columns">
							<?php if ( $items_v ):
								foreach ( $items_v as $item ) {
									?>
                                    <div class="column col-sm-6 col-md-12">
                                        <div class="media-left">
                  <span class="icon-circle-2 wow bounceIn">
                    <i class="fa <?php if ( isset( $item['icon'] ) ) {
	                    echo esc_attr( $item['icon'] );
                    } ?>"></i>
                  </span>
                                        </div>
                                        <div class="media-right">
                                            <h4 class="icon-title "><?php if ( isset( $item['t'] ) ) {
													echo esc_attr( $item['t'] );
												} ?></h4>

                                            <p><?php if ( isset( $item['d'] ) ) {
													echo esc_attr( $item['d'] );
												} ?></p>
                                        </div>
                                    </div>
									<?php
								}
							endif; ?>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
	<?php
	return ob_get_clean();
}


/*
*  Features 2
*/


add_shortcode( 'revo_about_3', 'revo_about_3_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_about_3_func( $atts, $content ) {


	ob_start();
	$content = !empty( $content ) ? $content : "";
	$atts = shortcode_atts(
		array(
			't' => esc_html__( 'We Are Awesome Web Agency', 'revo' ),
			'd' => esc_html__( ' The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo' ),
			'class' => 'fadeInUp',
			'icon' => '',
			'items' => '',
			'ts' => esc_html__( 'Branding', 'revo' ),
			'ds' => esc_html__( 'Maecenas mattis est eget efficitur tempus. Maecenas fermentum fringilla vestibulum. Nulla pulvinar ullamcorper auctor', 'revo' ),
			'section_id' => '',
			'wow_delay' => '',
			'css' => '',


		), $atts

	);

	extract( $atts );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );

	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="features <?php echo esc_attr( $css_class ); ?> text-center section">
        <div class="container">
            <div class="row row-columns">
				<?php
				$items_v = vc_param_group_parse_atts( $atts['items'] );
				if ( $items_v ) {
					foreach ( $items_v as $item ) {

						?>

                        <div class="feature-column column col-md-6 col-lg-4">
            <span class="icon-circle-2">
              <i class="fa <?php echo esc_attr( ( $item['icon'] ) ); ?>"></i>
            </span>

                            <h3 class="icon-title"><?php if ( isset( $item['ts'] ) ) {
									echo esc_html( $item['ts'] );
								} ?></h3>

                            <div class="spacer">
                                <div class="line">
                                    <div class="dot"></div>
                                    <div class="dot"></div>
                                    <div class="dot"></div>
                                </div>
                            </div>
                            <p class="small text-muted"><?php if ( isset( $item['ds'] ) ) {
									echo esc_html( $item['ds'] );
								} ?></p>
                        </div>

					<?php }
				}
				?>
            </div>
        </div>
    </section>
	<?php
	return ob_get_clean();
}


/*****Accordion section ***************/
class WPBakeryShortCode_revo_accordion_section extends WPBakeryShortCodesContainer {


}

add_shortcode( 'revo_accordion_section', 'revo_accordion_section_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_accordion_section_func( $atts, $content ) {
	ob_start();

	extract( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'items2' => '',
		'heading' => esc_html__( 'What we do', 'revo' ),
		'description' => esc_html__( 'The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo' ),
		'right_heading' => esc_html__( 'THE HOME OF CREATIVE DESIGNS', 'revo' ),
		'items' => '',
		'images' => '',
		't' => '',
		'd' => '',
		'left_heading' => esc_html__( 'OUR EXPERTISE', 'revo' ),
		'left_text' => esc_html__( 'Aliquam et hendrerit nisi, viverra ultricies nisi. Nullam at dolor condimentum, venenatis ligula non, faucibus risus. Donec pretium leo interdum nibh commodo tempus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.', 'revo' ),
		'progresstitle' => esc_html__( 'DESIGN', 'revo' ),
		'progresssize' => '',
		'img_src2' => '',
		'about_title' => '',


	), $atts ) );
	extract( $atts );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );

	$items_v2 = vc_param_group_parse_atts( $items2 );

	global $Revo_class;


	$img_arr = wp_get_attachment_image_src( $images, 'full' );
	$img = $Revo_class->trim_img_by_url( $img_arr[0], 650, 650 );

	if ( isset( $img_src2[0] ) ) {
		$params = array( 'width' => 960, 'height' => 650, 'crop' => true );
		$img2 = wp_get_attachment_image_src( $img_src2, 'full' );


	}
	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="bout <?php echo esc_attr( $css_class ); ?>  section pb-0">

        <div class="container">
            <div class="row">
                <header class="text-center col-md-8 col-md-offset-2">
					<?php if ( isset( $heading{1} ) ) { ?>
                        <h2 class="section-title"><?php echo esc_html( $heading ); ?></h2>
                        <div class="spacer spacer-primary">
                            <div class="line">
                                <div class="dot"></div>
                                <div class="dot"></div>
                                <div class="dot"></div>
                            </div>
                        </div>
					<?php } ?>
                    <p><?php if ( isset( $description{1} ) ) {
							echo wp_kses_post( $description );
						} ?></p></header>
            </div>
        </div>

        <div class="section-content">
            <div class="clearfix">
				<?php if ( isset( $img[0] ) ) { ?>
                    <div class="col-about-img col-md-6 col-lg-6 wow fadeInLeft">
                        <div class="img-frame md-pull-right"><img alt=""
                                                                  class="md-pull-right center-block img-responsive"
                                                                  src="<?php echo esc_url( $img ); ?>"></div>
                    </div>
				<?php } ?>
                <div class="col-about-margin col-md-6 col-lg-4">
                    <h2 class="about-title"><?php echo esc_html( $about_title ); ?>  </h2>

                    <div class="col-about-content">
                        <div class="panel-group" id="accordion1">
							<?php echo do_shortcode( $content ); ?>
                        </div>
                    </div>
                </div>
            </div>


            <div class="section-content">
                <div class="row-about bgc-light clearfix">
                    <div <?php if ( isset( $img2[0] ) ) { ?> style="background: url(<?php echo esc_url( $img2[0] ); ?>) center no-repeat;
                            background-size: cover;; "
					<?php } ?> class="bg-about-4 bg-right-fluid col-md-6"></div>


                    <div class="col-about-left col-md-5 col-md-offset-1">
                        <h2 class="about-title"><?php if ( isset( $left_heading{1} ) ) {
								echo esc_html( $left_heading );
							} ?></h2>

                        <p><?php if ( isset( $left_text{1} ) ) {
								echo esc_html( $left_text );
							} ?></p>

                        <div class="col-about-content">


							<?php if ( $items_v2 ):
								foreach ( $items_v2 as $item2 ) {
									?>
                                    <div
                                            class="progress-bar-title"><?php if ( isset( $item2 ['progresstitle'] ) ) {
											echo esc_attr( $item2 ['progresstitle'] );
										} ?></div>
                                    <div class="progress">
                                        <div class="progress-bar"
                                             data-width="<?php if ( isset( $item2 ['progresssize'] ) ) {
											     echo esc_html( $item2 ['progresssize'] );
										     } ?>">
											<span><?php if ( isset( $item2 ['progresssize'] ) ) {
													echo esc_html( $item2 ['progresssize'] . '%' );
												} ?></span>
                                        </div>
                                    </div>

									<?php
								}
							endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>


    </section> <?php
	return ob_get_clean();
}


/*
 * Revo accordion item
 */
add_shortcode( 'revo_accordion_item', 'revo_accordion_item_function' );
function revo_accordion_item_function( $atts, $content ) {
	$content = !empty( $content ) ? $content : "";
	$atts = shortcode_atts(
		array(
			'title' => '',
			'des' => '',
			'images' => '',
			'heading' => '',
			'name' => '',
			'class' => '',


		), $atts
	);
	ob_start();
	global $Revo_class;


	$img_arr = wp_get_attachment_image_src( $atts['images'], 'full' );
	$img = $Revo_class->trim_img_by_url( $img_arr[0], 100, 100 );

	STATIC $revo_acirdion_section = 1;
	$aria_expanded = 'false';
	if ( ( $atts['class'] ) == 'in' ) {
		$aria_expanded = 'true';
	}


	?>

    <!-- faq -->
    <!-- /faq-->

    <div class="panel">
        <div class="panel-heading">
            <h6 class="panel-title">
                <a data-toggle="collapse" data-parent="#accordion1"
                   href="#collapse<?php echo (int) $revo_acirdion_section; ?>-1"
                   aria-expanded="<?php echo esc_html( $aria_expanded ) ?>"
                   class=""><?php echo esc_html( $atts['title'] ); ?></a>
            </h6>
        </div>
        <div id="collapse<?php echo (int) $revo_acirdion_section; ?>-1" class="panel-collapse collapse
        <?php echo esc_attr( $atts['class'] ); ?>  ">
            <div class="panel-body">
                <div class="media-left">
					<?php if ( isset( $img[0] ) ) { ?>
                        <img alt="" src="<?php echo esc_url( $img ); ?>">
					<?php } ?>
                </div>
                <div class="media-right">
                    <h3 class="panel-body-title"><?php echo esc_html( $atts['name'] ); ?></h3>

                    <p><?php echo wp_kses_post( ( $content ) ); ?>
                    </p>
                </div>

            </div>
        </div>
    </div>


	<?php
	$revo_acirdion_section ++;

	return ob_get_clean();
}

/*
 * Revo image section
 */
add_shortcode( 'revo_image_section', 'revo_image_section_function' );
function revo_image_section_function( $atts, $content ) {
	$content = !empty( $content ) ? $content : "";
	$atts = shortcode_atts(
		array(
			'title' => '',
			'des' => '',
			'images' => '',
			'heading' => '',
			'url' => '',
			'bt' => '',
			'section_id' => '',
			'css' => '',

		), $atts
	);
	extract( $atts );
	ob_start();
	global $Revo_class;


	$img_arr = wp_get_attachment_image_src( $atts['images'], 'full' );
	$img = $Revo_class->trim_img_by_url( $img_arr[0], 555, 482 );

	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );


	?>


    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="image-section <?php echo esc_attr( $css_class ); ?> section pt-0">
        <div class="container">
            <div class="row row-columns">
                <div class="column col-md-6">
                    <h2 class="title-lg"><?php echo esc_html( $title ); ?></h2>

                    <p><?php echo esc_html( $des ); ?></p>
                    <a href="<?php echo esc_url( $url ); ?>" class="btn wow swing"><?php echo esc_html( $bt ); ?></a>
                </div>
                <div class="column col-md-6 wow fadeInRight">
                    <img alt="" class="img-responsive" src="<?php echo esc_url( $img ); ?>">
                </div>
            </div>
        </div>
    </section>


	<?php

	return ob_get_clean();
}

/**
 * Contacts map
 */

add_shortcode( 'revo_map', 'revo_map_func' );

/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_map_func( $atts, $content ) {

	ob_start();

	if ( isset( $atts['images']{0} ) ) {
		$img_arr = wp_get_attachment_image_src( $atts['images'], 'full' );
		if ( isset( $img_arr[0] ) ) {
			$atts['images'] = $img_arr[0];
		}

	}
	$content = !empty( $content ) ? $content : "";
	$atts = shortcode_atts(
		array(

			'text' => '',
			'section_id' => '',
			'h' => '',
			'd' => '',
			'images' => '',
			'lat' => '45.200',
			'lng' => '-71.4310',
			'st2' => '',
			'zoom' => 8,
			'email' => esc_html__( 'Email address *', 'revo' ),
			'phone' => esc_html__( 'Phone', 'revo' ),
			'name' => esc_html__( 'Name', 'revo' ),
			'items' => '',
			'message' => esc_html__( 'Write message *', 'revo' ),
			'submit' => esc_html__( 'Send message', 'revo' ),
			'icon' => '',
			't' => '',
			'css' => '',
			'map_items' => '',
			'map_visibility' => '1',
			'contact_items' => '',
			'map_url' => '',
			'map_url_t' => '',
			'map_items' => '',
		), $atts
	);


	extract( $atts );

	$contact_items = vc_param_group_parse_atts( $atts['contact_items'] );
	$map_items = vc_param_group_parse_atts( $atts['map_items'] );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );


	?>

    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class=" <?php echo esc_attr( $css_class ); ?> section">
        <div class="container">
            <form class="js-ajax-form">
                <div class="form-group">
                    <div class="row-form row">
                        <div class="col-form col-md-4">
                            <input type="text" class="form-control" name="name"
                                   placeholder="<?php if ( isset( $name ) ) {
								       echo( $name );
							       } ?>">
                        </div>
                        <div class="col-form col-md-4">
                            <input type="text" class="form-control" name="email" required
                                   placeholder="<?php if ( isset( $email ) ) {
								       echo( $email );
							       } ?>">
                        </div>
                        <div class="col-form col-md-4">
                            <input type="text" class="form-control" name="phone"
                                   placeholder="<?php if ( isset( $phone ) ) {
								       echo( $phone );
							       } ?>">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <textarea class="form-control" name="message" required
                              placeholder="<?php if ( isset( $message ) ) {
	                              echo( $message );
                              } ?> "></textarea>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn wow swing"><?php if ( isset( $submit ) ) {
							echo( $submit );
						} ?></button>
                </div>
            </form>
        </div>

		<?php
		if ( $map_visibility != '2' ) { ?>

            <div id="map" data-lat="<?php echo esc_attr( $lat ); ?>"
                 data-lng="<?php echo esc_attr( $lng ); ?>"
                 class="map"><?php if ( $images != '' ) {
					?>
                    <div class="map-title">
                        <h3><img alt="" width="140" src="<?php echo esc_url( $images ); ?>"></h3>
                    </div>
					<?php
				} ?>
				<?php if ( $map_items ) {
					foreach ( $map_items as $item ) {
						?>
                        <div class="map-address-row">
							<?php if ( isset( $item['icon'] ) && $item['icon'] != '' ): ?>
                                <i class="<?php echo esc_attr( $item['icon'] ); ?>"></i>
							<?php endif; ?>
							<?php if ( isset( $item['content'] ) && $item['content'] != '' ): ?>

                                <span class="text"><?php echo wp_kses_post( $item['content'] ); ?></span>

							<?php endif; ?>
                        </div>
						<?php
					}

				} ?>

				<?php if ( $map_url && $map_url_t ) { ?>
                    <p class="gmap-open">
                        <a
                                href="<?php echo esc_url( $map_url ); ?>"
                                target="_blank"><?php echo wp_kses_post( $map_url_t ); ?></a></p>

				<?php } ?>
            </div>
		<?php $map_style = get_theme_mod( 'revo_map_stylemap_json', '[]' );

		if ( strlen( str_replace( ' ', '', $map_style ) ) < 5 ) {
			$map_style = '[]';
		}
		?>
            <script>


                /************/
                function initialize() {
                    mapLocation = new google.maps.LatLng(parseFloat(<?php echo esc_attr( $lat ); ?>), parseFloat(<?php echo esc_attr( $lng ); ?>));

                    var mapOptions = {
                        zoom: <?php echo (int) $zoom; ?>, // Change zoom here
                        center: mapLocation,
                        scrollwheel: false,
                        styles: <?php echo wp_kses_post( $map_style ); ?>
                    };
                    var contentString = '<div class="map-info">' + jQuery("#map").html() + '</div>';

                    map = new google.maps.Map(document.getElementById('map'),
                        mapOptions);


                    //change address details here


                    var infowindow = new google.maps.InfoWindow({
                        content: contentString
                    });


                    marker = new google.maps.Marker({
                        map: map,
                        draggable: true,
                        title: 'Revo', //change title here
                        animation: google.maps.Animation.DROP,
                        position: mapLocation
                    });

                    google.maps.event.addListener(marker, 'click', function () {
                        infowindow.open(map, marker);
                    });


                }

            </script>
		<?php } ?>


        <div class="contact-address">
            <div class="container">
                <div class="row">
					<?php if ( $contact_items ) {
						foreach ( $contact_items as $item ) {
							?>
                            <div class="col-md-4">
                                <div class="contact-address-item">
                <span class="icon-address icon-circle-3 dark">
                  <i class="fa <?php if ( isset( $item['icon'] ) ) {
	                  echo esc_attr( ( $item['icon'] ) );
                  } ?>"></i>
                </span>
                                    <h4 class="icon-title"><?php if ( isset( $item['h'] ) ) {
											echo wp_kses_post( $item['h'] );
										} ?></h4>

                                    <p><?php if ( isset( $item['d'] ) ) {
											echo wp_kses_post( $item['d'] );
										} ?></p>
                                </div>
                            </div>
							<?php
						}

					} ?>

                </div>
            </div>
        </div>
    </section>
    <!--oldsspdr-->

	<?php

	return ob_get_clean();
}

/**
 * Contacts map2
 */

add_shortcode( 'revo_map2', 'revo_map2_func' );

/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_map2_func( $atts, $content ) {

	ob_start();

	if ( isset( $atts['images']{0} ) ) {
		$img_arr = wp_get_attachment_image_src( $atts['images'], 'full' );
		if ( isset( $img_arr[0] ) ) {
			$atts['images'] = $img_arr[0];
		}

	}
	$content = !empty( $content ) ? $content : "";
	$atts = shortcode_atts(
		array(

			'text' => '',
			'section_id' => '',
			'h' => '',
			'd' => '',
			'images' => '',
			'lat' => '45.200',
			'lng' => '-71.4310',
			'st2' => '',
			'zoom' => 8,
			'email' => esc_html__( 'Email address *', 'revo' ),
			'phone' => esc_html__( 'Name', 'revo' ),
			'name' => esc_html__( 'Phone', 'revo' ),
			'items' => '',
			'message' => esc_html__( 'Write message *', 'revo' ),
			'submit' => esc_html__( 'Send message', 'revo' ),
			'icon' => '',
			't' => '',
			'css' => '',
			'map_items' => '',
			'map_visibility' => '1',
			'contact_items' => '',
			'social' => '',
			'url' => '',
			'map_url' => '',
			'map_url_t' => '',
			'map_items' => '',

		), $atts
	);


	extract( $atts );
	$items_v = vc_param_group_parse_atts( $atts['social'] );
	$contact_items = vc_param_group_parse_atts( $atts['contact_items'] );
	$map_items = vc_param_group_parse_atts( $atts['map_items'] );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );


	?>

    <section <?php if ( isset( $section_id{0} ) ) { ?> id="<?php echo esc_attr( $section_id ); ?>"  <?php } ?>
            class="contact-2 <?php echo esc_attr( $css_class ); ?> section">
        <div class="container">

            <div class="row row-columns">

                <div class="column col-md-4 col-md-push-8">
					<?php if ( $contact_items ) {
						foreach ( $contact_items as $item ) {
							?>
                            <div class="contact-row">
                                <div class="media-left">
                  <span class="icon-circle-3 dark">
                           <i class="fa <?php if ( isset( $item['icon'] ) ) {
	                           echo esc_attr( ( $item['icon'] ) );
                           } ?>"></i>
                  </span>
                                </div>
                                <div class="media-right">
                                    <h4 class="icon-title"><?php if ( isset( $item['h'] ) ) {
											echo wp_kses_post( $item['h'] );
										} ?></h4>

                                    <p><?php if ( isset( $item['d'] ) ) {
											echo wp_kses_post( $item['d'] );
										} ?></p>
                                </div>
                            </div>
							<?php
						}

					} ?>
                </div>

                <div class="column col-md-8 col-md-pull-4">
                    <form class="js-ajax-form" novalidate="novalidate">
                        <div class="form-group">
                            <input type="text" class="form-control" name="name"
                                   placeholder="<?php if ( isset( $name ) ) {
								       echo( $name );
							       } ?>">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="email" required=""
                                   placeholder="<?php if ( isset( $phone ) ) {
								       echo( $phone );
							       } ?>">
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" name="message" required=""
                                      placeholder="<?php if ( isset( $message ) ) {
	                                      echo( $message );
                                      } ?>"></textarea>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-b-dark wow swing"
                                    style="visibility: hidden; animation-name: none;"><?php if ( isset( $submit ) ) {
									echo( $submit );
								} ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
		<?php
		if ( $map_visibility != '2' ) { ?>

            <div id="map" data-lat="<?php echo esc_attr( $lat ); ?>"
                 data-lng="<?php echo esc_attr( $lng ); ?>"
                 class="map"><?php if ( $images != '' ) {
					?>
                    <div class="map-title">
                        <h3><img alt="" width="140" src="<?php echo esc_url( $images ); ?>"></h3>
                    </div>
					<?php
				} ?>
				<?php if ( $map_items ) {
					foreach ( $map_items as $item ) {
						?>
                        <div class="map-address-row">
							<?php if ( isset( $item['icon'] ) && $item['icon'] != '' ): ?>
                                <i class="<?php echo esc_attr( $item['icon'] ); ?>"></i>
							<?php endif; ?>
							<?php if ( isset( $item['content'] ) && $item['content'] != '' ): ?>

                                <span class="text"><?php echo wp_kses_post( $item['content'] ); ?></span>

							<?php endif; ?>
                        </div>
						<?php
					}

				} ?>

				<?php if ( $map_url && $map_url_t ) { ?>
                    <p class="gmap-open">
                        <a
                                href="<?php echo esc_url( $map_url ); ?>"
                                target="_blank"><?php echo wp_kses_post( $map_url_t ); ?></a></p>

				<?php } ?>
            </div>
		<?php $map_style = get_theme_mod( 'revo_map_stylemap_json', '[]' );

		if ( strlen( str_replace( ' ', '', $map_style ) ) < 5 ) {
			$map_style = '[]';
		}
		?>
            <script>


                /************/
                function initialize() {
                    mapLocation = new google.maps.LatLng(parseFloat(<?php echo esc_attr( $lat ); ?>), parseFloat(<?php echo esc_attr( $lng ); ?>));

                    var mapOptions = {
                        zoom: <?php echo (int) $zoom; ?>, // Change zoom here
                        center: mapLocation,
                        scrollwheel: false,
                        styles: <?php echo wp_kses_post( $map_style ); ?>
                    };
                    //change address details here
                    var contentString = '<div class="map-info">'
                        + jQuery("#map").html() +
                        '</div>';
                    map = new google.maps.Map(document.getElementById('map'),
                        mapOptions);


                    var infowindow = new google.maps.InfoWindow({
                        content: contentString
                    });


                    marker = new google.maps.Marker({
                        map: map,
                        draggable: true,
                        title: 'Revo', //change title here
                        animation: google.maps.Animation.DROP,
                        position: mapLocation
                    });

                    google.maps.event.addListener(marker, 'click', function () {
                        infowindow.open(map, marker);
                    });


                }

            </script>
		<?php } ?>
        <div class="social-round social">
			<?php if ( $items_v ) {
				foreach ( $items_v as $item ) {
					?>
                    <a href="<?php if ( isset( $item['url'] ) ) {
						echo esc_url( $item['url'] );
					} ?>"><i
                                class="fa <?php if ( isset( $item['fa'] ) ) {
									echo esc_attr( $item['fa'] );
								} ?>"></i></a>
					<?php
				}

			} ?>
        </div>
    </section>

	<?php

	return ob_get_clean();
}


add_shortcode( 'revo_contact_form', 'revo_contact_form_func' );

/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_contact_form_func( $atts, $content ) {
	ob_start();

	$content = !empty( $content ) ? $content : "";
	$atts = shortcode_atts(
		array(
			'items' => '',
			'name' => esc_html__( 'Name *', 'revo' ),
			'Email' => esc_html__( 'Email *', 'revo' ),
			'sm' => esc_html__( 'Send request', 'revo' ),
			'message' => esc_html__( 'Message', 'revo' ),


		), $atts
	);

	extract( $atts );
	?>

    <form class="form-request js-ajax-form">
        <div class="row-fields row">
            <div class="form-group col-field col-sm-6">
                <input type="text" class="form-control form-control-white" name="name" required
                       placeholder="<?php echo esc_attr( $name ); ?>">
            </div>
            <div class="form-group col-field col-sm-6">
                <input type="email" class="form-control form-control-white" name="email" required
                       placeholder="<?php echo esc_attr( $Email ); ?>">
            </div>
            <div class="form-group col-field col-sm-12">
                            <textarea class="form-control form-control-white" rows="3" name="message"
                                      placeholder="<?php echo esc_attr( $message ); ?>"></textarea>
            </div>
            <div class="col-sm-12">
                <button type="submit" class="btn btn-hvr-white hvr-pulse-grow" data-text-hover="Submit">
					<?php echo esc_html( $sm ); ?>
                </button>
            </div>
        </div>
    </form>

	<?php
	return ob_get_clean();
}


add_shortcode( 'revo_portfolio_new_update', 'revo_portfolio_new_update_func' );
/**
 * @param $atts
 * @param $content
 *
 * @return string
 */
function revo_portfolio_new_update_func( $atts, $content ) {
	ob_start();

	( $atts = shortcode_atts( array(
		'section_id' => '',
		'css' => '',
		'cat' => '',
		'class' => '',
		'items' => '',
		'img_src' => '',
		'title' => '',
		'image_items' => '',
		'slug' => '',
		'col' => '',
		'size' => '',
		'filter' => '',
		'heading' => esc_html__( 'OUR PORTFOLIO', 'revo' ),

	), $atts ) );


	$items = vc_param_group_parse_atts( $atts['items'] );
	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $atts['css'], ' ' ), '', $atts );

	?>


    <section id="showcase"
             class="showcase text-center <?php echo esc_attr( $atts['class'] ); ?> <?php echo esc_attr( $css_class ); ?>  ">
        <div class="container">


			<?php if ( isset( $atts['heading']{1} ) ) { ?>
                <div class="row">
                    <header class="col-md-8 col-md-offset-2">
                        <h2 class="section-title"><?php if ( $atts['heading'] ) {
								echo esc_html( $atts['heading'] );
							} ?></h2>

                        <div class="spacer spacer-primary">
                            <div class="line">
                                <div class="dot"></div>
                                <div class="dot"></div>
                                <div class="dot"></div>
                            </div>
                        </div>
                    </header>
                </div>
			<?php } ?>


            <ul class=" filter <?php if ( isset( $atts['filter'] ) ) {
				echo esc_attr( $atts['filter'] );
			} ?> ">
                <li class="active"><a href="#" data-filter="*"><?php esc_html_e( 'All', 'revo' ); ?></a></li>
				<?php
				if ( isset ( $items  [0] ) ) {
					foreach ( $items as $v1 ) {

						if ( isset( $v1['cat']{2} ) ) {

							?>
                            <li><a href="#"
                                   data-filter=".<?php echo esc_attr( $v1['slug'] ); ?>"><?php echo esc_html( $v1['cat'] ); ?></a>
                            </li>
							<?php
						}
					}
				}
				?>

            </ul>
        </div>
        <div class="section-content">
			<?php
			$container = ' ';
			$row = ' ';
			$col = $atts['col'];
			if ( $col == 'col-3' ) {
				$col = 'col-3 isotope-padding';
				$container = ' ';
				$row = ' ';
			} elseif ( $col == 'col-2 ' ) {
				$col = 'col-2  isotope-padding ';
				$container = 'container';
				$row = 'row';
			} elseif ( $col == 'padding ' ) {
				$col = 'isotope-padding';
				$container = ' ';
				$row = ' ';
			}

			?>


            <div class="<?php echo esc_attr( $container ); ?>">
                <div class="<?php echo esc_attr( $row ); ?>">

                    <div class="isotope js-gallery <?php echo esc_attr( $col ); ?> ">

						<?php

						if ( isset ( $items[0] ) ) {
							foreach ( $items as $t ) {


								$image_items = vc_param_group_parse_atts( $t['image_items'] );
								$slug = $t['slug'];


								if ( $image_items ) {

									foreach ( $image_items as $img ) {

										if ( isset( $img['img_src']{1} ) ) {

											$img_arr = wp_get_attachment_image_src( $img['img_src'], 'full' );

											?>
                                            <div
                                                    class="isotope-item <?php echo esc_attr( $slug ); ?> <?php if ( isset( $img['size']{0} ) ) {
														echo esc_attr( $img['size'] );
													} ?>  ">
                                                <a href="<?php if ( isset( $img_arr[0] ) ) {
													;
												}
												echo esc_url( $img_arr[0] ); ?>"
                                                   title="<?php if ( isset( $t ['title'] ) ) {

													   echo esc_html( $t ['title'] );
												   } ?>">
                                                    <figure class="showcase-item">

                                                        <div class="showcase-item-thumbnail"><img alt=""
                                                                                                  src="<?php if ( isset( $img_arr[0] ) ) {
															                                          echo esc_url( $img_arr[0] );
														                                          }
														                                          ?>">
                                                        </div>


                                                        <figcaption class="showcase-item-hover">
                                                            <div class="showcase-item-info">
                                                                <div
                                                                        class="showcase-item-category"><?php if ( isset( $t ['cat'] ) ) {
																		;
																	}
																	echo esc_html( $t ['cat'] ); ?></div>
                                                                <div
                                                                        class="showcase-item-title"><?php if ( isset( $t ['title'] ) ) {

																		echo esc_html( $t ['title'] );
																	} ?></div>
                                                            </div>
                                                        </figcaption>
                                                    </figure>
                                                </a>
                                            </div>

											<?php
										}
									}

								}
							}
						}
						?>
                    </div>
                </div>
            </div>
        </div>
    </section>


	<?php
	return ob_get_clean();
}

