<?php
/**
 * Custom functions that act independently of the theme templates
 *
 * Eventually, some of the functionality here could be replaced by core features
 *
 * @package revo
 */
/* HEADER ------------------------------------------- */
function revo_custom_styling() { ?>
	<?php if ( function_exists( 'ot_get_option' ) ) : ?>
		<style>
			<?php if( is_customize_preview('administrator')): ?>
			.logged-in .navbar.affix, .logged-in .navbar {
				top: 0px;
			}

			<?php endif; ?>

			<?php if ( ot_get_option( 'revo_navigationbg' ) !='' ): ?>
			.navbar.affix {
				background-color: <?php echo esc_attr( ot_get_option( 'revo_navigationbg' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_navitem' ) !='' ): ?>
			.navbar-nav > li > a {
				color: <?php echo esc_attr( ot_get_option( 'revo_navitem' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_navitemhover' ) !='' ): ?>
			.navbar-nav > li > a:hover, .navbar-nav > li > a:focus, .navbar-nav > .active > a {
				color: <?php echo esc_attr( ot_get_option( 'revo_navitemhover' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_navigationbg' ) !='' ): ?>
			@media (max-width: 767px) {
				.navbar-nav li a:hover,
				.navbar-nav .active > a,
				.navbar.affix .navbar-nav li > a:hover,
				.navbar.affix .navbar-nav .active > a {
					color: <?php echo esc_attr( ot_get_option( 'revo_navigationbg' ) ); ?>;
				}

			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_sidebarwidgettitlecolor' ) !='' ): ?>
			.widget-title {

				color: <?php echo esc_attr( ot_get_option( 'revo_sidebarwidgettitlecolor' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_sidebarwidgetgeneralcolor' ) !='' ): ?>
			.widget ul {
				color: <?php echo esc_attr( ot_get_option( 'revo_sidebarwidgetgeneralcolor' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_sidebarlinkcolor' ) !='' ): ?>
			.widget ul li a {
				color: <?php echo esc_attr( ot_get_option( 'revo_sidebarlinkcolor' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_sidebarlinkhovercolor' ) !='' ): ?>
			.widget ul li a:hover {
				color: <?php echo esc_attr( ot_get_option( 'revo_sidebarlinkhovercolor' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_sidebarsearchsubmittextcolor' ) !='' ): ?>
			.search-form {
				color: <?php echo esc_attr( ot_get_option( 'revo_sidebarsearchsubmittextcolor' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_sidebarsearchsubmitbgcolor' ) !='' ): ?>
			.form-control:focus, .form-control-sm:focus {
				border-color: <?php echo esc_attr( ot_get_option( 'revo_sidebarsearchsubmitbgcolor' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_logosize' ) !='' &&  ot_get_option( 'revo_logosize' ) != '100'): ?>
			.brand {
				font-size: <?php echo esc_attr( ot_get_option( 'revo_logosize' ) ); ?>px;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_blogheaderbgcolor' ) !='' ): ?>
			.revo_blog_page .main-blog, .revo_blog_page .main-blog.masked:before {
				background-color: <?php echo esc_attr( ot_get_option( 'revo_blogheaderbgcolor' ) ); ?>;

			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_blogheaderbgcolor_single' ) !='' ): ?>
			.revo_blog_single .main-blog, .revo_blog_single .main-blog.masked:before {
				background-color: <?php echo esc_attr( ot_get_option( 'revo_blogheaderbgcolor_single' ) ); ?>;

			}

			<?php endif; ?>

			<?php if ( ot_get_option('revo_mask_c_page_header_single') == 'off') : ?>
			.revo_blog_single .main-blog {
				background-image: none !important;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_blogheaderbgheight' ) !=''  &&   ot_get_option( 'revo_blogheaderbgheight' ) !='50'): ?>
			.single .masked {
				height: <?php echo esc_attr( ot_get_option( 'revo_blogheaderbgheight' ) ); ?>vh !important;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_blogheaderpaddingtop' ) !=''
			&& ot_get_option( 'revo_blogheaderpaddingtop' ) !='250'
			 ): ?>
			@media (min-width: 768px) {
				.revo_blog_page .opener {

					padding-top: <?php echo esc_attr( ot_get_option( 'revo_blogheaderpaddingtop' ) ); ?>px !important;
					padding-bottom: <?php echo esc_attr( ot_get_option( 'revo_blogheaderpaddingbottom' ) ); ?>px !important;
				}
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_blogheadingcolor' ) !='' ): ?>
			.revo_blog_page .masked h1 {
				color: <?php echo esc_attr( ot_get_option( 'revo_blogheadingcolor' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_blogsubtitlecolor' ) !='' ): ?>
			.revo_blog_page .masked h2 {
				color: <?php echo esc_attr( ot_get_option( 'revo_blogsubtitlecolor' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_m_c' ) !='' ): ?>
			.masked:before {
				background-color: <?php echo esc_attr( ot_get_option( 'revo_m_c' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option('revo_mask') == 'off') : ?>
			.masked:before {
				display: none;
			}

			<?php endif; ?>
			<?php if ( ot_get_option('revo_mask_c_page_header') == 'off') : ?>
			.revo_blog_page .main-blog {
				background-image: none !important;
			}

			<?php endif; ?>

			<?php if ( ot_get_option( 'revo_singleheadingcolor' ) !='' ): ?>
			.single .masked h1 {
				color: <?php echo esc_attr( ot_get_option( 'revo_singleheadingcolor' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_singleheaderparagraphcolor' ) !='' ): ?>
			.single .masked h2 {
				color: <?php echo esc_attr( ot_get_option( 'revo_singleheaderparagraphcolor' ) ); ?> !important;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_singleheaderbgheight' ) !='' && ot_get_option( 'revo_singleheaderbgheight' ) !='50' ): ?>
			.revo_blog_single .masked {
				height: <?php echo esc_attr( ot_get_option( 'revo_singleheaderbgheight' ) ); ?>vh !important;
			}

			<?php endif; ?>
			<?php if ((    ot_get_option( 'revo_singleheaderpaddingtop' ) !=''
			  and ot_get_option( 'revo_singleheaderpaddingtop' ) !='250')
			||( ot_get_option( 'revo_singleheaderpaddingbottom' ) !=''
			&&  ot_get_option( 'revo_singleheaderpaddingbottom' ) !='200' )):
			 ?>
			@media (min-width: 768px) {

				.revo_blog_single .opener {
					padding-top: <?php echo esc_attr( ot_get_option( 'revo_singleheaderpaddingtop' ) ); ?>px !important;
					padding-bottom: <?php echo esc_attr( ot_get_option( 'revo_singleheaderpaddingbottom' ) ); ?>px !important;
				}
			}

			<?php endif; ?>

			<?php if ( ot_get_option( 'revo_archiveheadingcolor' ) !='' ): ?>
			.archive .masked h1 {
				color: <?php echo esc_attr( ot_get_option( 'revo_archiveheadingcolor' ) ); ?>;
			}

			<?php endif; ?>

			<?php if ( ot_get_option( 'revo_archiveheadingcolor_desc' ) !='' ): ?>
			.archive .masked .lead-text {
				color: <?php echo esc_attr( ot_get_option( 'revo_archiveheadingcolor_desc' ) ); ?>;
			}

			<?php endif; ?>

			<?php if ( ot_get_option( 'revo_blogheaderbgcolor_arhive' ) !='' ): ?>
			.revo_blog .main-blog, .revo_blog .main-blog.masked:before {
				background-color: <?php echo esc_attr( ot_get_option( 'revo_blogheaderbgcolor_arhive' ) ); ?>;

			}

			<?php endif; ?>

			<?php if ( ot_get_option( 'revo_archiveheaderbgheight' ) !='' &&  ot_get_option( 'revo_archiveheaderbgheight' ) !='50' ): ?>
			.archive .masthead {

				height: <?php echo esc_attr( ot_get_option( 'revo_archiveheaderbgheight' ) ); ?>vh !important;
			}

			<?php endif; ?>
			<?php if ((
			 ot_get_option( 'revo_archiveheaderpaddingtop' ) !=''  &&   ot_get_option( 'revo_archiveheaderpaddingtop' ) !='250'

			 )

			 ||( ot_get_option( 'revo_archiveheaderpaddingbottom' ) !='' && ot_get_option( 'revo_archiveheaderpaddingbottom' ) !='200' )): ?>
			@media (min-width: 768px) {

				.archive .masked .opener {
					padding-top: <?php echo esc_attr( ot_get_option( 'revo_archiveheaderpaddingtop' ) ); ?>px !important;
					padding-bottom: <?php echo esc_attr( ot_get_option( 'revo_archiveheaderpaddingbottom' ) ); ?>px !important;
				}
			}

			<?php endif; ?>
			<?php if ( ot_get_option('revo_mask_c_page_header_archive') == 'off') : ?>
			.revo_blog .main-blog {
				background-image: none !important;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_errorpageheadbg' ) !='' ): ?>
			.error404 .masthead-inner {
				background: transparent url( <?php echo esc_attr( ot_get_option( 'revo_errorpageheadbg' ) ); ?>) no-repeat fixed center top / cover !important;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_errorheaderbgcolor' ) !='' ): ?>
			.error404 .masked {
				background: none;
				background-color: <?php echo esc_attr( ot_get_option( 'revo_errorheaderbgcolor' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_errorheadingcolor' ) !='' ): ?>
			.error404 .masked h1 {
				color: <?php echo esc_attr( ot_get_option( 'revo_errorheadingcolor' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_error_heading_fontsize' ) !=''  &&  ot_get_option( 'revo_error_heading_fontsize' ) !='65'): ?>
			.error404 .masked h1 {
				font-size: <?php echo esc_attr( ot_get_option( 'revo_error_heading_fontsize' ) ); ?>px;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_errorheaderparagraphcolor' ) !='' ): ?>
			.error404 .masked h2 {
				color: <?php echo esc_attr( ot_get_option( 'revo_errorheaderparagraphcolor' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_errorheaderbgheight' ) !='' && ot_get_option( 'revo_errorheaderbgheight' ) !='0' ): ?>
			.error404 .masked {
				height: <?php echo esc_attr( ot_get_option( 'revo_errorheaderbgheight' ) ); ?>vh !important;
			}

			<?php endif; ?>
			<?php if ((
			ot_get_option( 'revo_errorheaderpaddingtop' ) !=''  &&   ot_get_option( 'revo_errorheaderpaddingtop' ) != '250'

			)||( ot_get_option( 'revo_errorheaderpaddingbottom' ) !='' && ot_get_option( 'revo_errorheaderpaddingbottom' )  !='200' )): ?>
			@media (min-width: 768px) {
				.error404 .masked .opener {
					padding-top: <?php echo esc_attr( ot_get_option( 'revo_errorheaderpaddingtop' ) ); ?>px !important;
					padding-bottom: <?php echo esc_attr( ot_get_option( 'revo_errorheaderpaddingbottom' ) ); ?>px !important;
				}
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_searchpageheadbg' ) !='' ): ?>
			.search .main-blog {
				background: url(<?php echo esc_attr( ot_get_option( 'revo_searchpageheadbg' ) ); ?>) center 0 no-repeat;

			}
			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_searchheadingcolor' ) !='' ): ?>
			.search .opener h1 i {
				color: <?php echo esc_attr( ot_get_option( 'revo_searchheadingcolor' ) ); ?>;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_search_heading_fontsize' ) !=''  && ot_get_option( 'revo_search_heading_fontsize' ) !='0' ): ?>
			.search .opener h1 i {
				font-size: <?php echo esc_attr( ot_get_option( 'revo_search_heading_fontsize' ) ); ?>px;
			}

			<?php endif; ?>
			<?php if ( ot_get_option( 'revo_searchheaderbgheight' ) !='' && ot_get_option( 'revo_searchheaderbgheight' ) !='50' ): ?>
			.search .masked {
				height: <?php echo esc_attr( ot_get_option( 'revo_searchheaderbgheight' ) ); ?>vh !important;
			}

			<?php endif; ?>
			<?php if (( ot_get_option( 'revo_searchheaderpaddingtop' ) !=''
			 && ot_get_option( 'revo_searchheaderpaddingtop' ) !='250')
			||( ot_get_option( 'revo_searchheaderpaddingbottom' ) !='' &&
			  ot_get_option( 'revo_searchheaderpaddingbottom' ) !='200'
			 )): ?>

			@media (min-width: 768px) {
				.search .opener {
					padding-top: <?php echo esc_attr( ot_get_option( 'revo_searchheaderpaddingtop' ) ); ?>px !important;
					padding-bottom: <?php echo esc_attr( ot_get_option( 'revo_searchheaderpaddingbottom' ) ); ?>px !important;
				}
			}

			<?php endif; ?>
			<?php
			  /*
			 * Typography
			 */
			 $revo_tipigrof = ot_get_option( 'revo_tipigrof', array() ); ?>
			<?php if($revo_tipigrof) { ?>
			body {
				color: <?php echo esc_attr( $revo_tipigrof['font-color'] ) ; ?>;
				font-family: <?php echo esc_attr( $revo_tipigrof['font-family'] ) ; ?> !important;
				font-size: <?php echo esc_attr( $revo_tipigrof['font-size'] ) ; ?>;
				font-style: <?php echo esc_attr( $revo_tipigrof['font-style'] ) ; ?>;
				font-variant: <?php echo esc_attr( $revo_tipigrof['font-variant'] ) ; ?>;
				font-weight: <?php echo esc_attr( $revo_tipigrof['font-weight'] ) ; ?>;
				letter-spacing: <?php echo esc_attr( $revo_tipigrof['letter-spacing'] ) ; ?>;
				line-height: <?php echo esc_attr( $revo_tipigrof['line-height'] ) ; ?>;
				text-decoration: <?php echo esc_attr( $revo_tipigrof['text-decoration'] ) ; ?>;
				text-transform: <?php echo esc_attr( $revo_tipigrof['text-transform'] ) ; ?>;
			}

			<?php } ?>
			<?php

			 $revo_tipigrof1 = ot_get_option( 'revo_tipigrof1', array() ); ?>
			<?php if( $revo_tipigrof1 ) { ?>
			h1 {
				color: <?php echo esc_attr( $revo_tipigrof1['font-color'] ) ; ?>;
				font-family: <?php echo esc_attr( $revo_tipigrof1['font-family'] ) ; ?> !important;
				font-size: <?php echo esc_attr( $revo_tipigrof1['font-size'] ) ; ?>;
				font-style: <?php echo esc_attr( $revo_tipigrof1['font-style'] ) ; ?>;
				font-variant: <?php echo esc_attr( $revo_tipigrof1['font-variant'] ) ; ?>;
				font-weight: <?php echo esc_attr( $revo_tipigrof1['font-weight'] ) ; ?>;
				letter-spacing: <?php echo esc_attr( $revo_tipigrof1['letter-spacing'] ) ; ?>;
				line-height: <?php echo esc_attr( $revo_tipigrof1['line-height'] ) ; ?>;
				text-decoration: <?php echo esc_attr( $revo_tipigrof1['text-decoration'] ) ; ?>;
				text-transform: <?php echo esc_attr( $revo_tipigrof1['text-transform'] ) ; ?>;
			}

			<?php } ?>

			<?php $revo_tipigrof2 = ot_get_option( 'revo_tipigrof2', array() ); ?>
			<?php if($revo_tipigrof2) { ?>
			h2 {
				color: <?php echo esc_attr( $revo_tipigrof2['font-color'] ) ; ?>;
				font-family: <?php echo esc_attr( $revo_tipigrof2['font-family'] ) ; ?> !important;
				font-size: <?php echo esc_attr( $revo_tipigrof2['font-size'] ) ; ?>;
				font-style: <?php echo esc_attr( $revo_tipigrof2['font-style'] ) ; ?>;
				font-variant: <?php echo esc_attr( $revo_tipigrof2['font-variant'] ) ; ?>;
				font-weight: <?php echo esc_attr( $revo_tipigrof2['font-weight'] ) ; ?>;
				letter-spacing: <?php echo esc_attr( $revo_tipigrof2['letter-spacing'] ) ; ?>;
				line-height: <?php echo esc_attr( $revo_tipigrof2['line-height'] ) ; ?>;
				text-decoration: <?php echo esc_attr( $revo_tipigrof2['text-decoration'] ) ; ?>;
				text-transform: <?php echo esc_attr( $revo_tipigrof2['text-transform'] ) ; ?>;
			}

			<?php } ?>

			<?php $revo_tipigrof3 = ot_get_option( 'revo_tipigrof3', array() ); ?>
			<?php if($revo_tipigrof3) { ?>
			h3 {
				color: <?php echo esc_attr( $revo_tipigrof3['font-color'] ) ; ?>;
				font-family: <?php echo esc_attr( $revo_tipigrof3['font-family'] ) ; ?> !important;
				font-size: <?php echo esc_attr( $revo_tipigrof3['font-size'] ) ; ?>;
				font-style: <?php echo esc_attr( $revo_tipigrof3['font-style'] ) ; ?>;
				font-variant: <?php echo esc_attr( $revo_tipigrof3['font-variant'] ) ; ?>;
				font-weight: <?php echo esc_attr( $revo_tipigrof3['font-weight'] ) ; ?>;
				letter-spacing: <?php echo esc_attr( $revo_tipigrof3['letter-spacing'] ) ; ?>;
				line-height: <?php echo esc_attr( $revo_tipigrof3['line-height'] ) ; ?>;
				text-decoration: <?php echo esc_attr( $revo_tipigrof3['text-decoration'] ) ; ?>;
				text-transform: <?php echo esc_attr( $revo_tipigrof3['text-transform'] ) ; ?>;
			}

			<?php } ?>

			<?php $revo_tipigrof4 = ot_get_option( 'revo_tipigrof4', array() ); ?>
			<?php if($revo_tipigrof4) { ?>
			h4 {
				color: <?php echo esc_attr( $revo_tipigrof4['font-color'] ) ; ?>;
				font-family: <?php echo esc_attr( $revo_tipigrof4['font-family'] ) ; ?> !important;
				font-size: <?php echo esc_attr( $revo_tipigrof4['font-size'] ) ; ?>;
				font-style: <?php echo esc_attr( $revo_tipigrof4['font-style'] ) ; ?>;
				font-variant: <?php echo esc_attr( $revo_tipigrof4['font-variant'] ) ; ?>;
				font-weight: <?php echo esc_attr( $revo_tipigrof4['font-weight'] ) ; ?>;
				letter-spacing: <?php echo esc_attr( $revo_tipigrof4['letter-spacing'] ) ; ?>;
				line-height: <?php echo esc_attr( $revo_tipigrof4['line-height'] ) ; ?>;
				text-decoration: <?php echo esc_attr( $revo_tipigrof4['text-decoration'] ) ; ?>;
				text-transform: <?php echo esc_attr( $revo_tipigrof4['text-transform'] ) ; ?>;
			}

			<?php } ?>

			<?php $revo_tipigrof5 = ot_get_option( 'revo_tipigrof5', array() ); ?>
			<?php if($revo_tipigrof5) { ?>
			h5 {
				color: <?php echo esc_attr( $revo_tipigrof5['font-color'] ) ; ?>;
				font-family: <?php echo esc_attr( $revo_tipigrof5['font-family'] ) ; ?> !important;
				font-size: <?php echo esc_attr( $revo_tipigrof5['font-size'] ) ; ?>;
				font-style: <?php echo esc_attr( $revo_tipigrof5['font-style'] ) ; ?>;
				font-variant: <?php echo esc_attr( $revo_tipigrof5['font-variant'] ) ; ?>;
				font-weight: <?php echo esc_attr( $revo_tipigrof5['font-weight'] ) ; ?>;
				letter-spacing: <?php echo esc_attr( $revo_tipigrof5['letter-spacing'] ) ; ?>;
				line-height: <?php echo esc_attr( $revo_tipigrof5['line-height'] ) ; ?>;
				text-decoration: <?php echo esc_attr( $revo_tipigrof5['text-decoration'] ) ; ?>;
				text-transform: <?php echo esc_attr( $revo_tipigrof5['text-transform'] ) ; ?>;
			}

			<?php } ?>

			<?php $revo_tipigrof6 = ot_get_option( 'revo_tipigrof6', array() ); ?>
			<?php if($revo_tipigrof6) { ?>
			h6 {
				color: <?php echo esc_attr( $revo_tipigrof6['font-color'] ) ; ?>;
				font-family: <?php echo esc_attr( $revo_tipigrof6['font-family'] ) ; ?> !important;
				font-size: <?php echo esc_attr( $revo_tipigrof6['font-size'] ) ; ?>;
				font-style: <?php echo esc_attr( $revo_tipigrof6['font-style'] ) ; ?>;
				font-variant: <?php echo esc_attr( $revo_tipigrof6['font-variant'] ) ; ?>;
				font-weight: <?php echo esc_attr( $revo_tipigrof6['font-weight'] ) ; ?>;
				letter-spacing: <?php echo esc_attr( $revo_tipigrof6['letter-spacing'] ) ; ?>;
				line-height: <?php echo esc_attr( $revo_tipigrof6['line-height'] ) ; ?>;
				text-decoration: <?php echo esc_attr( $revo_tipigrof6['text-decoration'] ) ; ?>;
				text-transform: <?php echo esc_attr( $revo_tipigrof6['text-transform'] ) ; ?>;
			}

			<?php } ?>

			<?php if (ot_get_option('additionalcss') != '') {
				echo (ot_get_option('additionalcss'));
			} ?>
			<?php 
			$img_style =  get_theme_mod('revo_404_top_img');
			if (isset($img_style{0})): ?>

			.error404 .masked {
				background: url(<?php  echo esc_url($img_style); ?>) 100% 0 no-repeat

			}

			<?php endif;?>

		</style>

		<?php if ( ot_get_option( 'additionaljs' ) != '' ): ?>
			<script type="text/javascript">
				<?php if ( ot_get_option( 'additionaljs' ) ) {
					echo ( ot_get_option( 'additionaljs' ) );
				} ?>
			</script>
		<?php endif; ?>

	<?php endif; ?>
<?php }

add_action( 'wp_head', 'revo_custom_styling' );