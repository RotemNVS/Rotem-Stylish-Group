<?php


/**
 * function extract colors from style.css
 * @return array
 */
function revo_get_style_color() {


	global $wp_filesystem;
	$colors = array();
	//the existence check
	if ( empty( $wp_filesystem ) ) {
		require_once( ABSPATH . '/wp-admin/includes/file.php' );
		WP_Filesystem();
	}
	$mycity_upload_dir = wp_upload_dir();
	$mycity_filename   = trailingslashit( $mycity_upload_dir['basedir'] ) . 'main.css';


	if ( $wp_filesystem->exists( $mycity_filename ) ) {
		$con = $wp_filesystem->get_contents( 'mycity_css_php', $mycity_upload_dir["baseurl"] . "/main.css" );
	} else {
		$con = $wp_filesystem->get_contents( get_template_directory() . "/css/style.css" );
	}


	preg_match_all( "/#([A-z0-9]{6,6}?)/", $con, $arr );
	$colors = $arr[1];
	foreach ( $colors as $k => $v ) {
		$colors[ $k ] = strtoupper( $v );
	}

	$colors = array_unique( $colors );

	return $colors;

}


/**
 * return url base style or false
 * @return bool|string
 */
function revo_enqueue_url_base_style() {
	global $wp_filesystem;
	if ( empty( $wp_filesystem ) ) {
		require_once( ABSPATH . '/wp-admin/includes/file.php' );
		WP_Filesystem();
	}
	$revo_upload_dir = wp_upload_dir();
	$revo_filename   = trailingslashit( $revo_upload_dir['basedir'] ) . 'style.css';
	if ( $wp_filesystem->exists( $revo_filename ) ) {
		$url = $revo_upload_dir["baseurl"];
		if ( isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] != 'off' ) { //HTTPS

			if(preg_match('#http:\/\/#',$url)){
				$url = str_replace( 'http', 'https', $url );
			}

		}

		return $url . "/style.css";
	} else {
		return false;
	}

}


add_action( 'wp_head', 'revo_css_generator' );
function revo_css_generator() {
	if ( ! current_user_can( "administrator" ) || isset( $wp_customize ) ) {
		return;

	}
	global $wp_filesystem;
	if ( empty( $wp_filesystem ) ) {
		require_once( ABSPATH . '/wp-admin/includes/file.php' );
		WP_Filesystem();
	}
	$revo_upload_dir = wp_upload_dir();
	$revo_filename   = trailingslashit( $revo_upload_dir['basedir'] ) . '/style.css';

	$con = revo_css_generator_custumize();
	/*******************************************************************/
	$F = $wp_filesystem->put_contents( $revo_filename, revo_minify_css( $con ), FS_CHMOD_FILE );


}

function revo_css_generator_custumize() {
	if ( ! current_user_can( "administrator" ) || isset( $wp_customize ) ) {
		return;

	}

	global $wp_filesystem;
	if ( empty( $wp_filesystem ) ) {
		require_once( ABSPATH . '/wp-admin/includes/file.php' );
		WP_Filesystem();
	}
	$revo_upload_dir = wp_upload_dir();
	$revo_filename   = trailingslashit( $revo_upload_dir['basedir'] ) . '/style.css';
	/*****************************************************************/
	$con = $wp_filesystem->get_contents( get_template_directory() . "/css/style.css" );
	$con = revo_color_hack( $con );
	preg_match_all( "/#([A-z0-9]{6,6}?)/", $con, $arr );
	$colors = $arr[1];
	$colors = array_unique( $colors );
	foreach ( $colors as $k => $v ) {
		$tmp_settingname = 'colors_m_' . strtoupper( $v );
		$color           = get_theme_mod( $tmp_settingname );
		if ( $color ) {
			$v     = esc_attr( $v );
			$color = esc_attr( $color );

			$con = str_replace( "#" . $v, $color, $con );
			$con = str_replace( "#" . strtolower( $v ), $color, $con );

			$con = str_replace( '../', get_template_directory_uri() . "/", $con );
		}
	}
	$con = preg_replace( '#\@import url(.*?);#', '', $con );
	$con = preg_replace( '#background:.*?url.*?;#', '', $con );

	return revo_minify_css( $con );


}


function revo_replace_callback( $matches ) {
	return 'calc(' . preg_replace( '#\s+#', "\x1A", $matches[1] ) . ')';
}

function revo_minify_css( $input ) {
	if ( trim( $input ) === "" ) {
		return $input;
	}
	// Force white-space(s) in `calc()`
	if ( strpos( $input, 'calc(' ) !== false ) {
		$input = preg_replace_callback( '#(?<=[\s:])calc\(\s*(.*?)\s*\)#', revo_replace_callback(), $input );
	}

	return preg_replace(
		array(
			// Remove comment(s)
			'#("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\')|\/\*(?!\!)(?>.*?\*\/)|^\s*|\s*$#s',
			// Remove unused white-space(s)
			'#("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\'|\/\*(?>.*?\*\/))|\s*+;\s*+(})\s*+|\s*+([*$~^|]?+=|[{};,>~+]|\s*+-(?![0-9\.])|!important\b)\s*+|([[(:])\s++|\s++([])])|\s++(:)\s*+(?!(?>[^{}"\']++|"(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\')*+{)|^\s++|\s++\z|(\s)\s+#si',
			// Replace `0(cm|em|ex|in|mm|pc|pt|px|vh|vw|%)` with `0`
			'#(?<=[\s:])(0)(cm|em|ex|in|mm|pc|pt|px|vh|vw|%)#si',
			// Replace `:0 0 0 0` with `:0`
			'#:(0\s+0|0\s+0\s+0\s+0)(?=[;\}]|\!important)#i',
			// Replace `background-position:0` with `background-position:0 0`
			'#(background-position):0(?=[;\}])#si',
			// Replace `0.6` with `.6`, but only when preceded by a white-space or `=`, `:`, `,`, `(`, `-`
			'#(?<=[\s=:,\(\-]|&\#32;)0+\.(\d+)#s',
			// Minify string value
			'#(\/\*(?>.*?\*\/))|(?<!content\:)([\'"])([a-z_][-\w]*?)\2(?=[\s\{\}\];,])#si',
			'#(\/\*(?>.*?\*\/))|(\burl\()([\'"])([^\s]+?)\3(\))#si',
			// Minify HEX color code
			'#(?<=[\s=:,\(]\#)([a-f0-6]+)\1([a-f0-6]+)\2([a-f0-6]+)\3#i',
			// Replace `(border|outline):none` with `(border|outline):0`
			'#(?<=[\{;])(border|outline):none(?=[;\}\!])#',
			// Remove empty selector(s)
			'#(\/\*(?>.*?\*\/))|(^|[\{\}])(?:[^\s\{\}]+)\{\}#s',
			'#\x1A#'
		),
		array(
			'$1',
			'$1$2$3$4$5$6$7',
			'$1',
			':0',
			'$1:0 0',
			'.$1',
			'$1$3',
			'$1$2$4$5',
			'$1$2$3',
			'$1:0',
			'$1$2',
			' '
		),
		$input );
}


function revo_video_arr() {
	return array(
		'#http://((m|www)\.)?youtube\.com/watch.*#i'          => array( 'http://www.youtube.com/oembed', true ),
		'#https://((m|www)\.)?youtube\.com/watch.*#i'         => array(
			'http://www.youtube.com/oembed?scheme=https',
			true
		),
		'#http://((m|www)\.)?youtube\.com/playlist.*#i'       => array( 'http://www.youtube.com/oembed', true ),
		'#https://((m|www)\.)?youtube\.com/playlist.*#i'      => array(
			'http://www.youtube.com/oembed?scheme=https',
			true
		),
		'#http://youtu\.be/.*#i'                              => array( 'http://www.youtube.com/oembed', true ),
		'#https://youtu\.be/.*#i'                             => array(
			'http://www.youtube.com/oembed?scheme=https',
			true
		),
		'http://blip.tv/*'                                    => array( 'http://blip.tv/oembed/', false ),
		'#https?://(.+\.)?vimeo\.com/.*#i'                    => array(
			'http://vimeo.com/api/oembed.{format}',
			true
		),
		'#https?://(www\.)?dailymotion\.com/.*#i'             => array(
			'http://www.dailymotion.com/services/oembed',
			true
		),
		'http://dai.ly/*'                                     => array(
			'http://www.dailymotion.com/services/oembed',
			false
		),
		'#https?://(www\.)?flickr\.com/.*#i'                  => array(
			'https://www.flickr.com/services/oembed/',
			true
		),
		'#https?://flic\.kr/.*#i'                             => array(
			'https://www.flickr.com/services/oembed/',
			true
		),
		'#https?://(.+\.)?smugmug\.com/.*#i'                  => array(
			'http://api.smugmug.com/services/oembed/',
			true
		),
		'#https?://(www\.)?hulu\.com/watch/.*#i'              => array(
			'http://www.hulu.com/api/oembed.{format}',
			true
		),
		'http://i*.photobucket.com/albums/*'                  => array(
			'http://photobucket.com/oembed',
			false
		),
		'http://gi*.photobucket.com/groups/*'                 => array(
			'http://photobucket.com/oembed',
			false
		),
		'#https?://(www\.)?scribd\.com/doc/.*#i'              => array(
			'http://www.scribd.com/services/oembed',
			true
		),
		'#https?://wordpress.tv/.*#i'                         => array( 'http://wordpress.tv/oembed/', true ),
		'#https?://(.+\.)?polldaddy\.com/.*#i'                => array( 'https://polldaddy.com/oembed/', true ),
		'#https?://poll\.fm/.*#i'                             => array( 'https://polldaddy.com/oembed/', true ),
		'#https?://(www\.)?funnyordie\.com/videos/.*#i'       => array(
			'http://www.funnyordie.com/oembed',
			true
		),
		'#https?://(www\.)?twitter\.com/.+?/status(es)?/.*#i' => array(
			'https://api.twitter.com/1/statuses/oembed.{format}',
			true
		),
		'#https?://vine.co/v/.*#i'                            => array(
			'https://vine.co/oembed.{format}',
			true
		),
		'#https?://(www\.)?soundcloud\.com/.*#i'              => array( 'http://soundcloud.com/oembed', true ),
		'#https?://(.+?\.)?slideshare\.net/.*#i'              => array(
			'https://www.slideshare.net/api/oembed/2',
			true
		),
		'#https?://instagr(\.am|am\.com)/p/.*#i'              => array(
			'https://api.instagram.com/oembed',
			true
		),
		'#https?://(www\.)?rdio\.com/.*#i'                    => array(
			'http://www.rdio.com/api/oembed/',
			true
		),
		'#https?://rd\.io/x/.*#i'                             => array(
			'http://www.rdio.com/api/oembed/',
			true
		),
		'#https?://(open|play)\.spotify\.com/.*#i'            => array(
			'https://embed.spotify.com/oembed/',
			true
		),
		'#https?://(.+\.)?imgur\.com/.*#i'                    => array( 'http://api.imgur.com/oembed', true ),
		'#https?://(www\.)?meetu(\.ps|p\.com)/.*#i'           => array( 'http://api.meetup.com/oembed', true ),
		'#https?://(www\.)?issuu\.com/.+/docs/.+#i'           => array( 'http://issuu.com/oembed_wp', true ),
		'#https?://(www\.)?collegehumor\.com/video/.*#i'      => array(
			'http://www.collegehumor.com/oembed.{format}',
			true
		),
		'#https?://(www\.)?mixcloud\.com/.*#i'                => array(
			'http://www.mixcloud.com/oembed',
			true
		),
		'#https?://(www\.|embed\.)?ted\.com/talks/.*#i'       => array(
			'http://www.ted.com/talks/oembed.{format}',
			true
		),
		'#https?://(www\.)?(animoto|video214)\.com/play/.*#i' => array(
			'http://animoto.com/oembeds/create',
			true
		),
		'#https?://(.+)\.tumblr\.com/post/.*#i'               => array(
			'https://www.tumblr.com/oembed/1.0',
			true
		),
		'#https?://(www\.)?kickstarter\.com/projects/.*#i'    => array(
			'https://www.kickstarter.com/services/oembed',
			true
		),
		'#https?://kck\.st/.*#i'                              => array(
			'https://www.kickstarter.com/services/oembed',
			true
		),
		'#https?://cloudup\.com/.*#i'                         => array( 'https://cloudup.com/oembed', true ),
	);
} 