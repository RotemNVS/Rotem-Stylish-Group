<?php
/**
 * Created by PhpStorm.
 * User: Pro
 * Date: 14.01.2016
 * Time: 18:33
 */

add_filter('vc_iconpicker-type-fontawesome', 'revo_tweak_vc_iconpicker_type_fontawesome2');


function revo_tweak_vc_iconpicker_type_fontawesome2($icons)
{
    // Add custom icons to array

    // Return icons
    return $icons;
}

add_action('vc_before_init', 'revo_subtitle_integrateWithVC');

/**
 *
 */
function revo_subtitle_integrateWithVC()
{


    /*
    *  Services
    */
    vc_map(array(
        'name' => esc_html__('Revo services', 'revo'),
        'base' => 'revo_services',
        'show_settings_on_create' => true,
        'category' => esc_html__('Revo', 'revo'),
        'description' => esc_html__('', 'revo'),
        'custom_markup' => '{{title}}<div class="vc_btn3-container"><h4 class="team-name"></h4></div>',
        'icon' => plugins_url('/icon/tools.png', __FILE__), // Simply pass url to your icon here
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),


            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => esc_html__('Text header', 'revo'),
                'param_name' => 't',
                'value' => 'We Are Awesome Web Agency',
                'description' => esc_html__('insert text', 'revo')
            ),

            array(
                'type' => 'textarea',
                'class' => '',
                'heading' => esc_html__('Description', 'revo'),
                'param_name' => 'd',
                'value' => esc_html__('The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo'),
                'description' => esc_html__('insert text', 'revo')
            ),


            array(
                'type' => 'param_group',
                'heading' => esc_html__('Services items', 'revo'),
                'group' => esc_html__('Services items', 'revo'),
                'param_name' => 'items',
                'params' => array(


                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__('The icons 1 ', 'revo'),
                        'param_name' => 'icon',
                        'value' => '',
                        'description' => esc_html__('insert icon', 'revo'),
                        'settings' => array(
                            'emptyIcon' => false,
                            'iconsPerPage' => 4000,
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('Title', 'revo'),
                        'param_name' => 'ts',
                        'value' => esc_html__('Branding', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),
                    array(
                        'type' => 'textarea',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('Description', 'revo'),
                        'param_name' => 'ds',
                        'value' => esc_html__('Maecenas mattis est eget efficitur tempus. Maecenas fermentum fringilla vestibulum. Nulla pulvinar ullamcorper auctor', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('data-wow-delay', 'revo'),
                        'param_name' => 'wow',
                        'value' => esc_html__('', 'revo'),
                        'description' => esc_html__('insert delay time  example: 0.2s', 'revo')
                    ),


                ),

            ),


            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),
        ),

    ));

    /*
*  Services2
*/
    vc_map(array(
        'name' => esc_html__('Revo services 2', 'revo'),
        'base' => 'revo_services2',
        'show_settings_on_create' => true,
        'category' => esc_html__('Revo', 'revo'),
        'description' => esc_html__('', 'revo'),
        'custom_markup' => '{{title}}<div class="vc_btn3-container"><h4 class="team-name"></h4></div>',
        'icon' => plugins_url('/icon/services2.png', __FILE__), // Simply pass url to your icon here
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),


            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => esc_html__('Text header', 'revo'),
                'param_name' => 't',
                'value' => 'Some facts about product',
                'description' => esc_html__('insert text', 'revo')
            ),


            array(
                'type' => 'textarea',
                'class' => '',
                'heading' => esc_html__('Description', 'revo'),
                'param_name' => 'd',
                'value' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua', 'revo'),
                'description' => esc_html__('insert text', 'revo')
            ),

            array(
                'type' => 'param_group',
                'heading' => esc_html__('Services items', 'revo'),
                'group' => esc_html__('Services items', 'revo'),
                'param_name' => 'items',
                'params' => array(


                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__('The icons 1 ', 'revo'),
                        'param_name' => 'icon',
                        'value' => '',
                        'description' => esc_html__('insert icon', 'revo'),
                        'settings' => array(
                            'emptyIcon' => false,
                            'iconsPerPage' => 4000,
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('Title', 'revo'),
                        'param_name' => 'ts',
                        'value' => esc_html__('Branding', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),
                    array(
                        'type' => 'textarea',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('Description', 'revo'),
                        'param_name' => 'ds',
                        'value' => esc_html__('Maecenas mattis est eget efficitur tempus. Maecenas fermentum fringilla vestibulum. Nulla pulvinar ullamcorper auctor', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),
                    array(
                        'type' => 'dropdown',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('Animation', 'revo'),
                        'param_name' => 'anima',
                        'value' => array(
                            esc_html__('wow fadeInUp', 'revo') => 'wow fadeInUp',
                            esc_html__('none', 'revo') => ' ',

                        ),


                    ),
                    array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('data-wow-delay', 'revo'),
                        'param_name' => 'wow',

                        'description' => esc_html__('insert delay time  example: 0.2s', 'revo')
                    ),


                ),

            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),
        ),

    ));


    /**
     * portfolio
     */
    vc_map(array(
        'name' => esc_html__('Revo Portfolio', 'revo'),
        'base' => 'revo_portfolio_new',
        'icon' => plugins_url('/icon/resume.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Heading', 'revo'),
                'param_name' => 'heading',
                'description' => esc_html__('Add Your Heading', 'revo'),
            ),
            array(
                'type' => 'dropdown',
                'param_name' => 'class',
                'value' => array(
                    esc_html__('none ', 'revo') => ' ',
                    esc_html__('col-3 ', 'revo') => 'col-3 isotope-padding ',
                    esc_html__('isotope-padding ', 'revo') => 'isotope-padding',


                ),
                'std' => '',
                'heading' => esc_html__('display style ', 'revo'),
                'description' => esc_html__('Select display style.', 'revo'),


            ),

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Portfolio Count', 'revo'),
                'param_name' => 'posts',
                'description' => esc_html__('You can control with number your portfolio posts', 'revo'),
                'group' => esc_html__('Portfolio values', 'revo'),
                'value' => esc_html__('3', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'heading' => esc_html__('order', 'revo'),
                'param_name' => 'order',
                'description' => esc_html__('Enter portfolio item order. DESC or ASC', 'revo'),
                'group' => esc_html__('Portfolio values', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'heading' => esc_html__('orderby', 'revo'),
                'param_name' => 'orderby',
                'description' => esc_html__('Enter post orderby. Default is : date', 'revo'),
                'group' => esc_html__('Portfolio values', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Category', 'revo'),
                'param_name' => 'portfolio_category',
                'description' => esc_html__('Enter Portfolio category or write all', 'revo'),
                'group' => esc_html__('Portfolio values', 'revo'),
            ),


            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),
        )
    ));


    /**
     * portfolio col-2
     */
    vc_map(array(
        'name' => esc_html__('Revo Portfolio col 2', 'revo'),
        'base' => 'revo_portfolio_col_2',
        'icon' => plugins_url('/icon/dossier.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Heading', 'revo'),
                'param_name' => 'heading',
                'description' => esc_html__('Add Your Heading', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Portfolio Count', 'revo'),
                'param_name' => 'posts',
                'description' => esc_html__('You can control with number your portfolio posts', 'revo'),
                'group' => esc_html__('Portfolio values', 'revo'),
                'value' => esc_html__('3', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'heading' => esc_html__('order', 'revo'),
                'param_name' => 'order',
                'description' => esc_html__('Enter portfolio item order. DESC or ASC', 'revo'),
                'group' => esc_html__('Portfolio values', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'heading' => esc_html__('orderby', 'revo'),
                'param_name' => 'orderby',
                'description' => esc_html__('Enter post orderby. Default is : date', 'revo'),
                'group' => esc_html__('Portfolio values', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Category', 'revo'),
                'param_name' => 'portfolio_category',
                'description' => esc_html__('Enter Portfolio category or write all', 'revo'),
                'group' => esc_html__('Portfolio values', 'revo'),
            ),


            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),
        )
    ));


    /**
     * about
     */

    vc_map(array(
        'name' => esc_html__('Revo About Section ', 'revo'),
        'base' => 'revo_about_section',
        'icon' => plugins_url('/icon/about.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => esc_html__('Main heading', 'revo'),
                'param_name' => 'heading',
                'value' => esc_html__('WHAT WE DO', 'revo'),
                'description' => esc_html__('insert text', 'revo')
            ),
            array(
                'type' => 'textarea',
                'class' => '',
                'heading' => esc_html__('Main description', 'revo'),
                'param_name' => 'description',
                'value' => esc_html__('The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo'),
                'description' => esc_html__('insert text', 'revo')
            ),

            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => esc_html__('top column heading', 'revo'),
                'group' => esc_html__('Top column ', 'revo'),
                'param_name' => 'right_heading',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('insert delay time  example: 0.2s', 'revo')
            ),
            array(
                'type' => 'attach_image',
                'heading' => esc_html__('Images bg', 'revo'),
                'group' => esc_html__('Top column ', 'revo'),
                "holder" => "img",
                'param_name' => 'img_src',
                'description' => esc_html__('Select images from media library.', 'revo'),
            ),
            array(
                'type' => 'param_group',
                'heading' => esc_html__('About items', 'revo'),
                'group' => esc_html__('Top column ', 'revo'),
                'param_name' => 'items',
                'params' => array(

                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__('The icons 1 ', 'revo'),
                        'param_name' => 'icon',
                        'value' => '',
                        'description' => esc_html__('insert icon', 'revo'),
                        'settings' => array(
                            'emptyIcon' => false,
                            'iconsPerPage' => 4000,
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        'class' => '',
                        'heading' => esc_html__('Title', 'revo'),
                        'param_name' => 't',
                        'value' => esc_html__('USER INTERFACE', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),
                    array(
                        'type' => 'textarea',
                        'class' => '',
                        'heading' => esc_html__('Description', 'revo'),
                        'param_name' => 'd',
                        'value' => esc_html__('Crafting visually stunning memorable experiences for web and interfaces', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),


                ),

            ),
            array(
                'group' => esc_html__('Bottom column ', 'revo'),
                'type' => 'attach_image',
                'heading' => esc_html__('Images bg', 'revo'),
                "holder" => "img",
                'param_name' => 'img_src2',
                'description' => esc_html__('Select images from media library.', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'group' => esc_html__('Bottom column ', 'revo'),
                'class' => '',
                'heading' => esc_html__('Bottom column heading', 'revo'),
                'param_name' => 'left_heading',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('insert text', 'revo')
            ),

            array(
                'type' => 'textarea',
                'group' => esc_html__('Bottom column ', 'revo'),
                'class' => '',
                'heading' => esc_html__('Bottom column text', 'revo'),
                'param_name' => 'left_text',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('insert text', 'revo')
            ),


            array(
                'type' => 'param_group',
                'group' => esc_html__('Bottom column ', 'revo'),
                'heading' => esc_html__('Progressbar ', 'revo'),
                'param_name' => 'items2',
                'params' => array(

                    array(
                        'type' => 'textfield',
                        'group' => esc_html__('Bottom column ', 'revo'),
                        'heading' => esc_html__('Item title', 'revo'),
                        'param_name' => 'progresstitle',
                        'description' => esc_html__('Add item title', 'revo')
                    ),
                    array(
                        'group' => esc_html__('Bottom column ', 'revo'),
                        'type' => 'textfield',
                        'heading' => esc_html__('Item width value', 'revo'),
                        'param_name' => 'progresssize',
                        'description' => esc_html__('Add item value example:50,30,90...etc', 'revo')
                    ),


                ),

            ),


            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Design options', 'revo'),
            ),


        )

    ));

    /**
     * about2
     */

    vc_map(array(
        'name' => esc_html__('Revo About Section 2 ', 'revo'),
        'base' => 'revo_about_section2',
        'icon' => plugins_url('/icon/about-filled.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => esc_html__('top column heading', 'revo'),
                'group' => esc_html__('Top column ', 'revo'),
                'param_name' => 'right_heading',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('insert delay time  example: 0.2s', 'revo')
            ),
            array(
                'type' => 'attach_image',
                'group' => esc_html__('Top column ', 'revo'),
                'heading' => esc_html__('Images', 'revo'),
                'param_name' => 'images',
                'value' => '',
                "holder" => "img",
                'description' => esc_html__('Select images from media library.', 'revo'),
            ),
            array(
                'type' => 'param_group',
                'heading' => esc_html__('About items', 'revo'),
                'group' => esc_html__('Top column ', 'revo'),
                'param_name' => 'items',
                'params' => array(

                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__('The icons 1 ', 'revo'),
                        'param_name' => 'icon',
                        'value' => '',
                        'description' => esc_html__('insert icon', 'revo'),
                        'settings' => array(
                            'emptyIcon' => false,
                            'iconsPerPage' => 4000,
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        'class' => '',
                        'heading' => esc_html__('Title', 'revo'),
                        'param_name' => 't',
                        'value' => esc_html__('USER INTERFACE', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),
                    array(
                        'type' => 'textfield',
                        'class' => '',
                        'heading' => esc_html__('Description', 'revo'),
                        'param_name' => 'd',
                        'value' => esc_html__('Crafting visually stunning memorable experiences for web and interfaces', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),


                ),

            ),

            array(
                'type' => 'textfield',
                'group' => esc_html__('Bottom column ', 'revo'),
                'class' => '',
                'heading' => esc_html__('Bottom column heading', 'revo'),
                'param_name' => 'left_heading',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('insert text', 'revo')
            ),

            array(
                'type' => 'textarea',
                'group' => esc_html__('Bottom column ', 'revo'),
                'class' => '',
                'heading' => esc_html__('Bottom column text', 'revo'),
                'param_name' => 'left_text',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('insert text', 'revo')
            ),


            array(
                'type' => 'param_group',
                'group' => esc_html__('Bottom column ', 'revo'),
                'heading' => esc_html__('Progressbar ', 'revo'),
                'param_name' => 'items2',
                'params' => array(

                    array(
                        'type' => 'textfield',
                        'group' => esc_html__('Bottom column ', 'revo'),
                        'heading' => esc_html__('Item title', 'revo'),
                        'param_name' => 'progresstitle',
                        'description' => esc_html__('Add item title', 'revo')
                    ),
                    array(
                        'group' => esc_html__('Bottom column ', 'revo'),
                        'type' => 'textfield',
                        'heading' => esc_html__('Item width value', 'revo'),
                        'param_name' => 'progresssize',
                        'description' => esc_html__('Add item value example:50,30,90...etc', 'revo')
                    ),


                ),

            ),


            array(
                'group' => esc_html__('Bottom column ', 'revo'),
                'type' => 'attach_image',
                'heading' => esc_html__('Images bg', 'revo'),
                "holder" => "img",
                'param_name' => 'img_src2',
                'description' => esc_html__('Select images from media library.', 'revo'),
            ),


            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Design options', 'revo'),
            ),


        )

    ));


    /**
     * Statistic
     */

    vc_map(array(
        'name' => esc_html__('Revo statistic  Section ', 'revo'),
        'base' => 'revo_statistic',
        'icon' => plugins_url('/icon/ratings.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),

            array(
                'type' => 'dropdown',
                'param_name' => 'class',
                'value' => array(
                    esc_html__('text-white bgc-primary', 'revo') => 'text-white bgc-primary',
                    esc_html__('bgc-light', 'revo') => 'bgc-light',


                ),
                'std' => '',
                'heading' => esc_html__('display style ', 'revo'),
                'description' => esc_html__('Select display style.', 'revo'),


            ),

            array(
                'type' => 'param_group',
                'heading' => esc_html__('Statistic items', 'revo'),
                'param_name' => 'items',
                'params' => array(


                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Item width value', 'revo'),
                        'param_name' => 'progresssize',
                        'description' => esc_html__('Add item count ', 'revo')
                    ),

                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Item title', 'revo'),
                        'param_name' => 'progresstitle',
                        'description' => esc_html__('Add item title', 'revo')
                    ),


                ),

            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),


        )
    ));


    /***********Revo  Team section****************/
    vc_map(array(
        'name' => esc_html__('revo my Team', 'revo'),
        'base' => 'revo_my_team',
        'show_settings_on_create' => true,
        'icon' => plugins_url('/icon/conference.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        "as_parent" => array('only' => 'revo_team'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
        "content_element" => true,
        "js_view" => 'VcColumnView',
        'params' => array(

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Title', 'revo'),
                'param_name' => 'heading',
                'description' => esc_html__('Add Your Title', 'revo'),
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),


        )
    ));

    /***********Revo team item****************/

    vc_map(array(
        'name' => esc_html__('Revo team item', 'revo'),
        'base' => 'revo_team',
        'show_settings_on_create' => true,
        'category' => esc_html__('Revo', 'revo'),
        'description' => esc_html__('', 'revo'),
        'icon' => plugins_url('/icon/collaborator.png', __FILE__), // Simply pass url to your icon here
        'custom_markup' => '{{title}}<div class="vc_btn3-container"><h4 class="team-name"></h4></div>',
        'params' => array(

            array(
                'type' => 'textfield',
                'holder' => 'div',
                'heading' => esc_html__('Name', 'revo'),
                'param_name' => 'name',
                'description' => esc_html__('insert text ', 'revo')
            ),
            array(
                'type' => 'textfield',
                'holder' => 'div',
                'heading' => esc_html__('Specialisation', 'revo'),
                'param_name' => 'spec',
                'description' => esc_html__('insert text ', 'revo')
            ),
            array(
                'type' => 'textarea',
                'holder' => 'div',
                'class' => '',
                'heading' => esc_html__('Description', 'revo'),
                'param_name' => 'content',
                'value' => '',
                'description' => esc_html__('insert text', 'revo')
            ),
            array(
                'type' => 'attach_image',
                'heading' => esc_html__('Images', 'revo'),
                'param_name' => 'images',
                'value' => '',
                'description' => esc_html__('Select images from media library.', 'revo'),
            ),
            array(
                'type' => 'param_group',
                'holder' => 'div',
                'heading' => esc_html__('Social links', 'revo'),
                'group' => esc_html__(' Social links ', 'revo'),
                'param_name' => 'items',
                'params' => array(
                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__('The icons 1 ', 'revo'),
                        'param_name' => 'icon',
                        'value' => '',
                        'description' => esc_html__('insert icon', 'revo'),
                        'settings' => array(
                            'emptyIcon' => false,
                            'iconsPerPage' => 4000,
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'heading' => esc_html__('Insert url', 'revo'),
                        'param_name' => 'url',
                        'description' => esc_html__('insert text ', 'revo')
                    ),


                ),
            ),


        ),


    ));


    /*
    * FEATURES
    */

    vc_map(array(
        'name' => esc_html__('Revo Features', 'revo'),
        'base' => 'revo_features',
        'icon' => plugins_url('/icon/star.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Heading', 'revo'),
                'param_name' => 'heading',
                'description' => esc_html__('Insert text', 'revo'),
            ),
            array(
                'type' => 'textarea',
                'heading' => esc_html__('Description', 'revo'),
                'param_name' => 'main_desc',
                'description' => esc_html__('Insert text', 'revo'),
            ),


            array(
                'type' => 'param_group',
                'heading' => esc_html__('Features list', 'revo'),
                'group' => esc_html__('Features list', 'revo'),
                'param_name' => 'items',
                'params' => array(
                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__('The icons 1 ', 'revo'),
                        'param_name' => 'icon',
                        'value' => 'fa-send',
                        'description' => esc_html__('insert icon', 'revo'),
                        'settings' => array(
                            'emptyIcon' => false,
                            'iconsPerPage' => 4000,
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'heading' => esc_html__('Text title', 'revo'),
                        'param_name' => 'h',
                        'description' => esc_html__('insert text ', 'revo')
                    ),
                    array(
                        'type' => 'textarea',
                        'holder' => 'div',
                        'heading' => esc_html__('Description', 'revo'),
                        'param_name' => 'desc',
                        'description' => esc_html__('insert text ', 'revo')
                    ),


                ),
            ),


            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),

        ),

    ));

    /*
* FEATURES2
*/

    vc_map(array(
        'name' => esc_html__('Revo Features 2', 'revo'),
        'base' => 'revo_features_2',
        'icon' => plugins_url('/icon/star2.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Heading', 'revo'),
                'param_name' => 'heading',
                'description' => esc_html__('Insert text', 'revo'),
                'value' => esc_html__('Design Makes Everything Better', 'revo'),
            ),
            array(
                'type' => 'textarea',
                'heading' => esc_html__('Description', 'revo'),
                'param_name' => 'main_desc',
                'description' => esc_html__('Insert text', 'revo'),
                'value' => esc_html__('The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo'),
            ),
            array(
                'type' => 'attach_image',
                'group' => esc_html__('Column with image  ', 'revo'),
                'heading' => esc_html__('Images', 'revo'),
                'param_name' => 'images',
                'value' => '',
                'description' => esc_html__('Select images from media library.', 'revo'),
            ),
            array(
                'type' => 'dropdown',
                'group' => esc_html__('Column with image  ', 'revo'),
                'param_name' => 'class2',
                'value' => array(
                    esc_html__('fadeInLeft', 'revo') => 'fadeInLeft',
                    esc_html__('fadeInUp', 'revo') => 'fadeInUp',


                ),
                'std' => '',
                'heading' => esc_html__('display style ', 'revo'),
                'description' => esc_html__('Select display style.', 'revo'),


            ),


            array(
                'type' => 'param_group',
                'heading' => esc_html__('Features left', 'revo'),
                'group' => esc_html__('Features left ', 'revo'),
                'param_name' => 'items',
                'params' => array(
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'class',
                        'value' => array(
                            esc_html__('fadeInLeft', 'revo') => 'fadeInLeft',
                            esc_html__('fadeInUp', 'revo') => 'fadeInUp',


                        ),
                        'std' => '',
                        'heading' => esc_html__('display style ', 'revo'),
                        'description' => esc_html__('Select display style.', 'revo'),


                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'heading' => esc_html__('Animation delay', 'revo'),
                        'param_name' => 'delay',
                        'description' => esc_html__('insert delay in seconds for example 0.5s or 1s (to delay the appearance of items ', 'revo')
                    ),

                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__('The icons 1 ', 'revo'),
                        'param_name' => 'icon',
                        'value' => 'fa-send',
                        'description' => esc_html__('insert icon', 'revo'),
                        'settings' => array(
                            'emptyIcon' => false,
                            'iconsPerPage' => 4000,
                        )
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'heading' => esc_html__('Text title', 'revo'),
                        'param_name' => 'h',
                        'description' => esc_html__('insert text ', 'revo')
                    ),
                    array(
                        'type' => 'textarea',
                        'holder' => 'div',
                        'heading' => esc_html__('Description', 'revo'),
                        'param_name' => 'desc',
                        'description' => esc_html__('insert text ', 'revo')
                    ),


                ),
            ),
            array(
                'type' => 'param_group',
                'heading' => esc_html__('Features list right', 'revo'),
                'group' => esc_html__('Features right', 'revo'),
                'param_name' => 'items2',
                'params' => array(
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'class3',
                        'value' => array(
                            esc_html__('fadeInRight', 'revo') => 'fadeInRight',
                            esc_html__('fadeInUp', 'revo') => 'fadeInUp',


                        ),
                        'std' => '',
                        'heading' => esc_html__('display style ', 'revo'),
                        'description' => esc_html__('Select display style.', 'revo'),


                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('data-wow-delay', 'revo'),
                        'param_name' => 'wow',
                        'value' => esc_html__('', 'revo'),
                        'description' => esc_html__('insert delay in seconds for example 0.5s or 1s (to delay the appearance of items ', 'revo')
                    ),


                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__('The icons 1 ', 'revo'),
                        'param_name' => 'icon2',
                        'value' => 'fa-send',
                        'description' => esc_html__('insert icon', 'revo'),
                        'settings' => array(
                            'emptyIcon' => false,
                            'iconsPerPage' => 4000,
                        )
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'heading' => esc_html__('Text title', 'revo'),
                        'param_name' => 'h2',
                        'description' => esc_html__('insert text ', 'revo')
                    ),
                    array(
                        'type' => 'textarea',
                        'holder' => 'div',
                        'heading' => esc_html__('Description', 'revo'),
                        'param_name' => 'desc2',
                        'description' => esc_html__('insert text ', 'revo')
                    ),


                ),
            ),
            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),

        ),

    ));


    /********Reviews***********/

    vc_map(array(
        'name' => esc_html__('Revo Reviews', 'revo'),
        'base' => 'revo_reviews',
        'icon' => plugins_url('/icon/reviews.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Insert main heading', 'revo'),
                'param_name' => 'title',
                'value' => esc_html__('Our Testimonials', 'revo'),
                'description' => esc_html__('insert  heading ', 'revo')
            ),
            array(
                'type' => 'param_group',
                'heading' => esc_html__('Revo Reviews items', 'revo'),
                'param_name' => 'items',
                'params' => array(
                    array(
                        'type' => 'attach_image',
                        'heading' => esc_html__('Images', 'revo'),
                        'param_name' => 'images',

                        'description' => esc_html__('Select images from media library.', 'revo'),
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'heading' => esc_html__('Review name', 'revo'),
                        'param_name' => 'name',
                        'description' => esc_html__('insert text example Ana Blunt ', 'revo')
                    ),
                    array(
                        'type' => 'textarea',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('Specialty', 'revo'),
                        'param_name' => 'spec',
                        'value' => '',
                        'description' => esc_html__('insert text', 'revo')
                    ),

                    array(
                        'type' => 'textarea',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('Description review', 'revo'),
                        'param_name' => 'desc',
                        'value' => '',
                        'description' => esc_html__('insert text', 'revo')
                    ),


                ),
            ),


            /** color option  */
            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),


        )
    ));


    /********Reviews2***********/

    vc_map(array(
        'name' => esc_html__('Revo Reviews 2', 'revo'),
        'base' => 'revo_reviews_2',
        'icon' => plugins_url('/icon/reviews2.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Insert main heading', 'revo'),
                'param_name' => 'title',
                'value' => esc_html__('Our Testimonials', 'revo'),
                'description' => esc_html__('insert  heading ', 'revo')
            ),
            array(
                'type' => 'param_group',
                'heading' => esc_html__('Revo Reviews items', 'revo'),
                'param_name' => 'items',
                'params' => array(
                    array(
                        'type' => 'attach_image',
                        'heading' => esc_html__('Images', 'revo'),
                        'param_name' => 'images',

                        'description' => esc_html__('Select images from media library.', 'revo'),
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'heading' => esc_html__('Review name', 'revo'),
                        'param_name' => 'name',
                        'description' => esc_html__('insert text example Ana Blunt ', 'revo')
                    ),
                    array(
                        'type' => 'textarea',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('Specialty', 'revo'),
                        'param_name' => 'spec',
                        'value' => '',
                        'description' => esc_html__('insert text', 'revo')
                    ),

                    array(
                        'type' => 'textarea',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('Description review', 'revo'),
                        'param_name' => 'desc',
                        'value' => '',
                        'description' => esc_html__('insert text', 'revo')
                    ),


                ),
            ),


            /** color option  */
            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),


        )
    ));


    /********Reviews3***********/

    vc_map(array(
        'name' => esc_html__('Revo Reviews 3', 'revo'),
        'base' => 'revo_reviews_3',
        'icon' => plugins_url('/icon/rev3.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Insert main heading', 'revo'),
                'param_name' => 'title',
                'value' => esc_html__('Our Testimonials', 'revo'),
                'description' => esc_html__('insert  heading ', 'revo')
            ),
            array(
                'type' => 'param_group',
                'heading' => esc_html__('Revo Reviews items', 'revo'),
                'param_name' => 'items',
                'params' => array(
                    array(
                        'type' => 'attach_image',
                        'heading' => esc_html__('Images', 'revo'),
                        'param_name' => 'images',

                        'description' => esc_html__('Select images from media library.', 'revo'),
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'heading' => esc_html__('Name', 'revo'),
                        'value' => esc_html__('Ana Blunt', 'revo'),
                        'param_name' => 'name',
                        'description' => esc_html__('insert text  ', 'revo')
                    ),
                    array(
                        'type' => 'textarea',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('Specialty', 'revo'),
                        'param_name' => 'spec',
                        'value' => esc_html__('Creative Director', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),

                    array(
                        'type' => 'textarea',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('Description ', 'revo'),
                        'param_name' => 'desc',
                        'value' => esc_html__('Mauris aliquam risus id dui elementum accumsan. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. massa sit amet viverra ', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),


                ),
            ),


            /** color option  */
            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),


        )
    ));


    /*
       * price table
       */

    vc_map(array(
        'name' => esc_html__('Revo Price table', 'revo'),
        'base' => 'revo_price_table',
        'icon' => plugins_url('/icon/price.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Title', 'revo'),
                'param_name' => 'heading',
                'description' => esc_html__('Add Your Title', 'revo'),
            ),


            array(
                'type' => 'textarea',
                'heading' => esc_html__('description', 'revo'),
                'param_name' => 'description',
                'description' => esc_html__('Add Your description', 'revo'),
            ),


            array(
                'type' => 'param_group',
                'heading' => esc_html__('Price table values', 'revo'),
                'param_name' => 'items',
                'group' => esc_html__('Price table values', 'revo'),
                'params' => array(
                    array(
                        'type' => 'dropdown',
                        'param_name' => 'class',
                        'value' => array(
                            esc_html__('Standard', 'revo') => '',
                            esc_html__('ADVANCED', 'revo') => 'ADVANCED',


                        ),
                        'std' => '',
                        'heading' => esc_html__('display style ', 'revo'),
                        'description' => esc_html__('Select display style.', 'revo'),
                    ),
                    array(
                        'type' => 'textfield',

                        'heading' => esc_html__('Table title', 'revo'),
                        'param_name' => 'h',
                        'description' => esc_html__('insert text ', 'revo')
                    ),

                    array(
                        'type' => 'textfield',

                        'heading' => esc_html__('currency', 'revo'),
                        'param_name' => 'currency',
                        'value' => esc_html__('$', 'revo'),
                        'description' => esc_html__('insert currency ', 'revo')
                    ),
                    array(
                        'type' => 'textfield',

                        'heading' => esc_html__('period', 'revo'),
                        'param_name' => 'period',
                        'value' => esc_html__('Per Month', 'revo'),
                        'description' => esc_html__('insert period', 'revo')
                    ),
                    array(
                        'type' => 'textfield',

                        'heading' => esc_html__('insert price', 'revo'),
                        'param_name' => 'price',
                        'description' => esc_html__('insert price', 'revo')
                    ),
                    array(
                        'type' => 'textfield',

                        'heading' => esc_html__('Text button', 'revo'),
                        'param_name' => 'tb',
                        'value' => esc_html__('Select plan', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),
                    array(
                        'type' => 'textfield',

                        'heading' => esc_html__('Text button hover', 'revo'),
                        'param_name' => 'tbh',
                        'value' => esc_html__('Order Now', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),
	                array(
		                'type' => 'textfield',

		                'heading' => esc_html__('button url', 'revo'),
		                'param_name' => 'url',
		                'value' => esc_html__('#', 'revo'),
		                'description' => esc_html__('insert link', 'revo')
	                ),
                    array(
                        'type' => 'param_group',

                        'heading' => esc_html__('Price features', 'revo'),
                        'param_name' => 'items',
                        'params' => array(

                            array(
                                'type' => 'textfield',

                                'heading' => esc_html__('Text', 'revo'),
                                'param_name' => 'title',
                                'description' => esc_html__('insert text', 'revo')
                            ),

                            array(
                                'type' => 'iconpicker',
                                'heading' => esc_html__('The icons 1 ', 'revo'),
                                'param_name' => 'icon',
                                'value' => 'fa-check',
                                'description' => esc_html__('insert icon', 'revo'),
                                'settings' => array(
                                    'emptyIcon' => false,
                                    'iconsPerPage' => 4000,
                                )
                            ),

                        ),
                    ),


                ),
            ),


            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),
        )
    ));


    /********blog***********/

    vc_map(array(
        'name' => esc_html__('Revo blog', 'revo'),
        'base' => 'revo_blog_section',
        'icon' => plugins_url('/icon/blog.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Insert main heading', 'revo'),
                'param_name' => 'title',
                'value' => esc_html__('OUR BLOG', 'revo'),
                'description' => esc_html__('insert  heading ', 'revo')
            ),

            array(
                'type' => 'textarea',
                'heading' => esc_html__('Insert description', 'revo'),
                'param_name' => 'description',
                'value' => esc_html__('The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo'),
                'description' => esc_html__('Insert description ', 'revo')
            ),

            array(
                'type' => 'textfield',

                'heading' => esc_html__('Post count', 'revo'),
                'param_name' => 'count',
                'description' => esc_html__('You can control with number your blog posts', 'revo'),
                'group' => esc_html__('Post settings', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'heading' => esc_html__('order', 'revo'),
                'param_name' => 'order',
                'description' => esc_html__('Enter blog item order. DESC or ASC', 'revo'),
                'group' => esc_html__('Post settings', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'heading' => esc_html__('orderby', 'revo'),
                'param_name' => 'orderby',
                'description' => esc_html__('Enter post orderby. Default is : date', 'revo'),
                'group' => esc_html__('Post settings', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Category', 'revo'),
                'param_name' => 'blog_category',
                'description' => esc_html__('Enter slug category ', 'revo'),
                'group' => esc_html__('Post settings', 'revo'),
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),

        )
    ));


    /*
 * contact section
 */

    vc_map(array(
        'name' => esc_html__('Revo Contact Section ', 'revo'),
        'base' => 'revo_contact_section',
        'icon' => plugins_url('/icon/message.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Title', 'revo'),
                'param_name' => 'heading',
                'description' => esc_html__('Add Your Title', 'revo'),
            ),


            /*******************STEPS Item********************/

            array(
                'type' => 'textfield',
                'heading' => esc_html__('insert text Name', 'revo'),
                'param_name' => 'name',
                'description' => esc_html__('insert text ', 'revo'),
                'value' => esc_html__('Name *', 'revo'),
                'group' => esc_html__('Contact form', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('insert text Email', 'revo'),
                'param_name' => 'Email',
                'description' => esc_html__('insert text ', 'revo'),
                'value' => esc_html__('Email address *', 'revo'),
                'group' => esc_html__('Contact form', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('insert text Send message button', 'revo'),
                'param_name' => 'sm',
                'description' => esc_html__('insert text ', 'revo'),
                'value' => esc_html__('Send message', 'revo'),
                'group' => esc_html__('Contact form', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'heading' => esc_html__('insert text Message', 'revo'),
                'param_name' => 'message',
                'description' => esc_html__('insert text ', 'revo'),
                'value' => esc_html__('Message', 'revo'),
                'group' => esc_html__('Contact form', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('insert text Submit button', 'revo'),
                'param_name' => 'smh',
                'description' => esc_html__('insert text ', 'revo'),
                'value' => esc_html__('Submit', 'revo'),
                'group' => esc_html__('Contact form', 'revo'),
            ),


            /*******aderess********/

            array(
                'type' => 'param_group',
                'heading' => esc_html__('Address item', 'revo'),
                'param_name' => 'address_items',
                'group' => esc_html__('Address item', 'revo'),
                'params' => array(
                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__('Address icons 1 ', 'revo'),
                        'param_name' => 'addres_icon',
                        'description' => esc_html__('Select icon', 'revo'),
                        'settings' => array(
                            'emptyIcon' => false,
                            'iconsPerPage' => 4000,
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Address Heading ', 'revo'),
                        'param_name' => 'addres_heading',
                        'description' => esc_html__('insert address heading text', 'revo'),

                    ),
                    array(
                        'type' => 'textarea',
                        'heading' => esc_html__('Address Description ', 'revo'),
                        'param_name' => 'addres_desc',
                        'description' => esc_html__('insert address description text', 'revo'),

                    ),
                ),
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),

        )
    ));


    /*
* contact section 2
*/

    vc_map(array(
        'name' => esc_html__('Revo Contact Section 2', 'revo'),
        'base' => 'revo_contact_section_2',
        'icon' => plugins_url('/icon/contact.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Title', 'revo'),
                'param_name' => 'heading',
                'description' => esc_html__('Add Your Title', 'revo'),
            ),


            /*******************STEPS Item********************/

            array(
                'type' => 'textfield',
                'heading' => esc_html__('insert text Name', 'revo'),
                'param_name' => 'name',
                'description' => esc_html__('insert text ', 'revo'),
                'value' => esc_html__('Name *', 'revo'),
                'group' => esc_html__('Contact form', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('insert text Email', 'revo'),
                'param_name' => 'Email',
                'description' => esc_html__('insert text ', 'revo'),
                'value' => esc_html__('Email address *', 'revo'),
                'group' => esc_html__('Contact form', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('insert numbers ', 'revo'),
                'param_name' => 'phone',
                'description' => esc_html__('insert text ', 'revo'),
                'value' => esc_html__('Phone', 'revo'),
                'group' => esc_html__('Contact form', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('insert text Send message button', 'revo'),
                'param_name' => 'sm',
                'description' => esc_html__('insert text ', 'revo'),
                'value' => esc_html__('Send message', 'revo'),
                'group' => esc_html__('Contact form', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'heading' => esc_html__('insert text Message', 'revo'),
                'param_name' => 'message',
                'description' => esc_html__('insert text ', 'revo'),
                'value' => esc_html__('Message', 'revo'),
                'group' => esc_html__('Contact form', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('insert text Submit button', 'revo'),
                'param_name' => 'smh',
                'description' => esc_html__('insert text ', 'revo'),
                'value' => esc_html__('Submit', 'revo'),
                'group' => esc_html__('Contact form', 'revo'),
            ),


            /*******aderess********/

            array(
                'type' => 'param_group',
                'heading' => esc_html__('Social', 'revo'),
                'param_name' => 'address_items',
                'group' => esc_html__('Address item', 'revo'),
                'params' => array(
                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__('Address icons 1 ', 'revo'),
                        'param_name' => 'social_icon',
                        'description' => esc_html__('Select icon', 'revo'),
                        'settings' => array(
                            'emptyIcon' => false,
                            'iconsPerPage' => 4000,
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Social url ', 'revo'),
                        'param_name' => 'social_url',
                        'description' => esc_html__('insert url', 'revo'),

                    ),

                ),
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),


        )
    ));


    /********partners***********/


    /*
    * Partners
    */
    vc_map(array(
        'name' => esc_html__('Revo Partners', 'revo'),
        'base' => 'revo_partners',
        'show_settings_on_create' => true,
        'category' => esc_html__('Revo', 'revo'),
        'description' => esc_html__('', 'revo'),
        'icon' => plugins_url('/icon/partners.png', __FILE__), // Simply pass url to your icon here
        'custom_markup' => '{{title}}<div class="vc_btn3-container"><h4 class="team-name"></h4></div>',
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Heading', 'revo'),
                'param_name' => 'h',
                'description' => esc_html__('Add Your Section Heading', 'revo'),
                'value' => esc_html__('Our Partners', 'revo'),
            ),

            array(
                'type' => 'attach_images',
                'heading' => esc_html__('Images', 'revo'),
                'param_name' => 'images',
                'value' => '',
                'description' => esc_html__('Select images from media library.', 'revo'),
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Design options', 'revo'),
            ),
        ),


    ));

    /**
     * revo slider
     */
    $slider_arr = array('Select alias' => '');
    if (class_exists('RevSlider')) {
        $sld = new RevSlider();
        $sliders = $sld->getArrSliders();
        if (!empty($sliders)) {
            foreach ($sliders as $slider) {
                //get alias all slider
                $slider_arr = array_merge($slider_arr, array($slider->getTitle() => $slider->getParam('alias', 'false')));


            }
        }


    }


    vc_map(array(
        'name' => esc_html__('Revo Revolution slider Header', 'revo'),
        'base' => 'revo_header_slider',
        'show_settings_on_create' => true,
        'category' => esc_html__('Revo', 'revo'),
        'description' => esc_html__('Site header', 'revo'),
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'dropdown',
                'heading' => esc_html__('Select Slider Revolution alias', 'revo'),
                'param_name' => 'alias_slider',
                'description' => esc_html__('select the alias of the slider', 'revo'),
                'value' => $slider_arr
            ),
            array(
                'type' => 'attach_image',
                'heading' => esc_html__('Images bg', 'revo'),
                'group' => esc_html__('Top column ', 'revo'),
                "holder" => "img",
                'param_name' => 'img_src',
                'description' => esc_html__('Select images from media library.', 'revo'),
            ),
        ),


    ));


    /*
   *  Home
   */
    vc_map(array(
        'name' => esc_html__('Revo home', 'revo'),
        'base' => 'revo_home',
        'show_settings_on_create' => true,
        'category' => esc_html__('Revo', 'revo'),
        'description' => esc_html__('', 'revo'),
        'custom_markup' => '{{title}}<div class="vc_btn3-container"><h4 class="team-name"></h4></div>',
        'icon' => plugins_url('/icon/home.png', __FILE__), // Simply pass url to your icon here
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),


            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => esc_html__('Heading', 'revo'),
                'param_name' => 't',
                'description' => esc_html__('insert text', 'revo')
            ),

            array(
                'type' => 'textarea',
                'class' => '',
                'heading' => esc_html__('Description', 'revo'),
                'param_name' => 'd',
                'description' => esc_html__('insert text', 'revo')
            ),
            array(
                'type' => 'dropdown',
                'param_name' => 'class',
                'value' => array(
                    esc_html__('main-about', 'revo') => 'main-about',
                    esc_html__('main-about2 ', 'revo') => 'main-about2',
                    esc_html__('main-portfolio ', 'revo') => 'main-portfolio',
                    esc_html__('main-features ', 'revo') => 'main-features',
                    esc_html__('main-services ', 'revo') => 'main-services',
                    esc_html__('main-contact ', 'revo') => 'main-contact',
                    esc_html__('main-contact2 ', 'revo') => 'main-contact2',
                    esc_html__(' main-404 ', 'revo') => 'main-404',
                    esc_html__(' main-portfolio2 ', 'revo') => ' main-portfolio2',
                    esc_html__(' main-portfolio3 ', 'revo') => ' main-portfolio3',


                ),
                'std' => '',
                'heading' => esc_html__('display style ', 'revo'),
                'description' => esc_html__('Select display style.', 'revo'),


            ),


            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),

        ),

    ));


    /**
     * banner
     */

    vc_map(array(
        'name' => esc_html__('Revo Banner  Section ', 'revo'),
        'base' => 'revo_banner',
        'icon' => plugins_url('/icon/collage.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Title', 'revo'),
                'param_name' => 'title',
                'description' => esc_html__('Insert heading', 'revo')
            ),


            array(
                'type' => 'textfield',
                'heading' => esc_html__('Button url', 'revo'),
                'param_name' => 'url',
                'description' => esc_html__('Insert url', 'revo')
            ),

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Button text', 'revo'),
                'param_name' => 'bt',
                'description' => esc_html__('Insert text', 'revo')
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),


        )
    ));


    /**
     * about  Progressbar
     */

    vc_map(array(
        'name' => esc_html__(' Revo Progressbar  ', 'revo'),
        'base' => 'revo_about_progressbar',
        'icon' => plugins_url('/icon/about1.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),


            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => esc_html__('Heading', 'revo'),
                'param_name' => 'left_heading',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('insert text', 'revo')
            ),

            array(
                'type' => 'textarea',

                'class' => '',
                'heading' => esc_html__('Text', 'revo'),
                'param_name' => 'left_text',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('insert text', 'revo')
            ),


            array(
                'type' => 'param_group',

                'heading' => esc_html__('Progressbar ', 'revo'),
                'param_name' => 'items2',
                'params' => array(

                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Item title', 'revo'),
                        'param_name' => 'progresstitle',
                        'description' => esc_html__('Add item title', 'revo')
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Item width value', 'revo'),
                        'param_name' => 'progresssize',
                        'description' => esc_html__('Add item value example:50,30,90...etc', 'revo')
                    ),


                ),

            ),


            array(

                'type' => 'attach_image',
                'heading' => esc_html__('Images bg', 'revo'),
                "holder" => "img",
                'param_name' => 'img_src2',
                'description' => esc_html__('Select images from media library.', 'revo'),
            ),


            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Design options', 'revo'),
            ),


        ),


    ));

    /**
     * about part  with icons
     */

    vc_map(array(
        'name' => esc_html__('Revo About  with icons ', 'revo'),
        'base' => 'revo_about_icon',
        'icon' => plugins_url('/icon/info.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => esc_html__('Section heading', 'revo'),
                'param_name' => 'heading',
                'value' => esc_html__('WHAT WE DO', 'revo'),
                'description' => esc_html__('insert text', 'revo')
            ),

            array(
                'type' => 'textarea',
                'class' => '',
                'heading' => esc_html__('Section description', 'revo'),
                'param_name' => 'description',
                'value' => esc_html__('The difference between a Designer and Developer when it comes to design skills, is the difference between shooting a bullet and throwing it', 'revo'),
                'description' => esc_html__('insert text', 'revo')
            ),
            array(
                'type' => 'checkbox',
                'heading' => esc_html__('Not show section heading & description ', 'revo'),
                'param_name' => 'style',
                'value' => false,
                'description' => esc_html__('', 'revo'),

            ),



            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => esc_html__('top column heading', 'revo'),
                'param_name' => 'right_heading',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('insert delay time  example: 0.2s', 'revo')
            ),
            array(
                'type' => 'attach_image',
                'heading' => esc_html__('Images', 'revo'),
                'param_name' => 'images',
                'value' => '',
                'description' => esc_html__('Select images from media library.', 'revo'),
            ),
            array(
                'type' => 'param_group',
                'heading' => esc_html__('About items', 'revo'),
                'param_name' => 'items',
                'params' => array(

                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__('The icons 1 ', 'revo'),
                        'param_name' => 'icon',
                        'value' => '',
                        'description' => esc_html__('insert icon', 'revo'),
                        'settings' => array(
                            'emptyIcon' => false,
                            'iconsPerPage' => 4000,
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        'class' => '',
                        'heading' => esc_html__('Title', 'revo'),
                        'param_name' => 't',
                        'value' => esc_html__('USER INTERFACE', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),
                    array(
                        'type' => 'textarea',
                        'class' => '',
                        'heading' => esc_html__('Description', 'revo'),
                        'param_name' => 'd',
                        'value' => esc_html__('Crafting visually stunning memorable experiences for web and interfaces', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),


                ),

            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Design options', 'revo'),
            ),


        )

    ));


    /*****
     * about with small img
     ***************/

    vc_map(array(
        'name' => esc_html__('Revo about section with small img', 'revo'),
        'base' => 'revo_about_small_img',
        'icon' => plugins_url('/icon/about-icon.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        'params' => array(

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => esc_html__('Main heading', 'revo'),
                'param_name' => 'main_heading',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('Insert text', 'revo')
            ),
            array(
                'type' => 'textarea',
                'class' => '',
                'heading' => esc_html__('Main description', 'revo'),
                'param_name' => 'main_description',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('Insert text', 'revo')
            ),
            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => esc_html__('About heading', 'revo'),
                'param_name' => 'about_heading',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('Insert text', 'revo')
            ),

            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => esc_html__('top column heading', 'revo'),
                'param_name' => 'right_heading',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('insert delay time  example: 0.2s', 'revo')
            ),
            array(
                'type' => 'attach_image',
                'heading' => esc_html__('Images', 'revo'),
                'param_name' => 'images',
                'value' => '',
                'description' => esc_html__('Select images from media library.', 'revo'),
            ),
            array(
                'type' => 'param_group',
                'heading' => esc_html__('About items', 'revo'),
                'param_name' => 'items',
                'params' => array(

                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__('The icons 1 ', 'revo'),
                        'param_name' => 'icon',
                        'value' => '',
                        'description' => esc_html__('insert icon', 'revo'),
                        'settings' => array(
                            'emptyIcon' => false,
                            'iconsPerPage' => 4000,
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        'class' => '',
                        'heading' => esc_html__('Title', 'revo'),
                        'param_name' => 't',
                        'value' => esc_html__('USER INTERFACE', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),
                    array(
                        'type' => 'textarea',
                        'class' => '',
                        'heading' => esc_html__('Description', 'revo'),
                        'param_name' => 'd',
                        'value' => esc_html__('Crafting visually stunning memorable experiences for web and interfaces', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),


                ),

            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Design options', 'revo'),
            ),


        )

    ));

    /*
*  Features 3
*/
    vc_map(array(
        'name' => esc_html__('Revo features 3', 'revo'),
        'base' => 'revo_about_3',
        'show_settings_on_create' => true,
        'category' => esc_html__('Revo', 'revo'),
        'description' => esc_html__('', 'revo'),
        'custom_markup' => '{{title}}<div class="vc_btn3-container"><h4 class="team-name"></h4></div>',
        'icon' => plugins_url('/icon/star3.png', __FILE__), // Simply pass url to your icon here
        'params' => array(
            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),

            array(
                'type' => 'param_group',
                'heading' => esc_html__('Services items', 'revo'),
                'param_name' => 'items',
                'params' => array(


                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__('The icons 1 ', 'revo'),
                        'param_name' => 'icon',
                        'value' => '',
                        'description' => esc_html__('insert icon', 'revo'),
                        'settings' => array(
                            'emptyIcon' => false,
                            'iconsPerPage' => 4000,
                        )
                    ),
                    array(
                        'type' => 'textfield',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('Title', 'revo'),
                        'param_name' => 'ts',
                        'value' => esc_html__('Branding', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),
                    array(
                        'type' => 'textarea',
                        'holder' => 'div',
                        'class' => '',
                        'heading' => esc_html__('Description', 'revo'),
                        'param_name' => 'ds',
                        'value' => esc_html__('Maecenas mattis est eget efficitur tempus. Maecenas fermentum fringilla vestibulum. Nulla pulvinar ullamcorper auctor', 'revo'),
                        'description' => esc_html__('insert text', 'revo')
                    ),


                ),

            ),


            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Background options', 'revo'),
            ),
        ),

    ));


    /**
     * accordion Section
     */


    vc_map(array(
        'name' => esc_html__('Revo accordion Section', 'revo'),
        'base' => 'revo_accordion_section',
        'show_settings_on_create' => true,
        'icon' => plugins_url('/icon/accordion.png', __FILE__), // Simply pass url to your icon here
        'category' => esc_html__('Revo', 'revo'),
        "as_parent" => array('only' => 'revo_accordion_item'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
        "content_element" => true,
        "js_view" => 'VcColumnView',
        'params' => array(


            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => esc_html__('Top Heading', 'revo'),
                'param_name' => 'heading',
                'description' => esc_html__('insert text', 'revo')
            ),
            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => esc_html__('Top description', 'revo'),
                'param_name' => 'description',
                'description' => esc_html__('insert text', 'revo')
            ),


            array(
                'type' => 'attach_image',
                'group' => esc_html__('Top column ', 'revo'),
                'heading' => esc_html__('Images', 'revo'),
                'param_name' => 'images',
                "holder" => "img",
                'description' => esc_html__('Select images from media library.', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'group' => esc_html__('Top column ', 'revo'),
                'class' => '',
                'heading' => esc_html__('top column heading', 'revo'),
                'param_name' => 'about_title',
                'description' => esc_html__('insert text', 'revo')
            ),

            array(
                'group' => esc_html__('Bottom column ', 'revo'),
                'type' => 'attach_image',
                'heading' => esc_html__('Images bg', 'revo'),
                "holder" => "img",
                'param_name' => 'img_src2',
                'description' => esc_html__('Select images from media library.', 'revo'),
            ),

            array(
                'type' => 'textfield',
                'group' => esc_html__('Bottom column ', 'revo'),
                'class' => '',
                'heading' => esc_html__('Bottom column heading', 'revo'),
                'param_name' => 'left_heading',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('insert text', 'revo')
            ),

            array(
                'type' => 'textarea',
                'group' => esc_html__('Bottom column ', 'revo'),
                'class' => '',
                'heading' => esc_html__('Bottom column text', 'revo'),
                'param_name' => 'left_text',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('insert text', 'revo')
            ),


            array(
                'type' => 'param_group',
                'group' => esc_html__('Bottom column ', 'revo'),
                'heading' => esc_html__('Progressbar ', 'revo'),
                'param_name' => 'items2',
                'params' => array(

                    array(
                        'type' => 'textfield',
                        'group' => esc_html__('Bottom column ', 'revo'),
                        'heading' => esc_html__('Item title', 'revo'),
                        'param_name' => 'progresstitle',
                        'description' => esc_html__('Add item title', 'revo')
                    ),
                    array(
                        'group' => esc_html__('Bottom column ', 'revo'),
                        'type' => 'textfield',
                        'heading' => esc_html__('Item width value', 'revo'),
                        'param_name' => 'progresssize',
                        'description' => esc_html__('Add item value example:50,30,90...etc', 'revo')
                    ),


                ),

            ),


            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Design options', 'revo'),
            ),


        )

    ));


    /*
     * revo Accordion item
     */

    vc_map(array(
        'name' => esc_html__('Revo Accordion item', 'revo'),
        'base' => 'revo_accordion_item',
        'show_settings_on_create' => true,
        'category' => esc_html__('Revo', 'revo'),
        'description' => esc_html__('', 'revo'),
        'icon' => plugins_url('/icon/user.png', __FILE__), // Simply pass url to your icon here
        'custom_markup' => '{{title}}<div class="vc_btn3-container"><h4 class="team-name"></h4></div>',
        'params' => array(

            // add params same as with any other content element
            array(
                'type' => 'textfield',
                'param_name' => 'title',
                'heading' => esc_html__('Title', "revo"),
                'description' => esc_html__('Enter text used as  title ', "revo"),
            ),

            array(
                'type' => 'dropdown',
                'param_name' => 'class',
                'value' => array(
                    esc_html__('closed item ', 'revo') => '',
                    esc_html__('open item ', 'revo') => 'in',

                ),
                'std' => '',
                'heading' => esc_html__('display style ', 'revo'),
                'description' => esc_html__('Select display style.', 'revo'),


            ),
            array(
                'type' => 'textfield',
                'param_name' => 'name',
                'heading' => esc_html__('Name', "revo"),
                'description' => esc_html__('Insert text ', "revo"),
            ),

            array(
                "type" => "textarea",
                "class" => "",
                "heading" => esc_html__("Enter description text", "revo"),
                "param_name" => "content",
                "value" => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce non felis id purus interdum euismod.',
                "description" => ''
            ),


            array(
                'type' => 'attach_image',
                'heading' => esc_html__('Images', 'revo'),
                'param_name' => 'images',
                'value' => '',
                'description' => esc_html__('Select images from media library.', 'revo'),
            ),


        ),

    ));

    /*
     * Revo image section
     */
    vc_map(array(
        'name' => esc_html__('Revo image section', 'revo'),
        'base' => 'revo_image_section',
        'category' => esc_html__('Revo', 'revo'),
        'icon' => plugins_url('/icon/Image.png', __FILE__), // Simply pass url to your icon here'category' => esc_html__('Revo', 'revo'),
        'params' => array(

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'class' => '',
                'heading' => esc_html__('Title', 'revo'),
                'param_name' => 'title',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('Insert text', 'revo')
            ),

            array(
                'type' => 'textfield',
                'param_name' => 'url',
                'heading' => esc_html__('Url', "revo"),
                'description' => esc_html__('Enter url ', "revo"),
            ),
            array(
                'type' => 'textfield',
                'param_name' => 'bt',
                'heading' => esc_html__('Button Text', "revo"),
                'description' => esc_html__('Enter text ', "revo"),
            ),
            array(
                'type' => 'textarea',
                'class' => '',
                'heading' => esc_html__('Description', 'revo'),
                'param_name' => 'des',
                'value' => esc_html__('', 'revo'),
                'description' => esc_html__('Insert text', 'revo')
            ),


            array(
                'type' => 'attach_image',
                'heading' => esc_html__('Images', 'revo'),
                'param_name' => 'images',
                'value' => '',
                'description' => esc_html__('Select images from media library.', 'revo'),
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Design options', 'revo'),
            ),


        )

    ));


    /*
  * Contact map
  */

    vc_map(array(

        'name' => esc_html__('Revo map', 'revo'),
        'base' => 'revo_map',
        'show_settings_on_create' => true,
        'category' => esc_html__('Revo', 'revo'),
        'description' => esc_html__('', 'revo'),
        'icon' => plugins_url('/icon/map.png', __FILE__), // Simply pass url to your icon here'category' => esc_html__('Revo', 'revo'),
        'custom_markup' => '{{title}}<div class="vc_btn3-container"><h4 class="team-name"></h4></div>',
        'params' => array(

            array(
                'type' => 'textfield',
                'heading' => esc_html__('Section ID', 'revo'),
                'param_name' => 'section_id',
                'description' => esc_html__('Add Your Section ID', 'revo'),
            ),
            array(
                'type' => 'param_group',
                'holder' => 'div',
                'heading' => esc_html__('Items values', 'revo'),
                'group' => esc_html__('Contact form', 'revo'),
                'param_name' => 'items',
                'params' => array(

                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Name ', 'revo'),
                        'param_name' => 'name',
                        'description' => esc_html__('insert text', 'revo'),

                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Email ', 'revo'),
                        'param_name' => 'email',
                        'description' => esc_html__('insert text', 'revo'),

                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Phone ', 'revo'),
                        'param_name' => 'phone',
                        'description' => esc_html__('insert text', 'revo'),

                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Message ', 'revo'),
                        'param_name' => 'message',
                        'description' => esc_html__('insert text', 'revo'),

                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Submit ', 'revo'),
                        'param_name' => 'submit',
                        'description' => esc_html__('insert text', 'revo'),

                    ),

                ),
            ),


            array(
                'type' => 'param_group',
                'holder' => 'div',
                'heading' => esc_html__('Contact address', 'revo'),
                'group' => esc_html__('Contact items', 'revo'),
                'param_name' => 'contact_items',
                'params' => array(
                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__('The icons', 'revo'),
                        'param_name' => 'icon',
                        'value' => 'fa-rss',
                        'description' => esc_html__('insert icon', 'revo'),
                        'settings' => array(
                            'emptyIcon' => false,
                            'iconsPerPage' => 4000,
                        )

                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => esc_html__('Title ', 'revo'),
                        'param_name' => 'h',
                        'description' => esc_html__('insert text', 'revo'),

                    ),
                    array(
                        'type' => 'textarea',
                        'heading' => esc_html__('Description ', 'revo'),
                        'param_name' => 'd',
                        'description' => esc_html__('insert text', 'revo'),

                    ),

                ),
            ),

            

            array(
                'type' => 'dropdown',
                'heading' => esc_html__('Contact map visibility', 'revo'),
                'param_name' => 'map_visibility',
                'description' => esc_html__('Show or hide map', 'revo'),
                'value' => array(
                    esc_html__('Show', 'revo') => '1',
                    esc_html__('Hide', 'revo') => '2',
                ),
                'group' => esc_html__('Map', 'revo'),
            ),
            array(
                'type' => 'attach_image',
                'heading' => esc_html__('Map marker image', 'revo'),
                'param_name' => 'images',
                'value' => '',
                'description' => esc_html__('Add your map marker image', 'revo'),
                'group' => esc_html__('Map', 'revo'),
            ),

            array(
                'type' => 'param_group',
                'holder' => 'div',
                'heading' => esc_html__('Map info values', 'revo'),
                'param_name' => 'map_items',
                'group' => esc_html__('Map', 'revo'),
                'params' => array(
                    array(
                        'type' => 'iconpicker',
                        'heading' => esc_html__('The icons', 'revo'),
                        'param_name' => 'icon',
                        'value' => '',
                        'description' => esc_html__('insert icon', 'revo'),
                        'settings' => array(
                            'emptyIcon' => false,
                            'iconsPerPage' => 4000,
                        )

                    ),
                    array(
                        'type' => 'textarea',
                        'heading' => esc_html__('Description ', 'revo'),
                        'param_name' => 'content',
                        'description' => esc_html__('insert text', 'revo'),

                    ),

                ),
            ),

            array(
                'type' => 'textfield',
                'holder' => 'div',
                'heading' => esc_html__('insert url ', 'revo'),
                'param_name' => 'map_url',
                'description' => esc_html__('url ', 'revo'),
                'group' => esc_html__('Map', 'revo'),

            ),
            array(
                'type' => 'textfield',
                'holder' => 'div',
                'heading' => esc_html__('insert text url ', 'revo'),
                'param_name' => 'map_url_t',
                'description' => esc_html__(' text url  ', 'revo'),
                'group' => esc_html__('Map', 'revo'),

            ),
            /*************************/

            array(
                'type' => 'textfield',
                'holder' => 'div',
                'heading' => esc_html__('insert lat coordinates ', 'revo'),
                'param_name' => 'lat',
                'description' => esc_html__('insert lat for example 45.036537 ', 'revo'),
                'value' => esc_html__('45.036537', 'revo'),
                'group' => esc_html__('Map', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'holder' => 'div',
                'heading' => esc_html__('insert lng coordinates ', 'revo'),
                'param_name' => 'lng',
                'description' => esc_html__('insert lng for example 38.9957687 ', 'revo'),
                'value' => esc_html__('38.995768', 'revo'),
                'group' => esc_html__('Map', 'revo'),
            ),
            array(
                'type' => 'textfield',
                'holder' => 'div',
                'heading' => esc_html__('insert zooms ', 'revo'),
                'param_name' => 'zoom',
                'description' => esc_html__('insert zoom for example 15', 'revo'),
                'value' => 12,
                'group' => esc_html__('Map', 'revo'),
            ),


            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Design options', 'revo'),
            ),


        ),


        
    ));



    /*
  * Contact map2
  */

	vc_map( array(

		'name' => esc_html__( 'Revo map2', 'revo' ),
		'base' => 'revo_map2',
		'show_settings_on_create' => true,
		'category' => esc_html__( 'Revo', 'revo' ),
		'description' => esc_html__( '', 'revo' ),
		'icon' => plugins_url( '/icon/map2.png', __FILE__ ),
		// Simply pass url to your icon here'category' => esc_html__('Revo', 'revo'),
		'custom_markup' => '{{title}}<div class="vc_btn3-container"><h4 class="team-name"></h4></div>',
		'params' => array(

			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Section ID', 'revo' ),
				'param_name' => 'section_id',
				'description' => esc_html__( 'Add Your Section ID', 'revo' ),
			),

			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Name ', 'revo' ),
				'param_name' => 'name',
				'description' => esc_html__( 'insert text', 'revo' ),
				'group' => esc_html__( 'Contact form', 'revo' ),

			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Email ', 'revo' ),
				'param_name' => 'email',
				'description' => esc_html__( 'insert text', 'revo' ),
				'group' => esc_html__( 'Contact form', 'revo' ),

			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Phone ', 'revo' ),
				'param_name' => 'phone',
				'description' => esc_html__( 'insert text', 'revo' ),
				'group' => esc_html__( 'Contact form', 'revo' ),

			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Message ', 'revo' ),
				'param_name' => 'message',
				'description' => esc_html__( 'insert text', 'revo' ),
				'group' => esc_html__( 'Contact form', 'revo' ),

			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Submit ', 'revo' ),
				'param_name' => 'submit',
				'description' => esc_html__( 'insert text', 'revo' ),
				'group' => esc_html__( 'Contact form', 'revo' ),

			),


			array(
				'type' => 'param_group',
				'holder' => 'div',
				'heading' => esc_html__( 'Contact address', 'revo' ),
				'group' => esc_html__( 'Contact items', 'revo' ),
				'param_name' => 'contact_items',
				'params' => array(
					array(
						'type' => 'iconpicker',
						'heading' => esc_html__( 'The icons', 'revo' ),
						'param_name' => 'icon',
						'value' => 'fa-rss',
						'description' => esc_html__( 'insert icon', 'revo' ),
						'settings' => array(
							'emptyIcon' => false,
							'iconsPerPage' => 4000,
						)

					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__( 'Title ', 'revo' ),
						'param_name' => 'h',
						'description' => esc_html__( 'insert text', 'revo' ),

					),
					array(
						'type' => 'textarea',
						'heading' => esc_html__( 'Description ', 'revo' ),
						'param_name' => 'd',
						'description' => esc_html__( 'insert text', 'revo' ),

					),

				),
			),


			array(
				'type' => 'dropdown',
				'heading' => esc_html__( 'Contact map visibility', 'revo' ),
				'param_name' => 'map_visibility',
				'description' => esc_html__( 'Show or hide map', 'revo' ),
				'value' => array(
					esc_html__( 'Show', 'revo' ) => '1',
					esc_html__( 'Hide', 'revo' ) => '2',
				),
				'group' => esc_html__( 'Map', 'revo' ),
			),
			array(
				'type' => 'attach_image',
				'heading' => esc_html__( 'Map marker image', 'revo' ),
				'param_name' => 'images',
				'value' => '',
				'description' => esc_html__( 'Add your map marker image', 'revo' ),
				'group' => esc_html__( 'Map', 'revo' ),
			),

			array(
				'type' => 'param_group',
				'holder' => 'div',
				'heading' => esc_html__( 'Map info values', 'revo' ),
				'param_name' => 'map_items',
				'group' => esc_html__( 'Map', 'revo' ),
				'params' => array(
					array(
						'type' => 'iconpicker',
						'heading' => esc_html__( 'The icons', 'revo' ),
						'param_name' => 'icon',
						'value' => '',
						'description' => esc_html__( 'insert icon', 'revo' ),
						'settings' => array(
							'emptyIcon' => false,
							'iconsPerPage' => 4000,
						)

					),
					array(
						'type' => 'textarea',
						'heading' => esc_html__( 'Description ', 'revo' ),
						'param_name' => 'content',
						'description' => esc_html__( 'insert text', 'revo' ),

					),

				),
			),

			array(
				'type' => 'textfield',
				'holder' => 'div',
				'heading' => esc_html__( 'insert url ', 'revo' ),
				'param_name' => 'map_url',
				'description' => esc_html__( 'url ', 'revo' ),
				'group' => esc_html__( 'Map', 'revo' ),

			),
			array(
				'type' => 'textfield',
				'holder' => 'div',
				'heading' => esc_html__( 'insert text url ', 'revo' ),
				'param_name' => 'map_url_t',
				'description' => esc_html__( ' text url  ', 'revo' ),
				'group' => esc_html__( 'Map', 'revo' ),

			),

			/*************************/

			array(
				'type' => 'textfield',
				'holder' => 'div',
				'heading' => esc_html__( 'insert lat coordinates ', 'revo' ),
				'param_name' => 'lat',
				'description' => esc_html__( 'insert lat for example 45.036537 ', 'revo' ),
				'value' => esc_html__( '45.200', 'revo' ),
				'group' => esc_html__( 'Map', 'revo' ),
			),
			array(
				'type' => 'textfield',
				'holder' => 'div',
				'heading' => esc_html__( 'insert lng coordinates ', 'revo' ),
				'param_name' => 'lng',
				'description' => esc_html__( 'insert lng for example 38.9957687 ', 'revo' ),
				'value' => esc_html__( '-72.4310', 'revo' ),
				'group' => esc_html__( 'Map', 'revo' ),
			),
			array(
				'type' => 'textfield',
				'holder' => 'div',
				'heading' => esc_html__( 'insert zooms ', 'revo' ),
				'param_name' => 'zoom',
				'description' => esc_html__( 'insert zoom for example 15', 'revo' ),
				'value' => 8,
				'group' => esc_html__( 'Map', 'revo' ),
			),

			array(
				'type' => 'param_group',
				'holder' => 'div',
				'heading' => esc_html__( 'Social', 'revo' ),
				'group' => esc_html__( 'Social items', 'revo' ),
				'param_name' => 'social',
				'params' => array(
					array(
						'type' => 'iconpicker',
						'heading' => esc_html__( 'The icons', 'revo' ),
						'param_name' => 'fa',
						'description' => esc_html__( 'insert icon', 'revo' ),
						'settings' => array(
							'emptyIcon' => false,
							'iconsPerPage' => 4000,
						)

					),
					array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => esc_html__( 'insert url ', 'revo' ),
						'param_name' => 'url',
						'description' => esc_html__( 'insert url', 'revo' ),
					),

				),
			),
			array(
				'type' => 'css_editor',
				'heading' => esc_html__( 'Css', 'revo' ),
				'param_name' => 'css',
				'group' => esc_html__( 'Design options', 'revo' ),
			),


		),


	) );



	/**
     *portfolio new update
     */


    vc_map(array(
            'name' => esc_html__('Revo portfolio new', 'revo'),
            'base' => 'revo_portfolio_new_update',
            'show_settings_on_create' => true,
            'icon' => plugins_url('/icon/dossier.png', __FILE__), // Simply pass url to your icon here
            'category' => esc_html__('Revo', 'revo'),
            "as_parent" => array('only' => 'revo_accordion_item'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
            "content_element" => true,
            'params' => array(

                array(
                    'type' => 'dropdown',
                    'class' => '',
                    'heading' => esc_html__('Filter class', 'revo'),
                    'param_name' => 'filter',
                    'value' => array(
                        esc_html__('none', 'revo') => '',
                        esc_html__(' filter-top', 'revo') => ' filter filter-top ',




                    ),

                ),
                array(
                    'type' => 'dropdown',
                    'class' => '',
                    'heading' => esc_html__('Class', 'revo'),
                    'param_name' => 'class',
                    'description' => esc_html__('Class that sets the top and bottom margins', 'revo'),
                    'value' => array(
                        esc_html__('none', 'revo') => '',
                        esc_html__('section ', 'revo') => ' section  ',
                    ),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Heading', 'revo'),
                    'param_name' => 'heading',
                    'description' => esc_html__('Add Your Heading', 'revo'),
                    'value' => esc_html__('OUR PORTFOLIO', 'revo'),
                ),

                array(
                    'type' => 'dropdown',
                    'class' => '',
                    'heading' => esc_html__('Portfolio view', 'revo'),
                    'param_name' => 'col',
                    'value' => array(
                        esc_html__('none', 'revo') => '',
                        esc_html__('padding ', 'revo') => ' isotope-padding ',
                        esc_html__('col-3 ', 'revo') => 'col-3 isotope-padding ',
                        esc_html__('col-2 ', 'revo') => 'col-2 ',



                    ),
                ),

                array(
                    'type' => 'param_group',
                    'heading' => esc_html__('Portfolio item', 'revo'),
                    'group' => esc_html__('Portfolio items', 'revo'),
                    'param_name' => 'items',
                    'params' => array(
                        array(
                            'type' => 'textfield',
                            'class' => '',
                            'heading' => esc_html__('Category', 'revo'),
                            'param_name' => 'cat',
                            'description' => esc_html__('Insert category', 'revo')
                        ),

                        array(
                            'type' => 'textfield',
                            'class' => '',
                            'heading' => esc_html__('Category slug', 'revo'),
                            'param_name' => 'slug',
                            'description' => esc_html__('Insert category slug', 'revo')
                        ),




                        array(
                            'type' => 'textfield',
                            'class' => '',
                            'heading' => esc_html__('Title', 'revo'),
                            'param_name' => 'title',
                            'description' => esc_html__('Insert title', 'revo')
                        ),

                        array(
                            'type' => 'param_group',
                            'heading' => esc_html__('Image item', 'revo'),
                            'group' => esc_html__('Image items', 'revo'),
                            'param_name' => 'image_items',
                            'params' => array(

                                array(
                                    'type' => 'attach_image',
                                    'heading' => esc_html__('Image', 'revo'),
                                    "holder" => "img",
                                    'param_name' => 'img_src',
                                    'description' => esc_html__('Select images from media library.', 'revo'),
                                ),

                                array(
                                    'type' => 'dropdown',
                                    'class' => '',
                                    'heading' => esc_html__('Image size', 'revo'),
                                    'param_name' => 'size',
                                    'value' => array(
                                        esc_html__('normal', 'revo') => '',
                                        esc_html__('big ', 'revo') => ' w2 ',




                                    ),

                                ),





                            ),

                        ),

                    ),

                ),
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'revo'),
                'param_name' => 'css',
                'group' => esc_html__('Design options', 'revo'),
            ),


        )

    );


}